exit;

#macro GNX_LOG "gnx_debug.txt"
