function scr_draw_mon_head()
{
    var _class = unit_data.class;
    var _type = unit_data.mon_type;
    var _lvl = unit_data.lvl;
    var _mon_num = 0;
    var _breed = false;
    var _mon_array = scr_mon_type_construct(_type);
    _mon_num = _mon_array.num[_class];

    if (draw_num)
    {
        var _cancel_shake = -shift_x + fail_ori_x;
        var _alpha = 1;
        draw_set_halign(fa_center);
        draw_set_color(c_white);
        var _x_shift, _y_shift;

        if (interact_type == 21)
        {
            if (draw_stat)
            {
                _x = (x - 11) + _cancel_shake;
                _y = y - 14;
                var _surface = -1;

                if (!surface_exists(_surface))
                    _surface = surface_create(480, 270);

                surface_set_target(_surface);
                draw_clear_alpha(c_white, 0);
                draw_sprite(spr_raid_mon_frame, 0, _x, _y);
                surface_reset_target();
                draw_surface_part(_surface, 49, 46, 114, 101, 49, 46);
                surface_free(_surface);
                _x = x + 16 + _cancel_shake;
                _y = y + 10;

                if (_lvl < 5)
                    scr_draw_bar_h(_x - 1, _y - 3, _mon_array.expe[_class], global.max_exp[min(4, _lvl)], 65535, 17, false);
                else
                    scr_draw_bar_h(_x - 1, _y - 3, 1, 1, 65280, 17, false);

                var _rng_num = array_length(global.mon_range[_type][_class]);
                _x = (x + 49 + _cancel_shake) - (5 * (_rng_num - 1));
                _y = y + 5;

                for (var i = 0; i < _rng_num; i++)
                    draw_sprite(spr_raid_stat_icon, global.mon_range[_type][_class][i], _x + (i * 10), _y);

                _x = x + 46;
                var _num = _mon_array.stat[_class] + _mon_array.lvl[_class];
                draw_text(_x + _cancel_shake, y - 9, "AP");
                draw_text(_x + _cancel_shake + 11, y - 9, _num);
                _x = x + 75 + _cancel_shake;
                _y = y - 2;
                var _skill = global.mon_skill[_type][_class];
                var _skill_lvl = _mon_array.skill_lvl[_class];
                draw_sprite(spr_skill_ui, _skill, _x - 1, _y + 1);
                var _v = _mon_array.skill_exp[_class];

                if (_skill_lvl < 5)
                    scr_draw_bar_h(_x + 8, _y + 9, _v, global.max_exp[_skill_lvl], 65535, 17, false);
                else
                    scr_draw_bar_h(_x + 8, _y + 9, 1, 1, 65280, 17, false);

                _x = x + 75 + 16;
                scr_draw_head_star(_x, _y - 1, 0, 0, _skill_lvl);
                _x_shift = 23;
                _y_shift = -3;
                _alpha = 1 - (raid_sel * 0.75);

                if (hover)
                {
                    var _ar = global.val.br_unlock[_type][_class];
                    var _h_num = min(0, _ar[0]) + min(0, _ar[1]) + 2;
                    var _i_num = 0;
                    var _height = 24;

                    if (_h_num > 0)
                        draw_sprite(spr_raid_head_window, _h_num - 1, x, y - _height);

                    for (var i = 0; i < 2; i++)
                    {
                        if (_ar[i] != -1)
                        {
                            var _icon_x = (x - ((_h_num - 1) * 11)) + ((_h_num - 1) * _i_num * 22);
                            draw_sprite(spr_head_grey, _ar[i], _icon_x, y - _height);
                            _i_num++;
                        }
                    }

                    // GNX: draw modded class breeders above vanilla window, cycling every 2s if multiple
                    var _gnx_list = global.gnx_br_unlock[_type][_class];
                    var _gnx_num = array_length(_gnx_list);
                    if (_gnx_num > 0)
                    {
                        var _gnx_idx = (current_time div 2000) mod _gnx_num;
                        var _gnx_class = _gnx_list[_gnx_idx];
                        if (ds_map_exists(global.class_registry, _gnx_class))
                        {
                            var _gnx_icon = ds_map_find_value(global.class_registry, _gnx_class).icon_spr;
                            if (_gnx_icon != -1)
                            {
                                var _gnx_y = y - _height - 22;
                                draw_sprite(spr_raid_head_window, 0, x, _gnx_y);
                                draw_sprite_ext(_gnx_icon, 0, x, _gnx_y, 1, 1, 0, c_gray, 1);
                            }
                        }
                    }

                    hover = false;
                }
            }
        }
        else
        {
            _mon_num = draw_num_sel;
            var _skill_alpha = 1;
            var _skill_exp = 0;
            var _skill_num = 0;
            var _skill_type = obj_np.obj_raid.raid_data.skill_type[row][button_num];
            _x_shift = 0;
            _y_shift = 12;

            if (image_alpha != 1 && num_window != -1 && instance_exists(num_window))
            {
                _alpha = image_alpha;
                _skill_alpha = image_alpha;
                draw_set_alpha(_skill_alpha);
                var _array = scr_mon_type_construct(unit_data.mon_type);
                _skill_exp = num_window.num * (_array.skill_lvl[unit_data.class] + 1);

                while (_skill_exp >= ((_skill_num + 1) * 10))
                {
                    _skill_exp -= ((_skill_num + 1) * 10);
                    _skill_num += 1;
                }
            }
            else
            {
                _skill_exp = obj_np.obj_raid.raid_data.skill_exp[row][button_num];
                _skill_num = obj_np.obj_raid.raid_data.skill_num[row][button_num];
            }

            scr_draw_bar_v(x - 9, y + 23, _skill_exp, (_skill_num + 1) * 10, 65535, 10);
            draw_sprite(spr_skill_ui, _skill_type, x + 2, y + 28);
            draw_set_alpha(1);
            scr_draw_shadow(x - 3, y + 28, _skill_num, 1);
        }

        draw_sprite_ext(sprite_index, _class + (_type * 4), x, y, 1, 1, image_angle, image_blend, _alpha);
        scr_draw_shadow(x + draw_num_x + _cancel_shake, y + draw_num_y, _mon_num, 1);
        var _x = x + _cancel_shake;
        var _y = y;
        scr_draw_head_star(_x, _y, _x_shift, _y_shift, _lvl);
    }
    else
    {
        draw_sprite_ext(sprite_index, _class + (_type * 4), x, y, 1, 1, image_angle, image_blend, image_alpha);
    }
}
