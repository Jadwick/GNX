if (gui)
{
    if (scr_window_draw != -1)
        script_execute(scr_window_draw);
    else
        draw_self();
}
