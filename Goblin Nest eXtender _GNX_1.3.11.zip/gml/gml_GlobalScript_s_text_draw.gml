function scr_draw_textbox()
{
    if (!ff)
    {
        var _lang_pos = scr_change_lang();
        draw_set_halign(fa_left);

        for (var c = 0; c < draw_char; c++)
        {
            var _text = char[c][page];
            var _x = char_x[c][page] + _lang_pos[0];
            var _y = char_y[c][page] + _lang_pos[1];
            draw_set_alpha(0.3);
            draw_set_color(shadow_color);
            draw_text(_x + 1, _y + 1, _text);
            draw_set_alpha(1);
            draw_set_color(text_color);
            draw_text(_x, _y, _text);
        }

        draw_set_font(fnt_base_font_eng);
    }
}

function scr_draw_window_portrait()
{
    scr_draw_backdrop();
    draw_sprite(spr_raid_screen, 0, 170, 36);

    // GNX: runtime-loaded portraits are standalone sprites (ID >= 100);
    // vanilla portraits are sub-image indices (0-94) into spr_portrait sheet
    if (portrait_index >= 100 && sprite_exists(portrait_index))
        draw_sprite(portrait_index, 0, 173, 39);
    else
        draw_sprite(spr_portrait, portrait_index, 173, 39);

    var _lang_pos = scr_change_lang();
    var _y = 0;
    draw_set_halign(fa_center);
    draw_text(284 + _lang_pos[0], 40 + _y + _lang_pos[1], name_text);
    draw_set_font(fnt_base_font_eng);
    draw_set_halign(fa_left);
    draw_text(297, 214, string(textbox_id.page_number));
    draw_set_halign(fa_right);
    draw_text(293, 214, string(textbox_id.page + 1));
    draw_set_halign(fa_center);
    draw_text(295, 214, "/");
}

function scr_draw_backdrop()
{
    draw_set_alpha(0.7);
    draw_rectangle_color(0, 0, 480, 270, c_black, c_black, c_black, c_black, false);
    draw_set_alpha(1);
}

function scr_create_cat_skill_window(arg0, arg1)
{
    var _width, _text_1, _text_2;

    switch (arg0)
    {
        case UnknownEnum.Value_0:
            switch (arg1)
            {
                case UnknownEnum.Value_0:
                    _text_1 = "Get more food from raiding.";
                    _text_2 = "Increases 8% per stack";
                    _width = 10.5;
                    break;

                case UnknownEnum.Value_1:
                    _text_1 = "Monsters have a chance to not die.";
                    _text_2 = "Increases 4% per stack";
                    _width = 12.5;
                    break;

                case UnknownEnum.Value_2:
                    _text_1 = "Front Formation AP increase.";
                    _text_2 = "Increases 3% per stack";
                    _width = 10;
                    break;

                case UnknownEnum.Value_3:
                    _text_1 = "Higher chance to get items.";
                    _text_2 = "Increases 4% per stack";
                    _width = 10;
                    break;
            }

            break;

        case UnknownEnum.Value_1:
            switch (arg1)
            {
                case UnknownEnum.Value_0:
                    _text_1 = "Get more gold from raiding.";
                    _text_2 = "Increases 5% per stack";
                    _width = 10;
                    break;

                case UnknownEnum.Value_1:
                    _text_1 = "Higher chance to capture units.";
                    _text_2 = "Increases 3% per stack";
                    _width = 12;
                    break;

                case UnknownEnum.Value_2:
                    _text_1 = "Caravan speed increase.";
                    _text_2 = "Increases 3% per stack";
                    _width = 10;
                    break;

                case UnknownEnum.Value_3:
                    _text_1 = "Back Formation AP increase.";
                    _text_2 = "Increases 3% per stack";
                    _width = 10;
                    break;
            }

            break;

        case UnknownEnum.Value_2:
            switch (arg1)
            {
                case UnknownEnum.Value_0:
                    _text_1 = "Mood increase after defeating the enemy in a raid.";
                    _text_2 = "Increases 0.5 per stack";
                    _width = 17;
                    break;

                case UnknownEnum.Value_1:
                    _text_1 = "Chance to get milk after capturing units.";
                    _text_2 = "Increases 8% per stack";
                    _width = 14;
                    break;

                case UnknownEnum.Value_2:
                    _text_1 = "Captured units have a chance to be a star higher.";
                    _text_2 = "Increases 2% per stack";
                    _width = 17;
                    break;

                case UnknownEnum.Value_3:
                    _text_1 = "Get more gold and food from raiding.";
                    _text_2 = "Increases 3% per stack";
                    _width = 13;
                    break;
            }

            break;

        case UnknownEnum.Value_3:
            switch (arg1)
            {
                case UnknownEnum.Value_0:
                    _text_1 = "Front formation skills stack increase.";
                    _text_2 = "Increases by 1 per stack";
                    _width = 13;
                    break;

                case UnknownEnum.Value_1:
                    _text_1 = "Back formation skills stack increase.";
                    _text_2 = "Increases by 1 per stack";
                    _width = 13;
                    break;

                case UnknownEnum.Value_2:
                    _text_1 = "Rare star units spawn chance increase.";
                    _text_2 = "Increases 3% per stack";
                    _width = 14;
                    break;

                case UnknownEnum.Value_3:
                    _text_1 = "Front and Back Formation AP increase.";
                    _text_2 = "Increases 2% per stack";
                    _width = 13;
                    break;
            }

            break;
    }

    with (instance_create_depth(127, 47 + (arg1 * 26), -2600, obj_window))
    {
        gui = true;
        interact_type = UnknownEnum.Value_10;
        sprite_index = spr_pixel;
        image_xscale = 36;
        image_yscale = 23;
        scr_window_end_step = -1;
        scr_window_draw = scr_cat_skill_draw;
        draw_width = _width;
        skill_text_1 = _text_1;
        skill_text_2 = _text_2;
    }
}

enum UnknownEnum
{
    Value_0,
    Value_1,
    Value_2,
    Value_3,
    Value_10 = 10
}
