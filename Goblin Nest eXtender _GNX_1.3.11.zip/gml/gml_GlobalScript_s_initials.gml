function scr_create_initials()
{
    randomize();
    global.val = {};
    global.val.sfx_vol = 0.5;
    global.val.bgm_vol = 0.5;
    global.val.money = 0;
    global.val.food = 0;
    global.val.play_time = 0;
    global.val.day_timer = 0;
    global.val.day = 1;
    global.val.floor = 0;
    global.val.mood = 80;
    global.val.mood_red = 0;
    global.val.camera_click = 2;
    global.val.select_click = 1;
    global.val.show_head = false;
    global.val.stage_info = [-1, -1, -1, -1, -1];
    global.val.stage_lvl_sel = [0, 0, 0, 0, 0];
    global.val.cage = [-1];
    global.val.quest_new = false;
    global.val.quest_clear = false;
    global.val.troop_size = 0;
    global.val.cart_spd = 1;
    global.val.add_range = 0;
    global.val.orb_num = 4;
    global.val.elf_num = 0;
    global.val.raid_num = 0;
    global.val.birth_num = 0;
    global.val.cap_num = 0;
    global.val.alpha_type = 0;
    global.val.mon_alpha = 1;
    global.val.crate_alpha_type = 0;
    global.val.crate_alpha = 1;
    global.val.ui_place = false;
    global.val.t_lvl = 0;
    global.val.old_t_lvl = 0;
    global.val.ct_lvl = 0;
    global.val.demo = 0;
    global.val.version = 1.33;
    global.val.language = 0;
    global.val.goblin = 
    {
        num: [0, -1, -1, -1],
        stat: [1, 1, 2, 3],
        lvl: [0, 0, 0, 0],
        expe: [0, 0, 0, 0],
        skill_lvl: [0, 0, 0, 0],
        skill_exp: [0, 0, 0, 0]
    };
    global.val.hobgoblin = 
    {
        num: [-1, -1, -1, -1],
        stat: [4, 5, 4, 5],
        lvl: [0, 0, 0, 0],
        expe: [0, 0, 0, 0],
        skill_lvl: [0, 0, 0, 0],
        skill_exp: [0, 0, 0, 0]
    };
    global.val.tentacle = 
    {
        num: [-1, -1, -1, -1],
        stat: [3, 3, 4, 4],
        lvl: [0, 0, 0, 0],
        expe: [0, 0, 0, 0],
        skill_lvl: [0, 0, 0, 0],
        skill_exp: [0, 0, 0, 0]
    };
    global.val.ogre = 
    {
        num: [-1, -1, -1, -1],
        stat: [6, 6, 7, 7],
        lvl: [0, 0, 0, 0],
        expe: [0, 0, 0, 0],
        skill_lvl: [0, 0, 0, 0],
        skill_exp: [0, 0, 0, 0]
    };
    global.val.mon_num = [0, -1, -1, -1];
    global.val.nest_num = [5, 0, 0, 0, 0];
    global.unlock = 
    {
        breed: [],
        utility: [],
        pleasure: [],
        b_breed: [],
        b_utility: [],
        b_other: [],
        t_breed: [],
        t_utility: [],
        edit_between: [],
        edit_top: [],
        edit_mid: [],
        edit_bot: [],
        entrance: false,
        raid: false,
        unit: false,
        timer: false,
        boss: [-1, -1, -1, -1, -1, -1]
    };
    global.val.br_unlock = [[[-1, -1], [-1, -1], [-1, -1], [-1, -1]], [[-1, -1], [-1, -1], [-1, -1], [-1, -1]], [[-1, -1], [-1, -1], [-1, -1], [-1, -1]], [[-1, -1], [-1, -1], [-1, -1], [-1, -1]]];
    // GNX: separate br_unlock for modded classes (vanilla slots are fully occupied)
    // each [type][class] entry is an array of GNX class_ids that can birth this monster class
    global.gnx_br_unlock = [];
    for (var _t = 0; _t < 4; _t++)
    {
        global.gnx_br_unlock[_t] = [];
        for (var _c = 0; _c < 4; _c++)
            global.gnx_br_unlock[_t][_c] = [];
    }
    global.val.guide_unlock =
    {
        num: 0,
        cell: []
    };
    global.unit_list = ds_list_create();
    global.front_row = ds_list_create();
    global.back_row = ds_list_create();
    global.new_button_list = ds_list_create();
    global.noti_list = ds_list_create();
    global.inv_list = ds_list_create();
    global.raid_inv_list = ds_list_create();
    global.quest_list = ds_list_create();
    global.new_guide_list = ds_list_create();
    global.front_row_save = ds_list_create();
    global.back_row_save = ds_list_create();
    
    for (var i = 0; i < 5; i++)
        ds_list_add(global.unit_list, -1);
    
    scr_set_encounter_reward();
    scr_set_shop_list();
    global.load_file = -1;
    global.mask_collision = false;
    global.dirt_fix = 0;
    global.death_fix = 0;
    global.trans_lock = false;
    global.camera_lock = false;
    global.click_lock = false;
    global.drag_lock = false;
    global.speed_lock = false;
    global.speed_save = false;
    global.build_side = false;
    global.w_spd = 1;
    global.zoom_target = 0;
    global.muffle = 1;
    global.breed_order = [1, 2, 7, 8, 9, 13, 14];
    global.utility_order = [5, 12, 4, 10, 11];
    global.pleasure_order = [3, 6, 15];
    global.b_breed_order = [19, 18, 23, 20, 21, 22];
    global.b_utility_order = [17, 24, 25];
    global.b_pleasure_order = [36, 37, 38, 42, 41, 40, 39];
    global.t_breed_order = [31, 32, 29, 27, 28];
    global.t_utility_order = [34, 30, 33];
    global.between_order = [0, 1, 2, 3, 4];
    global.prop_order_top = [37, 9, 13, 19, 24, 28, 6, 15, 16, 47];
    global.prop_order_mid = [10, 7, 14, 17, 8, 11, 12, 36, 21, 27];
    global.prop_order_bot = [0, 1, 20, 2, 3, 30, 31, 18, 4, 5, 22, 23, 25, 29, 32, 33, 34, 35, 26, 38];
    global.guide_order_cell = [10, 12, 11, 17, 33, 30, 24, 25, 41, 42, 40, 39];
    global.base_raid_time = [2760, 3240, 4000, 5100, 4800];
    var _goblin_alpha_c = make_color_rgb(35, 101, 0);
    var _hobgoblin_alpha_c = make_color_rgb(11, 105, 183);
    var _ogre_alpha_c = make_color_rgb(127, 105, 52);
    global.mon_alpha_c = [_goblin_alpha_c, _hobgoblin_alpha_c, -1, _ogre_alpha_c];
    var _start_x = -1;
    global.slot_x = [];
    global.slot_list = [];
    global.slot_x[0] = _start_x;
    global.slot_list[0] = ds_list_create();
    var _c_1 = make_color_rgb(153, 0, 38);
    var _c_2 = make_color_rgb(216, 42, 13);
    var _c_3 = make_color_rgb(222, 161, 0);
    var _c_4 = make_color_rgb(1, 221, 0);
    global.mood_c = [_c_1, _c_2, _c_3, _c_4];
    global.max_exp = [50, 100, 150, 200, 250, 1];
    global.max_troop = [10, 25, 50, 90, 150, 220, 320, -1];
    global.bar_c = make_color_rgb(219, 173, 40);
    scr_set_mon_skill();
    scr_set_mon_range();
    scr_stage_raid_reward();
    scr_set_trade_list();
    // GNX: classes registered with trade_stage go here, keyed by stage (0-4)
    global.gnx_trade_list = [[], [], [], [], []];
    // GNX: per-mod persistent state (inside global.val -> auto-saved)
    global.val.gnx_mod_data = {};
    // GNX: runtime alias map for fast access (not saved, rebuilt on load)
    global.gnx_mod_state = {};
    // GNX framework debug state (toggle keys for T39, not saved)
    variable_struct_set(global.gnx_mod_state, "_gnx", { perf: 0, verbose: 0 });
    global.gnx_save_state_defaults = {};
    // Free prior GNX registries on re-entry (e.g. menu return re-runs this).
    // Values are plain structs / sprite refs / reals (GC'd) — no nested ds structures.
    var _gnx_reg_maps = ["cell_registry", "class_registry", "bl_lookup", "gnx_cov", "gnx_seen", "gnx_seen_base"];
    for (var _gri = 0; _gri < array_length(_gnx_reg_maps); _gri++)
    {
        var _grn = _gnx_reg_maps[_gri];
        if (variable_global_exists(_grn) && ds_exists(variable_global_get(_grn), ds_type_map))
            ds_map_destroy(variable_global_get(_grn));
    }
    if (variable_global_exists("gnx_expected") && ds_exists(global.gnx_expected, ds_type_list))
        ds_list_destroy(global.gnx_expected);

    global.cell_registry = ds_map_create();
    global.class_registry = ds_map_create();
    global.bl_lookup = ds_map_create();
    global.gnx_cov = ds_map_create();
    global.gnx_cov_tick = 0;
    global.gnx_seen = ds_map_create();
    global.gnx_seen_base = ds_map_create();
    global.gnx_expected = ds_list_create();
    global.use_legacy_dispatch = false;
    var _cell = 
    {
        h_type: 1,
        slot_type: 0,
        name: "WALL 1",
        physical: 
        {
            allow_preg: true,
            max_mon_num: 1,
            anal: false,
            spr_row_pos: 0,
            slot_dirt_init: 0,
            spr_slot_template: [[12, spr_dirt_wall, false, -1, false], [0, spr_slot_wall_1_back, false, -1], [2, spr_slot_wall_1_handc, true, -1], [5, spr_slot_wall_1_extra, false, -1], [7, -1, false, -1, false], [8, -1, false, -1, false]],
            scr_slot_template: 
            {
                idle: scr_slot_h_state_idle,
                h: [scr_slot_h_base_start, scr_slot_h_base_wait, scr_slot_h_base_sloop, scr_slot_h_base_floop, scr_slot_h_base_wait, scr_slot_h_base_ej, scr_slot_h_base_wait]
            },
            scr_draw_special: scr_draw_slot_parts_wall,
            hand_x: [17, 6],
            hand_y: [-42, -40],
            hand_xscale: [1, 1],
            hand_angle: [90, 0],
            hand_frames: 
            {
                frame_1: [1],
                frame_2: [2, 3],
                frame_3: [2, 3]
            },
            sp_spr: spr_sp_v_start,
            sq_x: 22,
            sq_y: [-31, -30],
            sp_x: 22,
            sp_y: [-28, -33],
            sp_anim_x: 0,
            sp_anim_y: -1
        },
        human_spr: 
        {
            mode: "base+class",
            base_body: "standard"
        },
        mon_spr: undefined
    };
    ds_map_add(global.cell_registry, 1, _cell);
    _cell = 
    {
        h_type: 2,
        slot_type: 0,
        name: "WALL 2",
        physical: 
        {
            allow_preg: true,
            max_mon_num: 1,
            anal: false,
            spr_row_pos: 0,
            slot_dirt_init: 0,
            spr_slot_template: [[12, spr_dirt_wall, false, -1, false], [0, spr_slot_wall_2_back, false, -1], [3, spr_slot_wall_2_legc, true, -1], [2, spr_slot_wall_2_handc, true, -1], [7, -1, false, -1, false], [8, -1, false, -1, false], [9, -1, false, -1, false]],
            scr_slot_template: 
            {
                idle: scr_slot_h_state_idle,
                h: [scr_slot_h_base_start, scr_slot_h_base_wait, scr_slot_h_base_sloop, scr_slot_h_base_floop, scr_slot_h_base_wait, scr_slot_h_base_ej, scr_slot_h_base_wait]
            },
            scr_draw_special: scr_draw_slot_parts_wall,
            hand_x: [17, 6, 17],
            hand_y: [-42, -40, -13],
            hand_xscale: [1, 1, 1],
            hand_angle: [90, 0, 90],
            hand_frames: 
            {
                frame_1: [1],
                frame_2: [2, 3],
                frame_3: [2, 3]
            },
            sp_spr: spr_sp_v_start,
            sq_x: 22,
            sq_y: [-31, -30],
            sp_x: 22,
            sp_y: [-28, -33],
            sp_anim_x: 0,
            sp_anim_y: -1
        },
        human_spr: 
        {
            mode: "base+class",
            base_body: "standard"
        },
        mon_spr: undefined
    };
    ds_map_add(global.cell_registry, 2, _cell);
    _cell = 
    {
        h_type: 7,
        slot_type: 0,
        name: "WALL 3",
        physical: 
        {
            allow_preg: true,
            max_mon_num: 1,
            anal: false,
            spr_row_pos: 0,
            slot_dirt_init: 0,
            spr_slot_template: [[12, spr_dirt_wall, false, -1, false], [0, spr_slot_wall_3_back, false, -1], [3, spr_slot_wall_3_legc, true, -1], [2, spr_slot_wall_3_handc, true, -1], [8, -1, false, -1, false], [7, -1, false, -1, false], [9, -1, false, -1, false]],
            scr_slot_template: 
            {
                idle: scr_slot_h_state_idle,
                h: [scr_slot_h_base_start, scr_slot_h_base_wait, scr_slot_h_base_sloop, scr_slot_h_base_floop, scr_slot_h_base_wait, scr_slot_h_base_ej, scr_slot_h_base_wait]
            },
            scr_draw_special: scr_draw_slot_parts_wall,
            hand_x: [17, 6],
            hand_y: [-39, -20],
            hand_xscale: [-1, -1],
            hand_angle: [90, 0],
            hand_frames: 
            {
                frame_1: [1],
                frame_2: [2, 3],
                frame_3: [2, 3]
            },
            sp_spr: spr_sp_v_start,
            sq_x: 22,
            sq_y: [-30, -23],
            sp_x: 22,
            sp_y: [-30, -26],
            sp_anim_x: 0,
            sp_anim_y: 1
        },
        human_spr: 
        {
            mode: "base+class",
            base_body: "standard"
        },
        mon_spr: undefined
    };
    ds_map_add(global.cell_registry, 7, _cell);
    _cell = 
    {
        h_type: 8,
        slot_type: 0,
        name: "WALL 4",
        physical: 
        {
            allow_preg: true,
            max_mon_num: 1,
            anal: false,
            spr_row_pos: 0,
            slot_dirt_init: 0,
            spr_slot_template: [[12, spr_dirt_wall, false, -1, false], [0, spr_slot_wall_4_back, false, -1], [2, spr_slot_wall_4_handc, true, -1], [5, spr_slot_wall_4_extra, false, -1], [7, -1, false, -1, false], [8, -1, false, -1, false]],
            scr_slot_template: 
            {
                idle: scr_slot_h_state_idle,
                h: [scr_slot_h_base_start, scr_slot_h_base_wait, scr_slot_h_base_sloop, scr_slot_h_base_floop, scr_slot_h_base_wait, scr_slot_h_base_ej, scr_slot_h_base_wait]
            },
            scr_draw_special: scr_draw_slot_parts_wall,
            hand_x: [17, 6],
            hand_y: [-38, -35],
            hand_xscale: [-1, -1],
            hand_angle: [90, 0],
            hand_frames: 
            {
                frame_1: [1],
                frame_2: [2, 3],
                frame_3: [2, 3]
            },
            sp_spr: spr_sp_v_start,
            sq_x: 22,
            sq_y: [-30, -23],
            sp_x: 22,
            sp_y: [-30, -26],
            sp_anim_x: 0,
            sp_anim_y: 1
        },
        human_spr: 
        {
            mode: "base+class",
            base_body: "standard"
        },
        mon_spr: undefined
    };
    ds_map_add(global.cell_registry, 8, _cell);
    _cell = 
    {
        h_type: 9,
        slot_type: 0,
        name: "M.PRESS 1",
        physical: 
        {
            allow_preg: true,
            max_mon_num: 1,
            anal: false,
            spr_row_pos: 0,
            slot_dirt_init: 0,
            spr_slot_template: [[0, spr_slot_press_1_back, false, -1], [5, spr_slot_press_1_extra, false, -1], [12, spr_dirt_mp, false, -1, false], [9, -1, -2, -1, false], [6, -1, false, -1, true], [8, -1, false, -1, false], [2, spr_slot_press_1_handc, true, -1], [7, -1, false, -1, false], [11, -1, false, -1, false]],
            scr_slot_template: 
            {
                idle: scr_slot_h_state_idle,
                h: [scr_slot_h_base_start, scr_slot_h_base_wait, scr_slot_h_base_sloop, scr_slot_h_base_floop, scr_slot_h_base_wait, scr_slot_h_base_ej, scr_slot_h_base_wait]
            },
            scr_draw_special: scr_draw_slot_parts,
            hand_x: [3],
            hand_y: [-11],
            hand_xscale: [-1],
            hand_angle: [0],
            hand_frames: 
            {
                frame_2: [2, 3],
                frame_3: [3, 4]
            },
            sp_spr: spr_sp_v_start,
            sq_x: 22,
            sq_y: [-17, -14],
            sp_x: 22,
            sp_y: [-17, -14],
            sp_anim_x: 0,
            sp_anim_y: 1
        },
        human_spr: 
        {
            mode: "base+class",
            base_body: "standard"
        },
        mon_spr: undefined
    };
    ds_map_add(global.cell_registry, 9, _cell);
    _cell = 
    {
        h_type: 13,
        slot_type: 0,
        name: "PRONE 1",
        physical: 
        {
            allow_preg: true,
            max_mon_num: 1,
            anal: false,
            spr_row_pos: 0,
            slot_dirt_init: 0,
            spr_slot_template: [[10, -1, -2, -1, false, -1], [0, spr_slot_prone_1_back, false, -1], [12, spr_dirt_prone, false, -1, false], [6, -1, false, -1, false], [8, -1, false, -1, false], [2, spr_slot_prone_1_handc, true, -1], [7, -1, false, -1, false]],
            scr_slot_template: 
            {
                idle: scr_slot_h_state_idle,
                h: [scr_slot_h_base_start, scr_slot_h_base_wait, scr_slot_h_base_sloop, scr_slot_h_base_floop, scr_slot_h_base_wait, scr_slot_h_base_ej, scr_slot_h_base_wait]
            },
            scr_draw_special: scr_draw_slot_parts,
            hand_x: [4],
            hand_y: [-23],
            hand_xscale: [-1],
            hand_angle: [0],
            hand_frames: 
            {
                frame_2: [2, 3],
                frame_3: [3, 4]
            },
            sp_spr: spr_sp_v_start,
            sq_x: 22,
            sq_y: [-22, -25],
            sp_x: 22,
            sp_y: [-22, -25],
            sp_anim_x: 0,
            sp_anim_y: 0
        },
        human_spr: 
        {
            mode: "base+class",
            base_body: "standard"
        },
        mon_spr: undefined
    };
    ds_map_add(global.cell_registry, 13, _cell);
    _cell = 
    {
        h_type: 14,
        slot_type: 0,
        name: "RIDE",
        physical: 
        {
            allow_preg: true,
            max_mon_num: 1,
            anal: false,
            spr_row_pos: 0,
            slot_dirt_init: 0,
            spr_slot_template: [[12, spr_dirt_back, false, -1, false], [5, spr_slot_ride_extra, false, -1], [8, -1, false, -1, false], [10, -1, -2, -1, false, -1], [6, -1, false, -1, false]],
            scr_slot_template: 
            {
                idle: scr_slot_h_state_idle,
                h: [scr_slot_h_base_start, scr_slot_h_base_wait, scr_slot_h_base_sloop, scr_slot_h_base_floop, scr_slot_h_base_wait, scr_slot_h_base_ej, scr_slot_h_base_wait]
            },
            scr_draw_special: scr_draw_slot_parts,
            hand_x: [],
            hand_y: [],
            hand_xscale: [],
            hand_angle: [],
            sp_spr: spr_sp_v_start,
            sq_x: 22,
            sq_y: [-5, -25],
            sp_x: 22,
            sp_y: [-5, -25],
            sp_anim_x: 0,
            sp_anim_y: -1
        },
        human_spr: 
        {
            mode: "base+class",
            base_body: "standard"
        },
        mon_spr: undefined
    };
    ds_map_add(global.cell_registry, 14, _cell);
    _cell = 
    {
        h_type: 3,
        slot_type: 0,
        name: "T.FRAME 1",
        physical: 
        {
            allow_preg: false,
            max_mon_num: 1,
            anal: false,
            spr_row_pos: 0,
            slot_dirt_init: 0,
            spr_slot_template: [[0, spr_slot_tf_1_back, false, -1], [8, -1, false, -1, false], [10, -1, -2, -1, false, -1], [5, spr_slot_tf_1_extra, false, -1], [12, spr_dirt_tf, false, -1, false], [6, -1, false, -1, false], [2, spr_slot_tf_1_handc, true, -1], [7, -1, false, -1, false]],
            scr_slot_template: 
            {
                idle: scr_slot_h_state_idle,
                h: [scr_slot_h_base_start, scr_slot_h_base_wait, scr_slot_h_base_sloop, scr_slot_h_base_floop, scr_slot_h_base_wait, scr_slot_h_base_ej_2, scr_slot_h_base_wait]
            },
            scr_draw_special: scr_draw_slot_parts,
            hand_x: [7, 17],
            hand_y: [-21, -11],
            hand_xscale: [-1, -1],
            hand_angle: [0, 90],
            hand_frames: 
            {
                frame_2: [3, 4],
                frame_3: [3, 4]
            },
            sp_spr: spr_sp_v_start,
            sq_x: 22,
            sq_y: [-24],
            sp_x: 22,
            sp_y: [-16],
            sp_anim_x: 0,
            sp_anim_y: 0
        },
        human_spr: 
        {
            mode: "base+class",
            base_body: "standard"
        },
        mon_spr: undefined
    };
    ds_map_add(global.cell_registry, 3, _cell);
    _cell = 
    {
        h_type: 6,
        slot_type: 0,
        name: "BJ 1",
        physical: 
        {
            allow_preg: false,
            max_mon_num: 1,
            anal: false,
            spr_row_pos: 0,
            slot_dirt_init: 0,
            spr_slot_template: [[0, spr_slot_bj_1_back, false, -1], [12, spr_dirt_wall, false, -1, false], [2, spr_slot_bj_1_handc, true, -1], [10, -1, -2, -1, false, -1], [7, -1, false, -1, false]],
            scr_slot_template: 
            {
                idle: scr_slot_h_state_idle,
                h: [scr_slot_h_base_start, scr_slot_h_base_wait, scr_slot_h_base_sloop, scr_slot_h_base_floop, scr_slot_h_base_wait, scr_slot_h_base_ej, scr_slot_h_base_wait]
            },
            scr_draw_special: scr_draw_slot_parts,
            hand_x: [7, 17],
            hand_y: [-29, -12],
            hand_xscale: [-1, -1],
            hand_angle: [0, 90],
            hand_frames: 
            {
                frame_1: 0,
                frame_2: [3, 4],
                frame_3: [3, 4]
            },
            sp_spr: spr_sp_v_start,
            sq_x: 22,
            sq_y: [-22],
            sp_x: 22,
            sp_y: [-22],
            sp_anim_x: 0,
            sp_anim_y: 2
        },
        human_spr: 
        {
            mode: "base+class",
            base_body: "standard"
        },
        mon_spr: undefined
    };
    ds_map_add(global.cell_registry, 6, _cell);
    _cell = 
    {
        h_type: 15,
        slot_type: 0,
        name: "FOREPLAY",
        physical: 
        {
            allow_preg: false,
            max_mon_num: 1,
            anal: false,
            spr_row_pos: 0,
            slot_dirt_init: -1,
            spr_slot_template: [[8, -1, false, -1, false], [0, spr_slot_foreplay, false, -1]],
            scr_slot_template: 
            {
                idle: scr_slot_h_state_idle,
                h: [scr_slot_h_base_sloop, scr_slot_h_base_floop, scr_slot_h_base_wait, scr_slot_h_base_ej, scr_slot_h_base_wait]
            },
            scr_draw_special: scr_draw_slot_parts,
            hand_x: [],
            hand_y: [],
            hand_xscale: [],
            hand_angle: [],
            sp_spr: spr_sp_v_start,
            sq_x: 22,
            sq_y: [-34],
            sp_x: 22,
            sp_y: [-34],
            sp_anim_x: 0,
            sp_anim_y: 0
        },
        human_spr: 
        {
            mode: "base+class",
            base_body: "standard"
        },
        mon_spr: undefined
    };
    ds_map_add(global.cell_registry, 15, _cell);
    _cell = 
    {
        h_type: 20,
        slot_type: 0,
        name: "OGRE FRONT",
        physical: 
        {
            allow_preg: true,
            max_mon_num: 1,
            anal: false,
            spr_row_pos: 16,
            slot_dirt_init: 0,
            spr_slot_template: [[12, spr_dirt_big, false, -1, false], [4, 0, true, -1], [0, spr_o_big, false, -1], [6, -1, false, -1, false], [8, -1, false, -1, false]],
            scr_slot_template: 
            {
                idle: scr_slot_h_state_idle,
                h: [scr_slot_h_big_start, scr_slot_h_base_wait, scr_slot_h_base_sloop, scr_slot_h_base_floop, scr_slot_h_base_wait, scr_slot_h_base_ej, scr_slot_h_base_wait]
            },
            scr_draw_special: scr_draw_ogre_front,
            hand_x: [],
            hand_y: [],
            hand_xscale: [],
            hand_angle: [],
            sp_spr: spr_sp_v_start,
            sq_x: 38,
            sq_y: [-10],
            sp_x: 38,
            sp_y: [-10],
            sp_anim_x: 0,
            sp_anim_y: 0
        },
        human_spr: 
        {
            mode: "base+class",
            base_body: "big"
        },
        mon_spr: undefined
    };
    ds_map_add(global.cell_registry, 20, _cell);
    _cell = 
    {
        h_type: 21,
        slot_type: 0,
        name: "OGRE BEHIND",
        physical: 
        {
            allow_preg: true,
            max_mon_num: 1,
            anal: false,
            spr_row_pos: 16,
            slot_dirt_init: 0,
            spr_slot_template: [[12, spr_dirt_big, false, -1, false], [4, 0, true, -1], [0, spr_o_big, false, -1], [8, -1, false, -1, false], [6, -1, false, -1, true], [10, -1, false, -1, false]],
            scr_slot_template: 
            {
                idle: scr_slot_h_state_idle,
                h: [scr_slot_h_big_start, scr_slot_h_base_wait, scr_slot_h_base_sloop, scr_slot_h_base_floop, scr_slot_h_base_wait, scr_slot_h_base_ej, scr_slot_h_base_wait]
            },
            scr_draw_special: scr_draw_ogre_behind,
            hand_x: [],
            hand_y: [],
            hand_xscale: [],
            hand_angle: [],
            sp_spr: -1,
            sq_x: -1,
            sq_y: [-1],
            sp_x: -1,
            sp_y: [-1],
            sp_anim_x: -1,
            sp_anim_y: -1
        },
        human_spr: 
        {
            mode: "base+class",
            base_body: "big"
        },
        mon_spr: undefined
    };
    ds_map_add(global.cell_registry, 21, _cell);
    _cell = 
    {
        h_type: 22,
        slot_type: 0,
        name: "OGRE BEHIND 2",
        physical: 
        {
            allow_preg: true,
            max_mon_num: 1,
            anal: false,
            spr_row_pos: 16,
            slot_dirt_init: 0,
            spr_slot_template: [[12, spr_dirt_big, false, -1, false], [4, 0, true, -1], [0, spr_o_big, false, -1], [10, -1, false, -1, false], [6, -1, false, -1, true], [8, -1, false, -1, false]],
            scr_slot_template: 
            {
                idle: scr_slot_h_state_idle,
                h: [scr_slot_h_big_start, scr_slot_h_base_wait, scr_slot_h_base_sloop, scr_slot_h_base_floop, scr_slot_h_base_wait, scr_slot_h_base_ej, scr_slot_h_base_wait]
            },
            scr_draw_special: scr_draw_ogre_behind,
            hand_x: [],
            hand_y: [],
            hand_xscale: [],
            hand_angle: [],
            sp_spr: spr_sp_v_start,
            sq_x: 38,
            sq_y: [-19],
            sp_x: -1,
            sp_y: [-1],
            sp_anim_x: -1,
            sp_anim_y: -1
        },
        human_spr: 
        {
            mode: "base+class",
            base_body: "big"
        },
        mon_spr: undefined
    };
    ds_map_add(global.cell_registry, 22, _cell);
    _cell = 
    {
        h_type: 37,
        slot_type: 0,
        name: "GIANT",
        physical: 
        {
            allow_preg: true,
            max_mon_num: 1,
            anal: false,
            spr_row_pos: 0,
            slot_dirt_init: 0,
            spr_slot_template: [[12, spr_dirt_giant, false, -1, false], [13, 0, true, -1], [5, spr_slot_giant_extra, false, -1], [2, spr_slot_giant_control, true, -1, false], [3, spr_slot_giant_control, true, -1, false], [7, -1, true, -1, false], [10, -1, -2, -1, false], [6, -1, true, -1, false], [8, -1, true, -1, false], [9, -1, false, -1, false], [11, -1, false, -1, false], [1, spr_slot_giant_sign, true, -1]],
            scr_slot_template: 
            {
                idle: scr_slot_h_giant_idle,
                h: [scr_slot_h_base_start, scr_slot_h_base_wait, scr_slot_h_base_sloop, scr_slot_h_base_floop, scr_slot_h_base_wait, scr_slot_h_base_ej, scr_slot_h_giant_birth, scr_slot_h_giant_birth_ej, scr_slot_h_base_wait]
            },
            scr_draw_special: scr_draw_slot_giant,
            hand_x: [],
            hand_y: [],
            hand_xscale: [],
            hand_angle: [],
            sp_spr: spr_sp_v_start,
            sq_x: 38,
            sq_y: [-17],
            sp_x: 38,
            sp_y: [-17],
            sp_anim_x: 0,
            sp_anim_y: 0
        },
        human_spr: 
        {
            mode: "base+class",
            base_body: "standard"
        },
        mon_spr: undefined
    };
    ds_map_add(global.cell_registry, 37, _cell);
    _cell.physical.sign_y_base = -92;
    _cell.physical.sign_y_jitter = 1;
    _cell = 
    {
        h_type: 39,
        slot_type: 0,
        name: "LILITH SHRINE",
        physical: 
        {
            allow_preg: true,
            max_mon_num: 1,
            anal: false,
            spr_row_pos: 16,
            slot_dirt_init: 0,
            spr_slot_template: [[0, spr_slot_l_shrine, false, -1], [12, spr_dirt_l_shrine, false, -1, false], [10, -1, false, -1, false], [8, -1, false, -1, false], [6, -1, false, -1, true], [7, -1, false, -1, false], [1, spr_slot_lilith_sign, true, -1]],
            scr_slot_template: 
            {
                idle: scr_slot_h_state_idle,
                h: [scr_slot_h_base_start, scr_slot_h_base_wait, scr_slot_h_base_sloop, scr_slot_h_base_floop, scr_slot_h_base_wait, scr_slot_h_base_ej, scr_slot_h_base_wait]
            },
            scr_draw_special: scr_draw_slot_l_shrine,
            hand_x: [20],
            hand_y: [-78],
            hand_xscale: [-1],
            hand_angle: [0],
            hand_frames: 
            {
                frame_1: [0],
                frame_2: [0, 1, 4],
                frame_3: [2]
            },
            sp_spr: spr_sp_v_start,
            sq_x: 38,
            sq_y: [-30],
            sp_x: 38,
            sp_y: [-30],
            sp_anim_x: 0,
            sp_anim_y: 1
        },
        human_spr: 
        {
            mode: "fixed",
            phase_1: 
            {
                spr_array: [-1, spr_h_lilith_shrine_idle_head, spr_h_lilith_shrine_idle_breast, spr_h_lilith_hand, spr_h_lilith_shrine_idle_leg, -1],
                spr_c_array: [-1, -1, spr_h_lilith_shrine_idle_breast_c, spr_h_lilith_hand_c, spr_h_lilith_shrine_idle_leg_c, -1]
            },
            phase_2: 
            {
                spr_array: [-1, spr_h_lilith_shrine_loop_head, spr_h_lilith_shrine_loop_hand, spr_h_lilith_hand, spr_h_lilith_shrine_loop_leg, -1],
                spr_c_array: [-1, -1, spr_h_lilith_shrine_loop_hand, spr_h_lilith_hand_c, spr_h_lilith_shrine_loop_leg_c, -1]
            }
        },
        mon_spr: undefined
    };
    ds_map_add(global.cell_registry, 39, _cell);
    _cell.physical.sign_y_base = -92;
    _cell.physical.sign_y_jitter = 1;
    _cell.physical.slot_range = 1;
    _cell.physical.scr_slot_base = scr_slot_h_lilith_idle;
    _cell.physical.candle_index = 0;
    _cell.physical.dirt_fix_inc = true;
    _cell = 
    {
        h_type: 5,
        slot_type: 0,
        name: "BIRTH 1",
        physical: 
        {
            allow_preg: false,
            max_mon_num: 1,
            anal: false,
            spr_row_pos: 0,
            slot_dirt_init: -1,
            spr_slot_template: [[0, spr_slot_birth_back, false, -1], [5, spr_slot_birth_extra, false, -1], [10, -1, -2, -1, false, -1], [7, -1, -2, -1, false], [6, -1, -2, -1, false], [8, -1, -2, -1, false], [1, spr_slot_birth_sign, true, -1]],
            scr_slot_template: 
            {
                idle: scr_slot_h_birth_idle,
                h: [scr_slot_birth_spawn_loop, scr_slot_non_h_base_wait, scr_slot_birth_spawn_ej]
            },
            scr_draw_special: scr_draw_slot_parts,
            hand_x: [7],
            hand_y: [-34],
            hand_xscale: [1],
            hand_angle: [0],
            hand_frames: 
            {
                frame_2: [0],
                frame_3: [0]
            },
            sp_spr: -1,
            sq_x: -1,
            sq_y: [-1],
            sp_x: -1,
            sp_y: [-1],
            sp_anim_x: -1,
            sp_anim_y: -1
        },
        human_spr: 
        {
            mode: "base+class",
            base_body: "standard"
        },
        mon_spr: undefined
    };
    ds_map_add(global.cell_registry, 5, _cell);
    _cell.physical.sign_y_base = -84;
    _cell.physical.sign_y_jitter = 2;
    _cell = 
    {
        h_type: 12,
        slot_type: 0,
        name: "BIRTH 2",
        physical: 
        {
            allow_preg: false,
            max_mon_num: 1,
            anal: false,
            spr_row_pos: 0,
            slot_dirt_init: -1,
            spr_slot_template: [[0, spr_slot_birth_2_back, false, -1], [8, -1, -2, -1, false], [6, -1, -2, -1, false], [10, -1, -2, -1, false, -1], [5, spr_slot_birth_2_front, false, -1], [1, spr_slot_birth_2_sign, true, -1]],
            scr_slot_template: 
            {
                idle: scr_slot_h_birth_idle,
                h: [scr_slot_birth_spawn_loop, scr_slot_non_h_base_wait, scr_slot_birth_spawn_ej]
            },
            scr_draw_special: scr_draw_slot_parts,
            hand_x: [],
            hand_y: [],
            hand_xscale: [],
            hand_angle: [],
            sp_spr: -1,
            sq_x: -1,
            sq_y: [-1],
            sp_x: -1,
            sp_y: [-1],
            sp_anim_x: -1,
            sp_anim_y: -1
        },
        human_spr: 
        {
            mode: "base+class",
            base_body: "standard"
        },
        mon_spr: undefined
    };
    ds_map_add(global.cell_registry, 12, _cell);
    _cell.physical.sign_y_base = -84;
    _cell.physical.sign_y_jitter = 2;
    _cell = 
    {
        h_type: 4,
        slot_type: 0,
        name: "MILK 1",
        physical: 
        {
            allow_preg: false,
            max_mon_num: 1,
            anal: false,
            spr_row_pos: 0,
            slot_dirt_init: -1,
            spr_slot_template: [[0, spr_slot_milk_1_back, false, -1], [8, -1, false, -1, false], [6, -1, false, -1, false], [10, -1, -2, -1, false, -1], [2, spr_slot_milk_1_handc, true, -1], [7, -1, false, -1, false], [1, spr_slot_milk_1_sign, true, -1]],
            scr_slot_template: 
            {
                idle: scr_slot_h_milk_idle,
                h: [scr_slot_h_milk_loop]
            },
            scr_draw_special: scr_draw_slot_milk,
            hand_x: [8],
            hand_y: [-26],
            hand_xscale: [-1],
            hand_angle: [0],
            hand_frames: 
            {
                frame_2: [2],
                frame_3: [2]
            },
            sp_spr: -1,
            sq_x: -1,
            sq_y: [-1],
            sp_x: -1,
            sp_y: [-1],
            sp_anim_x: -1,
            sp_anim_y: -1
        },
        human_spr: 
        {
            mode: "base+class",
            base_body: "standard"
        },
        mon_spr: undefined
    };
    ds_map_add(global.cell_registry, 4, _cell);
    _cell.physical.sign_y_base = -84;
    _cell.physical.sign_y_jitter = 2;
    _cell.physical.milk_step = 0;
    _cell = 
    {
        h_type: 10,
        slot_type: 0,
        name: "DISPLAY",
        physical: 
        {
            allow_preg: false,
            max_mon_num: 1,
            anal: false,
            spr_row_pos: 0,
            slot_dirt_init: -1,
            spr_slot_template: [[0, spr_slot_display_back, false, -1], [11, -1, false, -1], [8, -1, false, -1, false], [6, -1, false, -1, true], [10, -1, -2, -1, false, -1], [1, spr_slot_display_sign, true, -1]],
            scr_slot_template: 
            {
                idle: scr_slot_display_idle
            },
            scr_draw_special: scr_draw_slot_parts,
            hand_x: [],
            hand_y: [],
            hand_xscale: [],
            hand_angle: [],
            sp_spr: -1,
            sq_x: -1,
            sq_y: [-1],
            sp_x: -1,
            sp_y: [-1],
            sp_anim_x: -1,
            sp_anim_y: -1
        },
        human_spr: 
        {
            mode: "base+class",
            base_body: "standard"
        },
        mon_spr: undefined
    };
    ds_map_add(global.cell_registry, 10, _cell);
    _cell.physical.sign_y_base = -84;
    _cell.physical.sign_y_jitter = 2;
    _cell = 
    {
        h_type: 11,
        slot_type: 0,
        name: "DRINK",
        physical: 
        {
            allow_preg: false,
            max_mon_num: 2,
            anal: false,
            spr_row_pos: 0,
            slot_dirt_init: -1,
            spr_slot_template: [[0, spr_slot_drink_back, false, -1], [2, spr_slot_drink_handc, true, -1], [7, -1, false, -1, false], [10, -1, -2, -1, false, -1], [6, -1, -2, -1, true], [1, spr_slot_drink_sign, true, -1]],
            scr_slot_template: 
            {
                idle: scr_slot_drink_idle,
                h: [scr_slot_h_drink_loop]
            },
            scr_draw_special: scr_draw_slot_drink,
            hand_x: [6],
            hand_y: [-48],
            hand_xscale: [-1],
            hand_angle: [0],
            hand_frames: 
            {
                frame_2: [3, 4],
                frame_3: [3, 4]
            },
            sp_spr: -1,
            sq_x: -1,
            sq_y: [-1],
            sp_x: -1,
            sp_y: [-1],
            sp_anim_x: -1,
            sp_anim_y: -1
        },
        human_spr: 
        {
            mode: "base+class",
            base_body: "standard"
        },
        mon_spr: undefined
    };
    ds_map_add(global.cell_registry, 11, _cell);
    _cell.physical.sign_y_base = -86;
    _cell.physical.sign_y_jitter = 2;
    _cell.physical.drink_num = 0;
    _cell.physical.mon_index = [0, 0];
    _cell.physical.slot_range = 3;
    _cell = 
    {
        h_type: 18,
        slot_type: 1,
        name: "G.BANG 2",
        physical: 
        {
            allow_preg: true,
            max_mon_num: 3,
            anal: false,
            spr_row_pos: 16,
            slot_dirt_init: 0,
            spr_slot_template: [[12, spr_dirt_big, false, -1, false], [10, -1, false, -1, false], [6, -1, -2, -1, false], [8, -1, false, -1, false], [0, spr_slot_gb_1_back, false, -1], [1, spr_slot_gb_sign, true, -1], [4, 0, true, -1]],
            scr_slot_template: 
            {
                idle: scr_slot_h_state_idle,
                h: [scr_slot_h_gb_1_sloop, scr_slot_h_gb_1_floop, scr_slot_h_gb_1_ej]
            },
            scr_draw_special: scr_draw_slot_gb_1,
            hand_x: [],
            hand_y: [],
            hand_xscale: [],
            hand_angle: [],
            sp_spr: spr_sp_v_start,
            sq_x: 22,
            sq_y: [-31, -33],
            sp_x: 22,
            sp_y: [-28, -33],
            sp_anim_x: 0,
            sp_anim_y: -1
        },
        human_spr: 
        {
            mode: "base+class",
            base_body: "big"
        },
        mon_spr: undefined
    };
    ds_map_add(global.cell_registry, 18, _cell);
    _cell.physical.sign_y_base = -84;
    _cell.physical.sign_y_jitter = 2;
    _cell.physical.set_timer = 0;
    _cell = 
    {
        h_type: 19,
        slot_type: 1,
        name: "G.BANG 1",
        physical: 
        {
            allow_preg: true,
            max_mon_num: 2,
            anal: false,
            spr_row_pos: 16,
            slot_dirt_init: 0,
            spr_slot_template: [[12, spr_dirt_big, false, -1, false], [0, spr_slot_gb_2_back, false, -1], [10, -1, false, -1, false], [6, -1, false, -1, true], [8, -1, false, -1, false], [1, spr_slot_gb_sign, true, -1]],
            scr_slot_template: 
            {
                idle: scr_slot_h_gb_2_idle,
                h: [scr_slot_h_gb_2_sloop, scr_slot_h_gb_2_floop, scr_slot_h_gb_2_ej]
            },
            scr_draw_special: scr_draw_slot_gb_2,
            hand_x: [],
            hand_y: [],
            hand_xscale: [],
            hand_angle: [],
            sp_spr: spr_sp_v_start,
            sq_x: 38,
            sq_y: [-14, -18],
            sp_x: 38,
            sp_y: [-14, -18],
            sp_anim_x: 0,
            sp_anim_y: 1
        },
        human_spr: 
        {
            mode: "base+class",
            base_body: "big"
        },
        mon_spr: undefined
    };
    ds_map_add(global.cell_registry, 19, _cell);
    _cell.physical.sign_y_base = -84;
    _cell.physical.sign_y_jitter = 2;
    _cell.physical.set_timer = 0;
    _cell.physical.sp_place_init = true;
    _cell = 
    {
        h_type: 23,
        slot_type: 1,
        name: "G.BANG 3",
        physical: 
        {
            allow_preg: true,
            max_mon_num: 2,
            anal: false,
            spr_row_pos: 16,
            slot_dirt_init: 0,
            spr_slot_template: [[12, spr_dirt_big, false, -1, false], [4, 0, true, -1], [0, spr_o_big, false, -1], [10, -1, false, -1, false], [6, -1, false, -1, false], [8, -1, false, -1, false], [1, spr_slot_gb_sign, true, -1]],
            scr_slot_template: 
            {
                idle: scr_slot_h_state_idle,
                h: [scr_slot_h_gb_3_sloop, scr_slot_h_gb_3_floop, scr_slot_h_gb_3_ej]
            },
            scr_draw_special: scr_draw_ogre_behind,
            hand_x: [],
            hand_y: [],
            hand_xscale: [],
            hand_angle: [],
            sp_spr: spr_sp_v_start,
            sq_x: 38,
            sq_y: [-19, -25],
            sp_x: 38,
            sp_y: [-19, -25],
            sp_anim_x: 0,
            sp_anim_y: -1
        },
        human_spr: 
        {
            mode: "base+class",
            base_body: "big"
        },
        mon_spr: undefined
    };
    ds_map_add(global.cell_registry, 23, _cell);
    _cell.physical.sign_y_base = -84;
    _cell.physical.sign_y_jitter = 2;
    _cell.physical.set_timer = 0;
    _cell = 
    {
        h_type: 36,
        slot_type: 1,
        name: "DAIRY",
        physical: 
        {
            allow_preg: true,
            max_mon_num: 2,
            anal: false,
            spr_row_pos: 0,
            slot_dirt_init: 0,
            spr_slot_template: [[12, spr_dirt_big, false, -1, false], [5, spr_slot_cow_extra, false, -1], [10, -1, -2, -1, false], [6, -1, -2, -1, false], [8, -1, false, -1, false], [7, -1, false, -1, false], [1, spr_slot_cow_sign, true, -1], [4, 0, true, -1]],
            scr_slot_template: 
            {
                idle: scr_slot_h_state_idle,
                h: [scr_slot_cow_state_idle, scr_slot_cow_state_loop, scr_slot_cow_state_floop, scr_slot_cow_state_ej]
            },
            scr_draw_special: scr_draw_slot_cow,
            hand_x: [],
            hand_y: [],
            hand_xscale: [],
            hand_angle: [],
            sp_spr: spr_sp_v_start,
            sq_x: 22,
            sq_y: [-30],
            sp_x: 22,
            sp_y: [-16],
            sp_anim_x: 0,
            sp_anim_y: 0
        },
        human_spr: undefined,
        mon_spr: undefined
    };
    ds_map_add(global.cell_registry, 36, _cell);
    _cell.human_spr = 
    {
        mode: "fixed",
        phase_1: 
        {
            spr_array: [-1, spr_cow_idle_head, spr_cow_breast, -1, -1, -1],
            spr_c_array: [-1, -1, -1, spr_cow_idle_hand, spr_cow_idle_leg, -1]
        },
        phase_2: 
        {
            spr_array: [-1, spr_cow_loop_head, spr_cow_breast, -1, -1, -1],
            spr_c_array: [-1, -1, -1, spr_cow_loop_hand, spr_cow_loop_leg, -1]
        }
    };
    _cell.physical.sign_y_base = -92;
    _cell.physical.sign_y_jitter = 1;
    _cell.physical.blink_spr = spr_cow_blink;
    _cell.physical.anim_struct_overrides = 
    {
        milk_index: -1,
        milk_timer: -1,
        milk_spd: -1,
        blink_index: -1,
        blink_timer: 0
    };
    _cell.physical.del_item_type = 2;
    _cell = 
    {
        h_type: 38,
        slot_type: 1,
        name: "CHAINS",
        physical: 
        {
            allow_preg: true,
            max_mon_num: 2,
            anal: false,
            spr_row_pos: 16,
            slot_dirt_init: 0,
            spr_slot_template: [[12, spr_dirt_big, false, -1, false], [0, spr_slot_chain_bg, false, -1], [5, spr_slot_chain_extra, false, -1], [6, -1, false, -1, false], [8, -1, false, -1, false], [1, spr_slot_chain_sign, true, -1]],
            scr_slot_template: 
            {
                idle: scr_slot_h_chain_idle,
                h: [scr_slot_h_chain_sloop, scr_slot_h_chain_floop, scr_slot_h_chain_ej]
            },
            scr_draw_special: scr_draw_slot_chain,
            hand_x: [],
            hand_y: [],
            hand_xscale: [],
            hand_angle: [],
            sp_spr: spr_sp_v_start,
            sq_x: [32, 42],
            sq_y: [-36, -36],
            sp_x: [32, 42],
            sp_y: [-36, -36],
            sp_anim_x: -1,
            sp_anim_y: 1
        },
        human_spr: 
        {
            mode: "fixed",
            phase_1: 
            {
                spr_array: [-1, -1, spr_h_morrigan_chain_idle_breast, -1, spr_h_morrigan_chain_idle_leg, -1],
                spr_c_array: [-1, -1, spr_h_morrigan_chain_idle_breast_c, -1, spr_h_morrigan_chain_idle_leg_c, -1]
            },
            phase_2: 
            {
                spr_array: [-1, -1, spr_h_morrigan_chain_loop_breast, -1, spr_h_morrigan_chain_loop_leg, -1],
                spr_c_array: [-1, -1, spr_h_morrigan_chain_loop_breast_c, -1, spr_h_morrigan_chain_loop_leg_c, -1]
            }
        },
        mon_spr: undefined
    };
    ds_map_add(global.cell_registry, 38, _cell);
    _cell.physical.sign_y_base = -84;
    _cell.physical.sign_y_jitter = 2;
    _cell.physical.set_timer = 0;
    _cell.physical.sp_place_init = true;
    _cell = 
    {
        h_type: 40,
        slot_type: 1,
        name: "S.SHRINE",
        physical: 
        {
            allow_preg: false,
            max_mon_num: 0,
            anal: false,
            spr_row_pos: 16,
            slot_dirt_init: -1,
            spr_slot_template: [[12, spr_dirt_big, false, -1, false], [0, spr_slot_v_shrine, false, -1]],
            scr_slot_template: 
            {
                idle: -1
            },
            scr_draw_special: scr_draw_slot_parts,
            hand_x: [],
            hand_y: [],
            hand_xscale: [],
            hand_angle: [],
            sp_spr: -1,
            sq_x: -1,
            sq_y: [-1],
            sp_x: -1,
            sp_y: [-1],
            sp_anim_x: -1,
            sp_anim_y: -1
        },
        human_spr: undefined,
        mon_spr: undefined
    };
    ds_map_add(global.cell_registry, 40, _cell);
    _cell.physical.slot_h = false;
    _cell.physical.death_fix_inc = true;
    _cell = 
    {
        h_type: 41,
        slot_type: 1,
        name: "F.SHRINE",
        physical: 
        {
            allow_preg: false,
            max_mon_num: 0,
            anal: false,
            spr_row_pos: 16,
            slot_dirt_init: -1,
            spr_slot_template: [[12, spr_dirt_big, false, -1, false], [0, spr_slot_f_shrine, false, -1], [14, 0, true, -1]],
            scr_slot_template: 
            {
                idle: -1
            },
            scr_draw_special: scr_draw_slot_parts,
            hand_x: [],
            hand_y: [],
            hand_xscale: [],
            hand_angle: [],
            sp_spr: -1,
            sq_x: -1,
            sq_y: [-1],
            sp_x: -1,
            sp_y: [-1],
            sp_anim_x: -1,
            sp_anim_y: -1
        },
        human_spr: undefined,
        mon_spr: undefined
    };
    ds_map_add(global.cell_registry, 41, _cell);
    _cell.physical.slot_h = false;
    _cell.physical.slot_range = 5;
    _cell = 
    {
        h_type: 42,
        slot_type: 1,
        name: "R.SHRINE",
        physical: 
        {
            allow_preg: false,
            max_mon_num: 0,
            anal: false,
            spr_row_pos: 16,
            slot_dirt_init: -1,
            spr_slot_template: [[12, spr_dirt_big, false, -1, false], [0, spr_slot_r_shrine, false, -1]],
            scr_slot_template: 
            {
                idle: -1
            },
            scr_draw_special: scr_draw_slot_parts,
            hand_x: [],
            hand_y: [],
            hand_xscale: [],
            hand_angle: [],
            sp_spr: -1,
            sq_x: -1,
            sq_y: [-1],
            sp_x: -1,
            sp_y: [-1],
            sp_anim_x: -1,
            sp_anim_y: -1
        },
        human_spr: undefined,
        mon_spr: undefined
    };
    ds_map_add(global.cell_registry, 42, _cell);
    _cell.physical.slot_h = false;
    _cell.physical.scr_slot_step = scr_slot_h_r_shrine_idle;
    _cell = 
    {
        h_type: 17,
        slot_type: 1,
        name: "CAGE",
        physical: 
        {
            allow_preg: false,
            max_mon_num: 2,
            anal: false,
            spr_row_pos: 16,
            slot_dirt_init: -1,
            spr_slot_template: [[5, spr_slot_carry_extra, false, -1], [8, -1, false, -1, false], [10, -1, false, -1, false], [6, -1, false, -1, false], [0, spr_slot_carry_back, false, -1], [1, spr_slot_carry_sign, true, -1]],
            scr_slot_template: 
            {
                idle: scr_slot_carry_idle,
                h: [scr_slot_carry_load, scr_slot_carry_active]
            },
            scr_draw_special: scr_draw_slot_carry,
            hand_x: [],
            hand_y: [],
            hand_xscale: [],
            hand_angle: [],
            sp_spr: -1,
            sq_x: -1,
            sq_y: [-1],
            sp_x: -1,
            sp_y: [-1],
            sp_anim_x: -1,
            sp_anim_y: -1
        },
        human_spr: 
        {
            mode: "base+class",
            base_body: "big"
        },
        mon_spr: undefined
    };
    ds_map_add(global.cell_registry, 17, _cell);
    _cell.physical.sign_y_base = -90;
    _cell.physical.sign_y_jitter = 2;
    _cell.physical.visual = true;
    _cell.physical.anim_struct_overrides = 
    {
        char_state: 0
    };
    _cell.physical.slot_range = 2;
    _cell.physical.scr_slot_step = scr_slot_state;
    _cell = 
    {
        h_type: 24,
        slot_type: 1,
        name: "DISPLAY_B",
        physical: 
        {
            allow_preg: false,
            max_mon_num: 1,
            anal: false,
            spr_row_pos: 16,
            slot_dirt_init: -1,
            spr_slot_template: [[8, -1, -2, -1, false], [10, -1, false, -1, false], [0, spr_slot_patrol_back, false, -1], [6, -1, -2, -1, false], [7, -1, -2, -1, false], [1, spr_slot_patrol_sign, true, -1]],
            scr_slot_template: 
            {
                idle: scr_slot_patrol_idle,
                h: [scr_slot_patrol_active]
            },
            scr_draw_special: scr_draw_slot_patrol,
            hand_x: [32],
            hand_y: [-71],
            hand_xscale: [1],
            hand_angle: [90],
            hand_frames: 
            {
                frame_1: [1]
            },
            sp_spr: -1,
            sq_x: -1,
            sq_y: [-1],
            sp_x: -1,
            sp_y: [-1],
            sp_anim_x: -1,
            sp_anim_y: -1
        },
        human_spr: 
        {
            mode: "base+class",
            base_body: "big"
        },
        mon_spr: undefined
    };
    ds_map_add(global.cell_registry, 24, _cell);
    _cell.physical.sign_y_base = -90;
    _cell.physical.sign_y_jitter = 2;
    _cell.physical.visual = true;
    _cell.physical.anim_struct_overrides = 
    {
        char_state: 0
    };
    _cell.physical.slot_range = 1;
    _cell = 
    {
        h_type: 25,
        slot_type: 1,
        name: "CLONE_B",
        physical: 
        {
            allow_preg: false,
            max_mon_num: 0,
            anal: false,
            spr_row_pos: 16,
            slot_dirt_init: -1,
            spr_slot_template: [[0, -1, false, -1], [1, spr_slot_clone_sign, true, -1]],
            scr_slot_template: 
            {
                idle: -1
            },
            scr_draw_special: scr_draw_slot_clone,
            hand_x: [],
            hand_y: [],
            hand_xscale: [],
            hand_angle: [],
            sp_spr: -1,
            sq_x: -1,
            sq_y: [-1],
            sp_x: -1,
            sp_y: [-1],
            sp_anim_x: -1,
            sp_anim_y: -1
        },
        human_spr: undefined,
        mon_spr: undefined
    };
    ds_map_add(global.cell_registry, 25, _cell);
    _cell.physical.sign_y_base = -84;
    _cell.physical.sign_y_jitter = 2;
    _cell.physical.slot_h = false;
    _cell.physical.scr_slot_step = scr_slot_h_clone_idle;
    _cell.physical.clone_wait = 0;
    _cell = 
    {
        h_type: 27,
        slot_type: 3,
        name: "BIND 1",
        physical: 
        {
            allow_preg: true,
            max_mon_num: 1,
            anal: false,
            spr_row_pos: 26,
            slot_dirt_init: -1,
            spr_slot_template: [[8, -1, false, -1, false], [10, -1, -2, -1, false, -1], [6, -1, false, -1, true], [0, spr_tent_front, false, -1]],
            scr_slot_template: 
            {
                idle: scr_slot_h_tent_idle,
                h: [scr_slot_h_tent_sloop, scr_slot_h_tent_floop, scr_slot_h_tent_ej, scr_slot_h_tent_birth, scr_slot_h_tent_birth_ej]
            },
            scr_draw_special: scr_draw_slot_tent,
            hand_x: [],
            hand_y: [],
            hand_xscale: [],
            hand_angle: [],
            sp_spr: spr_sp_v_start,
            sq_x: 22,
            sq_y: [-26],
            sp_x: 22,
            sp_y: [-26],
            sp_anim_x: 0,
            sp_anim_y: 1
        },
        human_spr: undefined,
        mon_spr: undefined
    };
    ds_map_add(global.cell_registry, 27, _cell);
    _cell.human_spr = 
    {
        mode: "base+class",
        base_body: "tent"
    };
    _cell.physical.slot_front = -1;
    _cell.physical.extra_spawn_part = true;
    _cell = 
    {
        h_type: 28,
        slot_type: 3,
        name: "BIND 2",
        physical: 
        {
            allow_preg: true,
            max_mon_num: 1,
            anal: false,
            spr_row_pos: 26,
            slot_dirt_init: -1,
            spr_slot_template: [[10, -1, -2, -1, false, -1], [6, -1, false, -1, true], [8, -1, false, -1, false], [0, spr_tent_front, false, -1]],
            scr_slot_template: 
            {
                idle: scr_slot_h_tent_idle,
                h: [scr_slot_h_tent_sloop, scr_slot_h_tent_floop, scr_slot_h_tent_ej, scr_slot_h_tent_birth, scr_slot_h_tent_birth_ej]
            },
            scr_draw_special: scr_draw_slot_tent,
            hand_x: [],
            hand_y: [],
            hand_xscale: [],
            hand_angle: [],
            sp_spr: spr_sp_v_start,
            sq_x: 22,
            sq_y: [-26],
            sp_x: 22,
            sp_y: [-25],
            sp_anim_x: 0,
            sp_anim_y: -1
        },
        human_spr: undefined,
        mon_spr: undefined
    };
    ds_map_add(global.cell_registry, 28, _cell);
    _cell.human_spr = 
    {
        mode: "base+class",
        base_body: "tent"
    };
    _cell.physical.slot_front = -1;
    _cell.physical.extra_spawn_part = true;
    _cell = 
    {
        h_type: 29,
        slot_type: 3,
        name: "T.WALL 3",
        physical: 
        {
            allow_preg: true,
            max_mon_num: 1,
            anal: false,
            spr_row_pos: 26,
            slot_dirt_init: -1,
            spr_slot_template: [[10, -1, -2, -1, false, -1], [8, -1, false, -1, false], [6, -1, false, -1, false], [0, spr_tent_front, false, -1]],
            scr_slot_template: 
            {
                idle: scr_slot_h_tent_idle,
                h: [scr_slot_h_tent_sloop, scr_slot_h_tent_floop, scr_slot_h_tent_ej, scr_slot_h_tent_birth, scr_slot_h_tent_birth_ej]
            },
            scr_draw_special: scr_draw_slot_tent,
            hand_x: [],
            hand_y: [],
            hand_xscale: [],
            hand_angle: [],
            sp_spr: spr_sp_v_start,
            sq_x: 22,
            sq_y: [-34],
            sp_x: 22,
            sp_y: [-34],
            sp_anim_x: 0,
            sp_anim_y: -1
        },
        human_spr: undefined,
        mon_spr: undefined
    };
    ds_map_add(global.cell_registry, 29, _cell);
    _cell.human_spr = 
    {
        mode: "base+class",
        base_body: "tent"
    };
    _cell.physical.slot_front = spr_slot_wall_tent;
    _cell.physical.extra_spawn_part = true;
    _cell = 
    {
        h_type: 31,
        slot_type: 3,
        name: "T.WALL 1",
        physical: 
        {
            allow_preg: true,
            max_mon_num: 1,
            anal: false,
            spr_row_pos: 26,
            slot_dirt_init: -1,
            spr_slot_template: [[8, -1, false, -1, false], [2, spr_empty, true, -1], [7, -1, false, -1, false], [3, spr_empty, true, -1], [9, -1, false, -1, false], [0, spr_tent_front, false, -1]],
            scr_slot_template: 
            {
                idle: scr_slot_h_tent_idle,
                h: [scr_slot_h_tent_sloop, scr_slot_h_tent_floop, scr_slot_h_tent_ej, scr_slot_h_tent_birth, scr_slot_h_tent_birth_ej]
            },
            scr_draw_special: scr_draw_slot_tent,
            hand_x: [4],
            hand_y: [-42],
            hand_xscale: [-1],
            hand_angle: [0],
            hand_frames: 
            {
                frame_1: [1],
                frame_2: [2, 3],
                frame_3: [2, 3],
                frame_4: [1]
            },
            sp_spr: spr_sp_v_start,
            sq_x: 22,
            sq_y: [-42],
            sp_x: 22,
            sp_y: [-42],
            sp_anim_x: 0,
            sp_anim_y: 1
        },
        human_spr: undefined,
        mon_spr: undefined
    };
    ds_map_add(global.cell_registry, 31, _cell);
    _cell.human_spr = 
    {
        mode: "base+class",
        base_body: "tent"
    };
    _cell.physical.slot_front = spr_slot_wall_tent;
    _cell.physical.extra_spawn_part = true;
    _cell = 
    {
        h_type: 32,
        slot_type: 3,
        name: "T.WALL 2",
        physical: 
        {
            allow_preg: true,
            max_mon_num: 1,
            anal: false,
            spr_row_pos: 26,
            slot_dirt_init: -1,
            spr_slot_template: [[8, -1, false, -1, false], [2, spr_empty, true, -1], [7, -1, false, -1, false], [3, spr_empty, true, -1], [9, -1, false, -1, false], [0, spr_tent_front, false, -1]],
            scr_slot_template: 
            {
                idle: scr_slot_h_tent_idle,
                h: [scr_slot_h_tent_sloop, scr_slot_h_tent_floop, scr_slot_h_tent_ej, scr_slot_h_tent_birth, scr_slot_h_tent_birth_ej]
            },
            scr_draw_special: scr_draw_slot_tent,
            hand_x: [4, 9],
            hand_y: [-43, -52],
            hand_xscale: [1, 1],
            hand_angle: [0, 90],
            hand_frames: 
            {
                frame_1: [1],
                frame_2: [2, 3],
                frame_3: [2, 3],
                frame_4: [1]
            },
            sp_spr: spr_sp_v_start,
            sq_x: 22,
            sq_y: [-40],
            sp_x: 22,
            sp_y: [-40],
            sp_anim_x: 0,
            sp_anim_y: -1
        },
        human_spr: undefined,
        mon_spr: undefined
    };
    ds_map_add(global.cell_registry, 32, _cell);
    _cell.human_spr = 
    {
        mode: "base+class",
        base_body: "tent"
    };
    _cell.physical.slot_front = spr_slot_wall_tent;
    _cell.physical.extra_spawn_part = true;
    _cell = 
    {
        h_type: 30,
        slot_type: 3,
        name: "MILK 2",
        physical: 
        {
            allow_preg: false,
            max_mon_num: 1,
            anal: false,
            spr_row_pos: 26,
            slot_dirt_init: -1,
            spr_slot_template: [[6, -1, false, -1, false], [10, -1, -2, -1, false, -1], [1, spr_slot_milk_2_sign, true, -1], [0, spr_tent_front, false, -1]],
            scr_slot_template: 
            {
                idle: scr_slot_h_milk_2_idle,
                h: [scr_slot_h_milk_2_loop]
            },
            scr_draw_special: scr_draw_slot_tent,
            hand_x: [],
            hand_y: [],
            hand_xscale: [],
            hand_angle: [],
            sp_spr: -1,
            sq_x: -1,
            sq_y: [-1],
            sp_x: -1,
            sp_y: [-1],
            sp_anim_x: -1,
            sp_anim_y: -1
        },
        human_spr: undefined,
        mon_spr: undefined
    };
    ds_map_add(global.cell_registry, 30, _cell);
    _cell.human_spr = 
    {
        mode: "base+class",
        base_body: "tent"
    };
    _cell.physical.sign_y_base = -84;
    _cell.physical.sign_y_jitter = 2;
    _cell.physical.slot_front = spr_slot_wall_tent_2;
    _cell.physical.milk_num = 0;
    _cell = 
    {
        h_type: 33,
        slot_type: 3,
        name: "RECOVER",
        physical: 
        {
            allow_preg: false,
            max_mon_num: 1,
            anal: false,
            spr_row_pos: 26,
            slot_dirt_init: -1,
            spr_slot_template: [[8, -1, false, -1, false], [10, -1, -2, -1, false, -1], [6, -1, false, -1, true], [1, spr_slot_recover_sign, true, -1], [0, spr_tent_front, false, -1]],
            scr_slot_template: 
            {
                idle: scr_slot_recover_idle
            },
            scr_draw_special: scr_draw_slot_tent,
            hand_x: [],
            hand_y: [],
            hand_xscale: [],
            hand_angle: [],
            sp_spr: -1,
            sq_x: -1,
            sq_y: [-1],
            sp_x: -1,
            sp_y: [-1],
            sp_anim_x: -1,
            sp_anim_y: -1
        },
        human_spr: undefined,
        mon_spr: undefined
    };
    ds_map_add(global.cell_registry, 33, _cell);
    _cell.human_spr = 
    {
        mode: "base+class",
        base_body: "tent"
    };
    _cell.physical.sign_y_base = -84;
    _cell.physical.sign_y_jitter = 2;
    _cell.physical.slot_front = spr_slot_wall_tent_2;
    _cell.physical.bar_glow_rep = 0;
    _cell = 
    {
        h_type: 34,
        slot_type: 3,
        name: "CLEAN",
        physical: 
        {
            allow_preg: false,
            max_mon_num: 0,
            anal: false,
            spr_row_pos: 26,
            slot_dirt_init: -1,
            spr_slot_template: [[0, spr_slot_clean_back, false, -1], [1, spr_slot_clean_sign, true, -1]],
            scr_slot_template: 
            {
                idle: -1
            },
            scr_draw_special: scr_draw_slot_parts,
            hand_x: [],
            hand_y: [],
            hand_xscale: [],
            hand_angle: [],
            sp_spr: -1,
            sq_x: -1,
            sq_y: [-1],
            sp_x: -1,
            sp_y: [-1],
            sp_anim_x: -1,
            sp_anim_y: -1
        },
        human_spr: undefined,
        mon_spr: undefined
    };
    ds_map_add(global.cell_registry, 34, _cell);
    _cell.physical.sign_y_base = -84;
    _cell.physical.sign_y_jitter = 2;
    _cell.physical.slot_front = -1;
    _cell.physical.slot_range = 2;
    _cell.physical.slot_h = false;
    _cell.physical.scr_slot_step = scr_slot_clean_idle;
    var _class = 
    {
        name: "peasant",
        is_special: false,
        has_hair: true,
        fap_mul: 1,
        bap_mul: 0,
        hand_sprite: -1,
        hand_color: -1,
        cape_sprite: -1,
        clothing_standard: 
        {
            phase_1: 
            {
                leg_1: 
                {
                    hair: spr_h_peasant_idle_hair,
                    head: spr_h_peasant_idle_head,
                    breast: spr_h_peasant_idle_breast,
                    leg: spr_h_peasant_idle_leg_1,
                    leg_part: spr_h_peasant_idle_leg_part
                },
                leg_2: 
                {
                    hair: spr_h_peasant_idle_hair,
                    head: spr_h_peasant_idle_head,
                    breast: spr_h_peasant_idle_breast,
                    leg: spr_h_peasant_idle_leg_2,
                    leg_part: spr_h_peasant_idle_leg_part
                }
            },
            phase_2: 
            {
                leg_1: 
                {
                    hair: spr_h_peasant_loop_hair,
                    head: spr_h_peasant_loop_head,
                    breast: spr_h_peasant_loop_breast,
                    leg: spr_h_peasant_loop_leg_1,
                    leg_part: spr_h_peasant_loop_leg_part
                },
                leg_2: 
                {
                    hair: spr_h_peasant_loop_hair,
                    head: spr_h_peasant_loop_head,
                    breast: spr_h_peasant_loop_breast,
                    leg: spr_h_peasant_loop_leg_2,
                    leg_part: spr_h_peasant_loop_leg_part
                }
            }
        },
        clothing_big: 
        {
            start: 
            {
                hair: spr_h_peasant_big_start_hair,
                head: spr_h_peasant_big_start_head,
                breast: spr_h_peasant_big_start_breast,
                leg_1: spr_h_peasant_big_start_leg_1,
                leg_2: spr_h_peasant_big_start_leg_2
            },
            idle: 
            {
                hair: spr_h_peasant_big_idle_hair,
                head: spr_h_peasant_big_idle_head,
                breast: spr_h_peasant_big_idle_breast,
                leg_1: spr_h_peasant_big_idle_leg_1,
                leg_2: spr_h_peasant_big_idle_leg_2
            },
            loop: 
            {
                hair: spr_h_peasant_big_loop_hair,
                head: spr_h_peasant_big_loop_head,
                breast: spr_h_peasant_big_loop_breast,
                leg_any: spr_h_peasant_big_loop_leg
            }
        },
        clothing_tent: 
        {
            phase_1: 
            {
                leg_any: 
                {
                    hair: spr_h_peasant_tent_idle_hair,
                    head: spr_h_peasant_tent_idle_head,
                    breast: spr_h_peasant_tent_idle_breast,
                    hand: -1,
                    leg: spr_h_peasant_tent_idle_leg,
                    leg_part: spr_h_peasant_tent_idle_leg_part
                }
            },
            phase_2: 
            {
                leg_1: 
                {
                    hair: spr_h_peasant_tent_loop_hair,
                    head: spr_h_peasant_tent_loop_head,
                    breast: spr_h_peasant_tent_loop_breast,
                    hand: -1,
                    leg: spr_h_peasant_tent_loop_leg_v1,
                    leg_part: spr_h_peasant_tent_loop_leg_part
                },
                leg_2: 
                {
                    hair: spr_h_peasant_tent_loop_hair,
                    head: spr_h_peasant_tent_loop_head,
                    breast: spr_h_peasant_tent_loop_breast,
                    hand: -1,
                    leg: spr_h_peasant_tent_loop_leg_v2,
                    leg_part: spr_h_peasant_tent_loop_leg_part
                }
            },
            phase_4: 
            {
                leg_any: 
                {
                    hair: spr_h_peasant_tent_birth_hair,
                    head: spr_h_peasant_tent_birth_head,
                    breast: spr_h_peasant_tent_birth_breast,
                    hand: -1,
                    leg: spr_h_peasant_tent_birth_leg,
                    leg_part: spr_h_peasant_tent_birth_leg_part
                }
            }
        }
    };
    ds_map_add(global.class_registry, 0, _class);
    _class = 
    {
        name: "cleric",
        is_special: false,
        has_hair: false,
        fap_mul: 1,
        bap_mul: 4,
        hand_sprite: -1,
        hand_color: spr_h_cleric_hand,
        cape_sprite: -1,
        clothing_standard: 
        {
            phase_1: 
            {
                leg_1: 
                {
                    hair: -1,
                    head: spr_h_cleric_idle_head,
                    breast: spr_h_cleric_idle_breast,
                    leg: spr_h_cleric_idle_leg_1,
                    leg_part: spr_h_cleric_idle_leg_part
                },
                leg_2: 
                {
                    hair: -1,
                    head: spr_h_cleric_idle_head,
                    breast: spr_h_cleric_idle_breast,
                    leg: spr_h_cleric_idle_leg_2,
                    leg_part: spr_h_cleric_idle_leg_part
                }
            },
            phase_2: 
            {
                leg_1: 
                {
                    hair: -1,
                    head: spr_h_cleric_loop_head,
                    breast: spr_h_cleric_loop_breast,
                    leg: spr_h_cleric_loop_leg_1,
                    leg_part: spr_h_cleric_loop_leg_part
                },
                leg_2: 
                {
                    hair: -1,
                    head: spr_h_cleric_loop_head,
                    breast: spr_h_cleric_loop_breast,
                    leg: spr_h_cleric_loop_leg_2,
                    leg_part: spr_h_cleric_loop_leg_part
                }
            }
        },
        clothing_big: 
        {
            start: 
            {
                head: spr_h_cleric_big_start_head,
                breast: spr_h_cleric_big_start_breast,
                leg_any: spr_h_cleric_big_start_leg
            },
            idle: 
            {
                head: spr_h_cleric_big_idle_head,
                breast: spr_h_cleric_big_idle_breast,
                leg_any: spr_h_cleric_big_idle_leg
            },
            loop: 
            {
                head: spr_h_cleric_big_loop_head,
                breast: spr_h_cleric_big_loop_breast,
                leg_any: spr_h_cleric_big_loop_leg
            }
        },
        clothing_tent: 
        {
            phase_1: 
            {
                leg_any: 
                {
                    hair: -1,
                    head: spr_h_cleric_tent_idle_head,
                    breast: spr_h_cleric_tent_idle_breast,
                    hand: spr_h_cleric_hand,
                    leg: spr_h_cleric_tent_idle_leg,
                    leg_part: spr_h_cleric_tent_idle_leg_part
                }
            },
            phase_2: 
            {
                leg_any: 
                {
                    hair: -1,
                    head: spr_h_cleric_tent_loop_head,
                    breast: spr_h_cleric_tent_loop_breast,
                    hand: spr_h_cleric_hand,
                    leg: spr_h_cleric_tent_loop_leg,
                    leg_part: spr_h_cleric_tent_loop_leg_part
                }
            },
            phase_4: 
            {
                leg_any: 
                {
                    hair: -1,
                    head: spr_h_cleric_tent_birth_head,
                    breast: spr_h_cleric_tent_birth_breast,
                    hand: spr_h_cleric_hand,
                    leg: spr_h_cleric_tent_birth_leg,
                    leg_part: spr_h_cleric_tent_birth_leg_part
                }
            }
        }
    };
    ds_map_add(global.class_registry, 1, _class);
    _class = 
    {
        name: "knight",
        is_special: false,
        has_hair: true,
        fap_mul: 3,
        bap_mul: 1,
        hand_sprite: -1,
        hand_color: spr_h_knight_hand,
        cape_sprite: -1,
        clothing_standard: 
        {
            phase_1: 
            {
                leg_1: 
                {
                    hair: spr_h_knight_idle_hair,
                    head: spr_h_knight_idle_head,
                    breast: spr_h_knight_idle_breast,
                    leg: spr_h_knight_idle_leg_1,
                    leg_part: spr_h_knight_idle_leg_part
                },
                leg_2: 
                {
                    hair: spr_h_knight_idle_hair,
                    head: spr_h_knight_idle_head,
                    breast: spr_h_knight_idle_breast,
                    leg: spr_h_knight_idle_leg_2,
                    leg_part: spr_h_knight_idle_leg_part
                }
            },
            phase_2: 
            {
                leg_1: 
                {
                    hair: spr_h_knight_loop_hair,
                    head: spr_h_knight_loop_head,
                    breast: spr_h_knight_loop_breast,
                    leg: spr_h_knight_loop_leg_1,
                    leg_part: spr_h_knight_loop_leg_part
                },
                leg_2: 
                {
                    hair: spr_h_knight_loop_hair,
                    head: spr_h_knight_loop_head,
                    breast: spr_h_knight_loop_breast,
                    leg: spr_h_knight_loop_leg_2,
                    leg_part: spr_h_knight_loop_leg_part
                }
            }
        },
        clothing_big: 
        {
            start: 
            {
                hair: spr_h_knight_big_start_hair,
                head: spr_h_knight_big_start_head,
                breast: spr_h_knight_big_start_breast,
                leg_any: spr_h_knight_big_start_leg
            },
            idle: 
            {
                hair: spr_h_knight_big_idle_hair,
                head: spr_h_knight_big_idle_head,
                breast: spr_h_knight_big_idle_breast,
                leg_1: spr_h_knight_big_idle_leg_1,
                leg_2: spr_h_knight_big_idle_leg_2
            },
            loop: 
            {
                hair: spr_h_knight_big_loop_hair,
                head: spr_h_knight_big_loop_head,
                breast: spr_h_knight_big_loop_breast,
                leg_any: spr_h_knight_big_loop_leg
            }
        },
        clothing_tent: 
        {
            phase_1: 
            {
                leg_1: 
                {
                    hair: spr_h_knight_tent_idle_hair,
                    head: spr_h_knight_tent_idle_head,
                    breast: spr_h_knight_tent_idle_breast,
                    hand: spr_h_knight_hand,
                    leg: spr_h_knight_tent_idle_leg_v1,
                    leg_part: spr_h_knight_tent_idle_leg_part
                },
                leg_2: 
                {
                    hair: spr_h_knight_tent_idle_hair,
                    head: spr_h_knight_tent_idle_head,
                    breast: spr_h_knight_tent_idle_breast,
                    hand: spr_h_knight_hand,
                    leg: spr_h_knight_tent_idle_leg_v2,
                    leg_part: spr_h_knight_tent_idle_leg_part
                }
            },
            phase_2: 
            {
                leg_1: 
                {
                    hair: spr_h_knight_tent_loop_hair,
                    head: spr_h_knight_tent_loop_head,
                    breast: spr_h_knight_tent_loop_breast,
                    hand: spr_h_knight_hand,
                    leg: spr_h_knight_tent_loop_leg_v1,
                    leg_part: spr_h_knight_tent_loop_leg_part
                },
                leg_2: 
                {
                    hair: spr_h_knight_tent_loop_hair,
                    head: spr_h_knight_tent_loop_head,
                    breast: spr_h_knight_tent_loop_breast,
                    hand: spr_h_knight_hand,
                    leg: spr_h_knight_tent_loop_leg_v2,
                    leg_part: spr_h_knight_tent_loop_leg_part
                }
            },
            phase_4: 
            {
                leg_1: 
                {
                    hair: spr_h_knight_tent_birth_hair,
                    head: spr_h_knight_tent_birth_head,
                    breast: spr_h_knight_tent_birth_breast,
                    hand: spr_h_knight_hand,
                    leg: spr_h_knight_tent_birth_leg_v1,
                    leg_part: spr_h_knight_tent_birth_leg_part
                },
                leg_2: 
                {
                    hair: spr_h_knight_tent_birth_hair,
                    head: spr_h_knight_tent_birth_head,
                    breast: spr_h_knight_tent_birth_breast,
                    hand: spr_h_knight_hand,
                    leg: spr_h_knight_tent_birth_leg_v2,
                    leg_part: spr_h_knight_tent_birth_leg_part
                }
            }
        }
    };
    ds_map_add(global.class_registry, 2, _class);
    _class = 
    {
        name: "ranger",
        is_special: false,
        has_hair: false,
        fap_mul: 2,
        bap_mul: 5,
        hand_sprite: -1,
        hand_color: spr_h_ranger_hand,
        cape_sprite: -1,
        clothing_standard: 
        {
            phase_1: 
            {
                cape: spr_h_ranger_idle_cape,
                leg_1: 
                {
                    hair: -1,
                    head: spr_h_ranger_idle_head,
                    breast: spr_h_ranger_idle_breast,
                    leg: spr_h_ranger_idle_leg_1,
                    leg_part: spr_h_ranger_idle_leg_part
                },
                leg_2: 
                {
                    hair: -1,
                    head: spr_h_ranger_idle_head,
                    breast: spr_h_ranger_idle_breast,
                    leg: spr_h_ranger_idle_leg_2,
                    leg_part: spr_h_ranger_idle_leg_part
                }
            },
            phase_2: 
            {
                cape: spr_h_ranger_loop_cape,
                leg_1: 
                {
                    hair: -1,
                    head: spr_h_ranger_loop_head,
                    breast: spr_h_ranger_loop_breast,
                    leg: spr_h_ranger_loop_leg_1,
                    leg_part: spr_h_ranger_loop_leg_part
                },
                leg_2: 
                {
                    hair: -1,
                    head: spr_h_ranger_loop_head,
                    breast: spr_h_ranger_loop_breast,
                    leg: spr_h_ranger_loop_leg_2,
                    leg_part: spr_h_ranger_loop_leg_part
                }
            }
        },
        clothing_big: 
        {
            start: 
            {
                head: spr_h_ranger_big_start_head,
                breast: spr_h_ranger_big_start_breast,
                leg_any: spr_h_ranger_big_start_leg
            },
            idle: 
            {
                head: spr_h_ranger_big_idle_head,
                breast: spr_h_ranger_big_idle_breast,
                leg_1: spr_h_ranger_big_idle_leg_1,
                leg_2: spr_h_ranger_big_idle_leg_2
            },
            loop: 
            {
                head: spr_h_ranger_big_loop_head,
                breast: spr_h_ranger_big_loop_breast,
                leg_any: spr_h_ranger_big_loop_leg
            }
        },
        clothing_tent: 
        {
            phase_1: 
            {
                leg_1: 
                {
                    hair: -1,
                    head: spr_h_ranger_tent_idle_head,
                    breast: spr_h_ranger_tent_idle_breast,
                    hand: spr_h_ranger_hand,
                    leg: spr_h_ranger_tent_idle_leg_v1,
                    leg_part: spr_h_ranger_tent_idle_leg_part
                },
                leg_2: 
                {
                    hair: -1,
                    head: spr_h_ranger_tent_idle_head,
                    breast: spr_h_ranger_tent_idle_breast,
                    hand: spr_h_ranger_hand,
                    leg: spr_h_ranger_tent_idle_leg_v2,
                    leg_part: spr_h_ranger_tent_idle_leg_part
                }
            },
            phase_2: 
            {
                leg_1: 
                {
                    hair: -1,
                    head: spr_h_ranger_tent_loop_head,
                    breast: spr_h_ranger_tent_loop_breast,
                    hand: spr_h_ranger_hand,
                    leg: spr_h_ranger_tent_loop_leg_v1,
                    leg_part: spr_h_ranger_tent_loop_leg_part
                },
                leg_2: 
                {
                    hair: -1,
                    head: spr_h_ranger_tent_loop_head,
                    breast: spr_h_ranger_tent_loop_breast,
                    hand: spr_h_ranger_hand,
                    leg: spr_h_ranger_tent_loop_leg_v2,
                    leg_part: spr_h_ranger_tent_loop_leg_part
                }
            },
            phase_4: 
            {
                leg_1: 
                {
                    hair: -1,
                    head: spr_h_ranger_tent_birth_head,
                    breast: spr_h_ranger_tent_birth_breast,
                    hand: spr_h_ranger_hand,
                    leg: spr_h_ranger_tent_birth_leg_v1,
                    leg_part: spr_h_ranger_tent_birth_leg_part
                },
                leg_2: 
                {
                    hair: -1,
                    head: spr_h_ranger_tent_birth_head,
                    breast: spr_h_ranger_tent_birth_breast,
                    hand: spr_h_ranger_hand,
                    leg: spr_h_ranger_tent_birth_leg_v2,
                    leg_part: spr_h_ranger_tent_birth_leg_part
                }
            }
        }
    };
    ds_map_add(global.class_registry, 3, _class);
    _class = 
    {
        name: "nun",
        is_special: false,
        has_hair: false,
        fap_mul: 0,
        bap_mul: 2,
        hand_sprite: -1,
        hand_color: -1,
        cape_sprite: -1,
        clothing_standard: 
        {
            phase_1: 
            {
                leg_1: 
                {
                    hair: -1,
                    head: spr_h_nun_idle_head,
                    breast: spr_h_nun_idle_breast,
                    leg: spr_h_nun_idle_leg_1,
                    leg_part: spr_h_nun_idle_leg_part
                },
                leg_2: 
                {
                    hair: -1,
                    head: spr_h_nun_idle_head,
                    breast: spr_h_nun_idle_breast,
                    leg: spr_h_nun_idle_leg_2,
                    leg_part: spr_h_nun_idle_leg_part
                }
            },
            phase_2: 
            {
                leg_1: 
                {
                    hair: -1,
                    head: spr_h_nun_loop_head,
                    breast: spr_h_nun_loop_breast,
                    leg: spr_h_nun_loop_leg_1,
                    leg_part: spr_h_nun_loop_leg_part
                },
                leg_2: 
                {
                    hair: -1,
                    head: spr_h_nun_loop_head,
                    breast: spr_h_nun_loop_breast,
                    leg: spr_h_nun_loop_leg_2,
                    leg_part: spr_h_nun_loop_leg_part
                }
            }
        },
        clothing_big: 
        {
            start: 
            {
                head: spr_h_nun_big_start_head,
                breast: spr_h_nun_big_start_breast,
                leg_any: spr_h_nun_big_start_leg
            },
            idle: 
            {
                head: spr_h_nun_big_idle_head,
                breast: spr_h_nun_big_idle_breast,
                leg_1: spr_h_nun_big_idle_leg_1,
                leg_2: spr_h_nun_big_idle_leg_2
            },
            loop: 
            {
                head: spr_h_nun_big_loop_head,
                breast: spr_h_nun_big_loop_breast,
                leg_any: spr_h_nun_big_loop_leg
            }
        },
        clothing_tent: 
        {
            phase_1: 
            {
                leg_1: 
                {
                    hair: -1,
                    head: spr_h_nun_tent_idle_head,
                    breast: spr_h_nun_tent_idle_breast,
                    hand: -1,
                    leg: spr_h_nun_tent_idle_leg_v1,
                    leg_part: spr_h_nun_tent_idle_leg_part
                },
                leg_2: 
                {
                    hair: -1,
                    head: spr_h_nun_tent_idle_head,
                    breast: spr_h_nun_tent_idle_breast,
                    hand: -1,
                    leg: spr_h_nun_tent_idle_leg_v2,
                    leg_part: spr_h_nun_tent_idle_leg_part
                }
            },
            phase_2: 
            {
                leg_1: 
                {
                    hair: -1,
                    head: spr_h_nun_tent_loop_head,
                    breast: spr_h_nun_tent_loop_breast,
                    hand: -1,
                    leg: spr_h_nun_tent_loop_leg_v1,
                    leg_part: spr_h_nun_tent_loop_leg_part
                },
                leg_2: 
                {
                    hair: -1,
                    head: spr_h_nun_tent_loop_head,
                    breast: spr_h_nun_tent_loop_breast,
                    hand: -1,
                    leg: spr_h_nun_tent_loop_leg_v2,
                    leg_part: spr_h_nun_tent_loop_leg_part
                }
            },
            phase_4: 
            {
                leg_1: 
                {
                    hair: -1,
                    head: spr_h_nun_tent_birth_head,
                    breast: spr_h_nun_tent_birth_breast,
                    hand: -1,
                    leg: spr_h_nun_tent_birth_leg_v1,
                    leg_part: spr_h_nun_tent_birth_leg_part
                },
                leg_2: 
                {
                    hair: -1,
                    head: spr_h_nun_tent_birth_head,
                    breast: spr_h_nun_tent_birth_breast,
                    hand: -1,
                    leg: spr_h_nun_tent_birth_leg_v2,
                    leg_part: spr_h_nun_tent_birth_leg_part
                }
            }
        }
    };
    ds_map_add(global.class_registry, 4, _class);
    _class = 
    {
        name: "samurai",
        is_special: false,
        has_hair: true,
        fap_mul: 6,
        bap_mul: 2,
        hand_sprite: -1,
        hand_color: spr_h_samurai_hand,
        cape_sprite: -1,
        clothing_standard: 
        {
            phase_1: 
            {
                leg_1: 
                {
                    hair: spr_h_samurai_idle_hair,
                    head: spr_h_samurai_idle_head,
                    breast: spr_h_samurai_idle_breast,
                    leg: spr_h_samurai_idle_leg_1,
                    leg_part: spr_h_samurai_idle_leg_part
                },
                leg_2: 
                {
                    hair: spr_h_samurai_idle_hair,
                    head: spr_h_samurai_idle_head,
                    breast: spr_h_samurai_idle_breast,
                    leg: spr_h_samurai_idle_leg_2,
                    leg_part: spr_h_samurai_idle_leg_part
                }
            },
            phase_2: 
            {
                leg_1: 
                {
                    hair: spr_h_samurai_loop_hair,
                    head: spr_h_samurai_loop_head,
                    breast: spr_h_samurai_loop_breast,
                    leg: spr_h_samurai_loop_leg_1,
                    leg_part: spr_h_samurai_loop_leg_part
                },
                leg_2: 
                {
                    hair: spr_h_samurai_loop_hair,
                    head: spr_h_samurai_loop_head,
                    breast: spr_h_samurai_loop_breast,
                    leg: spr_h_samurai_loop_leg_2,
                    leg_part: spr_h_samurai_loop_leg_part
                }
            }
        },
        clothing_big: 
        {
            start: 
            {
                hair: spr_h_samurai_big_start_hair,
                head: spr_h_samurai_big_start_head,
                breast: spr_h_samurai_big_start_breast,
                leg_any: spr_h_samurai_big_start_leg
            },
            idle: 
            {
                hair: spr_h_samurai_big_idle_hair,
                head: spr_h_samurai_big_idle_head,
                breast: spr_h_samurai_big_idle_breast,
                leg_1: spr_h_samurai_big_idle_leg_1,
                leg_2: spr_h_samurai_big_idle_leg_2
            },
            loop: 
            {
                hair: spr_h_samurai_big_loop_hair,
                head: spr_h_samurai_big_loop_head,
                breast: spr_h_samurai_big_loop_breast,
                leg_any: spr_h_samurai_big_loop_leg
            }
        },
        clothing_tent: 
        {
            phase_1: 
            {
                leg_1: 
                {
                    hair: spr_h_samurai_tent_idle_hair,
                    head: spr_h_samurai_tent_idle_head,
                    breast: spr_h_samurai_tent_idle_breast,
                    hand: spr_h_samurai_hand,
                    leg: spr_h_samurai_tent_idle_leg_v1,
                    leg_part: spr_h_samurai_tent_idle_leg_part
                },
                leg_2: 
                {
                    hair: spr_h_samurai_tent_idle_hair,
                    head: spr_h_samurai_tent_idle_head,
                    breast: spr_h_samurai_tent_idle_breast,
                    hand: spr_h_samurai_hand,
                    leg: spr_h_samurai_tent_idle_leg_v2,
                    leg_part: spr_h_samurai_tent_idle_leg_part
                }
            },
            phase_2: 
            {
                leg_1: 
                {
                    hair: spr_h_samurai_tent_loop_hair,
                    head: spr_h_samurai_tent_loop_head,
                    breast: spr_h_samurai_tent_loop_breast,
                    hand: spr_h_samurai_hand,
                    leg: spr_h_samurai_tent_loop_leg_v1,
                    leg_part: spr_h_samurai_tent_loop_leg_part
                },
                leg_2: 
                {
                    hair: spr_h_samurai_tent_loop_hair,
                    head: spr_h_samurai_tent_loop_head,
                    breast: spr_h_samurai_tent_loop_breast,
                    hand: spr_h_samurai_hand,
                    leg: spr_h_samurai_tent_loop_leg_v2,
                    leg_part: spr_h_samurai_tent_loop_leg_part
                }
            },
            phase_4: 
            {
                leg_1: 
                {
                    hair: spr_h_samurai_tent_birth_hair,
                    head: spr_h_samurai_tent_birth_head,
                    breast: spr_h_samurai_tent_birth_breast,
                    hand: spr_h_samurai_hand,
                    leg: spr_h_samurai_tent_birth_leg_v1,
                    leg_part: spr_h_samurai_tent_birth_leg_part
                },
                leg_2: 
                {
                    hair: spr_h_samurai_tent_birth_hair,
                    head: spr_h_samurai_tent_birth_head,
                    breast: spr_h_samurai_tent_birth_breast,
                    hand: spr_h_samurai_hand,
                    leg: spr_h_samurai_tent_birth_leg_v2,
                    leg_part: spr_h_samurai_tent_birth_leg_part
                }
            }
        }
    };
    ds_map_add(global.class_registry, 5, _class);
    _class = 
    {
        name: "mage",
        is_special: false,
        has_hair: true,
        fap_mul: 1,
        bap_mul: 2,
        hand_sprite: -1,
        hand_color: -1,
        cape_sprite: -1,
        clothing_standard: 
        {
            phase_1: 
            {
                leg_any: 
                {
                    hair: spr_h_mage_idle_hair,
                    head: spr_h_mage_idle_head,
                    breast: spr_h_mage_idle_breast,
                    leg: spr_h_mage_idle_leg,
                    leg_part: spr_h_mage_idle_leg_part
                }
            },
            phase_2: 
            {
                leg_any: 
                {
                    hair: spr_h_mage_loop_hair,
                    head: spr_h_mage_loop_head,
                    breast: spr_h_mage_loop_breast,
                    leg: spr_h_mage_loop_leg,
                    leg_part: spr_h_mage_loop_leg_part
                }
            }
        },
        clothing_big: 
        {
            start: 
            {
                hair: spr_h_shaman_big_start_hair,
                head: spr_h_shaman_big_start_head,
                breast: spr_h_shaman_big_start_breast,
                leg_any: spr_h_shaman_big_start_leg
            },
            idle: 
            {
                hair: spr_h_shaman_big_idle_hair,
                head: spr_h_shaman_big_idle_head,
                breast: spr_h_shaman_big_idle_breast,
                leg_any: spr_h_shaman_big_idle_leg
            },
            loop: 
            {
                hair: spr_h_shaman_big_loop_hair,
                head: spr_h_shaman_big_loop_head,
                breast: spr_h_shaman_big_loop_breast,
                leg_any: spr_h_shaman_big_loop_leg
            }
        },
        clothing_tent: 
        {
            phase_1: 
            {
                leg_any: 
                {
                    hair: spr_h_mage_tent_idle_hair,
                    head: spr_h_mage_tent_idle_head,
                    breast: spr_h_mage_tent_idle_breast,
                    hand: -1,
                    leg: spr_h_mage_tent_idle_leg,
                    leg_part: spr_h_mage_tent_idle_leg_part
                }
            },
            phase_2: 
            {
                leg_any: 
                {
                    hair: spr_h_mage_tent_loop_hair,
                    head: spr_h_mage_tent_loop_head,
                    breast: spr_h_mage_tent_loop_breast,
                    hand: -1,
                    leg: spr_h_mage_tent_loop_leg,
                    leg_part: spr_h_mage_tent_loop_leg_part
                }
            },
            phase_4: 
            {
                leg_any: 
                {
                    hair: spr_h_mage_tent_birth_hair,
                    head: spr_h_mage_tent_birth_head,
                    breast: spr_h_mage_tent_birth_breast,
                    hand: -1,
                    leg: spr_h_mage_tent_birth_leg,
                    leg_part: spr_h_mage_tent_birth_leg_part
                }
            }
        }
    };
    ds_map_add(global.class_registry, 6, _class);
    _class = 
    {
        name: "warrior",
        is_special: false,
        has_hair: false,
        fap_mul: 5,
        bap_mul: 0,
        hand_sprite: -1,
        hand_color: spr_h_warrior_hand,
        cape_sprite: -1,
        clothing_standard: 
        {
            phase_1: 
            {
                leg_any: 
                {
                    hair: -1,
                    head: spr_h_warrior_idle_head,
                    breast: spr_h_warrior_idle_breast,
                    leg: spr_h_warrior_idle_leg,
                    leg_part: spr_h_warrior_idle_leg_part
                }
            },
            phase_2: 
            {
                leg_any: 
                {
                    hair: -1,
                    head: spr_h_warrior_loop_head,
                    breast: spr_h_warrior_loop_breast,
                    leg: spr_h_warrior_loop_leg,
                    leg_part: spr_h_warrior_loop_leg_part
                }
            }
        },
        clothing_big: 
        {
            start: 
            {
                head: spr_h_warrior_big_start_head,
                breast: spr_h_warrior_big_start_breast,
                leg_any: spr_h_warrior_big_start_leg
            },
            idle: 
            {
                head: spr_h_warrior_big_idle_head,
                breast: spr_h_warrior_big_idle_breast,
                leg_any: spr_h_warrior_big_idle_leg
            },
            loop: 
            {
                head: spr_h_warrior_big_loop_head,
                breast: spr_h_warrior_big_loop_breast,
                leg_any: spr_h_warrior_big_loop_leg
            }
        },
        clothing_tent: 
        {
            phase_1: 
            {
                leg_any: 
                {
                    hair: -1,
                    head: spr_h_warrior_tent_idle_head,
                    breast: spr_h_warrior_tent_idle_breast,
                    hand: spr_h_warrior_hand,
                    leg: spr_h_warrior_tent_idle_leg,
                    leg_part: spr_h_warrior_tent_idle_leg_part
                }
            },
            phase_2: 
            {
                leg_any: 
                {
                    hair: -1,
                    head: spr_h_warrior_tent_loop_head,
                    breast: spr_h_warrior_tent_loop_breast,
                    hand: spr_h_warrior_hand,
                    leg: spr_h_warrior_tent_loop_leg,
                    leg_part: spr_h_warrior_tent_loop_leg_part
                }
            },
            phase_4: 
            {
                leg_any: 
                {
                    hair: -1,
                    head: spr_h_warrior_tent_birth_head,
                    breast: spr_h_warrior_tent_birth_breast,
                    hand: spr_h_warrior_hand,
                    leg: spr_h_warrior_tent_birth_leg,
                    leg_part: spr_h_warrior_tent_birth_leg_part
                }
            }
        }
    };
    ds_map_add(global.class_registry, 7, _class);
    _class = 
    {
        name: "cow",
        is_special: true,
        clothing_standard: 
        {
            phase_1: 
            {
                spr_array: [-1, spr_h_base_idle_head_cow, spr_h_base_idle_breast_cow, spr_h_cow_hand, spr_h_base_idle_leg_cow, spr_h_base_idle_leg_part_cow, spr_h_base_idle_cape_cow],
                spr_c_array: [-1, spr_h_base_idle_head_cow, spr_h_base_idle_breast_c_cow, spr_h_cow_hand_c, spr_h_base_idle_leg_c_cow, spr_h_base_idle_leg_part_c_cow]
            },
            phase_2: 
            {
                spr_array: [-1, spr_h_base_loop_head_cow, spr_h_base_loop_breast_cow, spr_h_cow_hand, spr_h_base_loop_leg_cow, spr_h_base_loop_leg_part_cow, spr_h_base_loop_cape_cow],
                spr_c_array: [-1, spr_h_base_loop_head_cow, spr_h_base_loop_breast_c_cow, spr_h_cow_hand_c, spr_h_base_loop_leg_c_cow, spr_h_base_loop_leg_part_c_cow]
            }
        },
        clothing_big: 
        {
            phase_0: 
            {
                spr_array: [-1, spr_h_cow_big_start_head, spr_h_cow_big_start_breast, spr_h_cow_hand, spr_h_cow_big_start_leg, -1],
                spr_c_array: [-1, spr_h_cow_big_start_head, spr_h_cow_big_start_breast_c, spr_h_cow_hand_c, spr_h_cow_big_start_leg_c, -1]
            },
            phase_1: 
            {
                spr_array: [-1, spr_h_cow_big_idle_head, spr_h_cow_big_idle_breast, spr_h_cow_hand, spr_h_cow_big_idle_leg, -1],
                spr_c_array: [-1, spr_h_cow_big_idle_head, spr_h_cow_big_idle_breast_c, spr_h_cow_hand_c, spr_h_cow_big_idle_leg_c, -1]
            },
            phase_2: 
            {
                spr_array: [-1, spr_h_cow_big_loop_head, spr_h_cow_big_loop_breast, spr_h_cow_hand, spr_h_cow_big_loop_leg, -1],
                spr_c_array: [-1, spr_h_cow_big_loop_head, spr_h_cow_big_loop_breast_c, spr_h_cow_hand_c, spr_h_cow_big_loop_leg_c, -1]
            }
        },
        clothing_tent: 
        {
            phase_1: 
            {
                spr_array: [-1, spr_h_cow_tent_idle_head, spr_h_cow_tent_idle_breast, spr_h_cow_hand, spr_h_cow_tent_idle_leg, spr_h_cow_tent_idle_leg_part],
                spr_c_array: [-1, spr_h_cow_tent_idle_head, spr_h_cow_tent_idle_breast_c, spr_h_cow_hand_c, spr_h_cow_tent_idle_leg_c, spr_h_cow_tent_idle_leg_part_c]
            },
            phase_2: 
            {
                spr_array: [-1, spr_h_cow_tent_loop_head, spr_h_cow_tent_loop_breast, spr_h_cow_hand, spr_h_cow_tent_loop_leg, spr_h_cow_tent_loop_leg_part],
                spr_c_array: [-1, spr_h_cow_tent_loop_head, spr_h_cow_tent_loop_breast_c, spr_h_cow_hand_c, spr_h_cow_tent_loop_leg_c, spr_h_cow_tent_loop_leg_part_c]
            },
            phase_4: 
            {
                spr_array: [-1, spr_h_cow_tent_birth_head, spr_h_cow_tent_birth_breast, spr_h_cow_hand, spr_h_cow_tent_birth_leg, spr_h_cow_tent_birth_leg_part],
                spr_c_array: [-1, spr_h_cow_tent_birth_head, spr_h_cow_tent_birth_breast_c, spr_h_cow_hand_c, spr_h_cow_tent_birth_leg_c, spr_h_cow_tent_birth_leg_part_c]
            }
        }
    };
    ds_map_add(global.class_registry, 9, _class);
    _class = 
    {
        name: "nyx",
        is_special: true,
        clothing_standard: 
        {
            phase_1: 
            {
                spr_array: [-1, spr_h_base_idle_head_nyx, spr_h_base_idle_breast_nyx, spr_h_nyx_hand, spr_h_base_idle_leg_nyx, spr_h_base_idle_leg_part_nyx, -1],
                spr_c_array: [-1, spr_h_base_idle_head_nyx, spr_h_base_idle_breast_c_nyx, spr_h_nyx_hand_c, spr_h_base_idle_leg_c_nyx, spr_h_base_idle_leg_part_c_nyx]
            },
            phase_2: 
            {
                spr_array: [-1, spr_h_base_loop_head_nyx, spr_h_base_loop_breast_nyx, spr_h_nyx_hand, spr_h_base_loop_leg_nyx, spr_h_base_loop_leg_part_nyx, -1],
                spr_c_array: [-1, spr_h_base_loop_head_nyx, spr_h_base_loop_breast_c_nyx, spr_h_nyx_hand_c, spr_h_base_loop_leg_c_nyx, spr_h_base_loop_leg_part_c_nyx]
            }
        },
        clothing_big: 
        {
            phase_0: 
            {
                spr_array: [-1, spr_h_nyx_big_start_head, spr_h_nyx_big_start_breast, spr_h_nyx_hand, spr_h_nyx_big_start_leg, -1],
                spr_c_array: [-1, spr_h_nyx_big_start_head, spr_h_nyx_big_start_breast_c, spr_h_nyx_hand_c, spr_h_nyx_big_start_leg_c, -1]
            },
            phase_1: 
            {
                spr_array: [-1, spr_h_nyx_big_idle_head, spr_h_nyx_big_idle_breast, spr_h_nyx_hand, spr_h_nyx_big_idle_leg, -1],
                spr_c_array: [-1, spr_h_nyx_big_idle_head, spr_h_nyx_big_idle_breast_c, spr_h_nyx_hand_c, spr_h_nyx_big_idle_leg_c, -1]
            },
            phase_2: 
            {
                spr_array: [-1, spr_h_nyx_big_loop_head, spr_h_nyx_big_loop_breast, spr_h_nyx_hand, spr_h_nyx_big_loop_leg, -1],
                spr_c_array: [-1, spr_h_nyx_big_loop_head, spr_h_nyx_big_loop_breast_c, spr_h_nyx_hand_c, spr_h_nyx_big_loop_leg_c, -1]
            }
        },
        clothing_tent: 
        {
            phase_1: 
            {
                spr_array: [-1, spr_h_nyx_tent_idle_head, spr_h_nyx_tent_idle_breast, spr_h_nyx_hand, spr_h_nyx_tent_idle_leg, spr_h_nyx_tent_idle_leg_part],
                spr_c_array: [-1, spr_h_nyx_tent_idle_head, spr_h_nyx_tent_idle_breast_c, spr_h_nyx_hand_c, spr_h_nyx_tent_idle_leg_c, spr_h_nyx_tent_idle_leg_part_c]
            },
            phase_2: 
            {
                spr_array: [-1, spr_h_nyx_tent_loop_head, spr_h_nyx_tent_loop_breast, spr_h_nyx_hand, spr_h_nyx_tent_loop_leg, spr_h_nyx_tent_loop_leg_part],
                spr_c_array: [-1, spr_h_nyx_tent_loop_head, spr_h_nyx_tent_loop_breast_c, spr_h_nyx_hand_c, spr_h_nyx_tent_loop_leg_c, spr_h_nyx_tent_loop_leg_part_c]
            },
            phase_4: 
            {
                spr_array: [-1, spr_h_nyx_tent_birth_head, spr_h_nyx_tent_birth_breast, spr_h_nyx_hand, spr_h_nyx_tent_birth_leg, spr_h_nyx_tent_birth_leg_part],
                spr_c_array: [-1, spr_h_nyx_tent_birth_head, spr_h_nyx_tent_birth_breast_c, spr_h_nyx_hand_c, spr_h_nyx_tent_birth_leg_c, spr_h_nyx_tent_birth_leg_part_c]
            }
        }
    };
    ds_map_add(global.class_registry, 10, _class);
    _class = 
    {
        name: "cat",
        is_special: true,
        clothing_standard: 
        {
            phase_1: 
            {
                spr_array: [-1, spr_h_base_idle_head_cat, spr_h_base_idle_breast_cat, spr_h_cat_hand, spr_h_base_idle_leg_cat, spr_h_base_idle_leg_part_cat, -1],
                spr_c_array: [-1, spr_h_base_idle_head_cat, spr_h_base_idle_breast_c_cat, spr_h_cat_hand_c, spr_h_base_idle_leg_c_cat, spr_h_base_idle_leg_part_c_cat]
            },
            phase_2: 
            {
                spr_array: [-1, spr_h_base_loop_head_cat, spr_h_base_loop_breast_cat, spr_h_cat_hand, spr_h_base_loop_leg_cat, spr_h_base_loop_leg_part_cat, -1],
                spr_c_array: [-1, spr_h_base_loop_head_cat, spr_h_base_loop_breast_c_cat, spr_h_cat_hand_c, spr_h_base_loop_leg_c_cat, spr_h_base_loop_leg_part_c_cat]
            }
        },
        clothing_big: 
        {
            phase_0: 
            {
                spr_array: [-1, spr_h_cat_big_start_head, spr_h_cat_big_start_breast, spr_h_cat_hand, spr_h_cat_big_start_leg, -1],
                spr_c_array: [-1, spr_h_cat_big_start_head, spr_h_cat_big_start_breast_c, spr_h_cat_hand_c, spr_h_cat_big_start_leg_c, -1]
            },
            phase_1: 
            {
                spr_array: [-1, spr_h_cat_big_idle_head, spr_h_cat_big_idle_breast, spr_h_cat_hand, spr_h_cat_big_idle_leg, -1],
                spr_c_array: [-1, spr_h_cat_big_idle_head, spr_h_cat_big_idle_breast_c, spr_h_cat_hand_c, spr_h_cat_big_idle_leg_c, -1]
            },
            phase_2: 
            {
                spr_array: [-1, spr_h_cat_big_loop_head, spr_h_cat_big_loop_breast, spr_h_cat_hand, spr_h_cat_big_loop_leg, -1],
                spr_c_array: [-1, spr_h_cat_big_loop_head, spr_h_cat_big_loop_breast_c, spr_h_cat_hand_c, spr_h_cat_big_loop_leg_c, -1]
            }
        },
        clothing_tent: 
        {
            phase_1: 
            {
                spr_array: [-1, spr_h_cat_tent_idle_head, spr_h_cat_tent_idle_breast, spr_h_cat_hand, spr_h_cat_tent_idle_leg, spr_h_cat_tent_idle_leg_part],
                spr_c_array: [-1, spr_h_cat_tent_idle_head, spr_h_cat_tent_idle_breast_c, spr_h_cat_hand_c, spr_h_cat_tent_idle_leg_c, spr_h_cat_tent_idle_leg_part_c]
            },
            phase_2: 
            {
                spr_array: [-1, spr_h_cat_tent_loop_head, spr_h_cat_tent_loop_breast, spr_h_cat_hand, spr_h_cat_tent_loop_leg, spr_h_cat_tent_loop_leg_part],
                spr_c_array: [-1, spr_h_cat_tent_loop_head, spr_h_cat_tent_loop_breast_c, spr_h_cat_hand_c, spr_h_cat_tent_loop_leg_c, spr_h_cat_tent_loop_leg_part_c]
            },
            phase_4: 
            {
                spr_array: [-1, spr_h_cat_tent_birth_head, spr_h_cat_tent_birth_breast, spr_h_cat_hand, spr_h_cat_tent_birth_leg, spr_h_cat_tent_birth_leg_part],
                spr_c_array: [-1, spr_h_cat_tent_birth_head, spr_h_cat_tent_birth_breast_c, spr_h_cat_hand_c, spr_h_cat_tent_birth_leg_c, spr_h_cat_tent_birth_leg_part_c]
            }
        }
    };
    ds_map_add(global.class_registry, 13, _class);
    _class = 
    {
        name: "morrigan",
        is_special: true,
        clothing_standard: 
        {
            phase_1: 
            {
                spr_array: [-1, spr_h_base_idle_head_morrigan, spr_h_base_idle_breast_morrigan, spr_h_morrigan_hand, spr_h_base_idle_leg_morrigan, spr_h_base_idle_leg_part_morrigan, spr_h_base_idle_cape_morrigan],
                spr_c_array: [-1, spr_h_base_idle_head_morrigan, spr_h_base_idle_breast_c_morrigan, spr_h_morrigan_hand_c, spr_h_base_idle_leg_c_morrigan, spr_h_base_idle_leg_part_c_morrigan]
            },
            phase_2: 
            {
                spr_array: [-1, spr_h_base_loop_head_morrigan, spr_h_base_loop_breast_morrigan, spr_h_morrigan_hand, spr_h_base_loop_leg_morrigan, spr_h_base_loop_leg_part_morrigan, spr_h_base_idle_cape_morrigan],
                spr_c_array: [-1, spr_h_base_loop_head_morrigan, spr_h_base_loop_breast_c_morrigan, spr_h_morrigan_hand_c, spr_h_base_loop_leg_c_morrigan, spr_h_base_loop_leg_part_c_morrigan]
            }
        },
        clothing_big: 
        {
            phase_0: 
            {
                spr_array: [-1, spr_h_morrigan_big_start_head, spr_h_morrigan_big_start_breast, spr_h_morrigan_hand, spr_h_morrigan_big_start_leg, -1],
                spr_c_array: [-1, spr_h_morrigan_big_start_head, spr_h_morrigan_big_start_breast_c, spr_h_morrigan_hand_c, spr_h_morrigan_big_start_leg_c, -1]
            },
            phase_1: 
            {
                spr_array: [-1, spr_h_morrigan_big_idle_head, spr_h_morrigan_big_idle_breast, spr_h_morrigan_hand, spr_h_morrigan_big_idle_leg, -1],
                spr_c_array: [-1, spr_h_morrigan_big_idle_head, spr_h_morrigan_big_idle_breast_c, spr_h_morrigan_hand_c, spr_h_morrigan_big_idle_leg_c, -1]
            },
            phase_2: 
            {
                spr_array: [-1, spr_h_morrigan_big_loop_head, spr_h_morrigan_big_loop_breast, spr_h_morrigan_hand, spr_h_morrigan_big_loop_leg, -1],
                spr_c_array: [-1, spr_h_morrigan_big_loop_head, spr_h_morrigan_big_loop_breast_c, spr_h_morrigan_hand_c, spr_h_morrigan_big_loop_leg_c, -1]
            }
        },
        clothing_tent: 
        {
            phase_1: 
            {
                spr_array: [-1, spr_h_morrigan_tent_idle_head, spr_h_morrigan_tent_idle_breast, spr_h_morrigan_hand, spr_h_morrigan_tent_idle_leg, spr_h_morrigan_tent_idle_leg_part],
                spr_c_array: [-1, spr_h_morrigan_tent_idle_head, spr_h_morrigan_tent_idle_breast_c, spr_h_morrigan_hand_c, spr_h_morrigan_tent_idle_leg_c, spr_h_morrigan_tent_idle_leg_part_c]
            },
            phase_2: 
            {
                spr_array: [-1, spr_h_morrigan_tent_loop_head, spr_h_morrigan_tent_loop_breast, spr_h_morrigan_hand, spr_h_morrigan_tent_loop_leg, spr_h_morrigan_tent_loop_leg_part],
                spr_c_array: [-1, spr_h_morrigan_tent_loop_head, spr_h_morrigan_tent_loop_breast_c, spr_h_morrigan_hand_c, spr_h_morrigan_tent_loop_leg_c, spr_h_morrigan_tent_loop_leg_part_c]
            },
            phase_4: 
            {
                spr_array: [-1, spr_h_morrigan_tent_birth_head, spr_h_morrigan_tent_birth_breast, spr_h_morrigan_hand, spr_h_morrigan_tent_birth_leg, spr_h_morrigan_tent_birth_leg_part],
                spr_c_array: [-1, spr_h_morrigan_tent_birth_head, spr_h_morrigan_tent_birth_breast_c, spr_h_morrigan_hand_c, spr_h_morrigan_tent_birth_leg_c, spr_h_morrigan_tent_birth_leg_part_c]
            }
        }
    };
    ds_map_add(global.class_registry, 12, _class);
    _class = 
    {
        name: "lilith",
        is_special: true,
        fap_mul: 0,
        bap_mul: 0,
        clothing_standard: 
        {
            phase_1: 
            {
                spr_array: [-1, spr_h_base_idle_head_lilith, spr_h_base_idle_breast_lilith, spr_h_lilith_hand, spr_h_base_idle_leg_lilith, spr_h_base_idle_leg_part_lilith, -1],
                spr_c_array: [-1, spr_h_base_idle_head_lilith, spr_h_base_idle_breast_c_lilith, spr_h_lilith_hand_c, spr_h_base_idle_leg_c_lilith, spr_h_base_idle_leg_part_c_lilith]
            },
            phase_2: 
            {
                spr_array: [-1, spr_h_base_loop_head_lilith, spr_h_base_loop_breast_lilith, spr_h_lilith_hand, spr_h_base_loop_leg_lilith, spr_h_base_loop_leg_part_lilith, -1],
                spr_c_array: [-1, spr_h_base_loop_head_lilith, spr_h_base_loop_breast_c_lilith, spr_h_lilith_hand_c, spr_h_base_loop_leg_c_lilith, spr_h_base_loop_leg_part_c_lilith]
            }
        },
        clothing_big: 
        {
            phase_0: 
            {
                spr_array: [-1, spr_h_lilith_big_start_head, spr_h_lilith_big_start_breast, spr_h_lilith_hand, spr_h_lilith_big_start_leg, -1],
                spr_c_array: [-1, spr_h_lilith_big_start_head, spr_h_lilith_big_start_breast_c, spr_h_lilith_hand_c, spr_h_lilith_big_start_leg_c, -1]
            },
            phase_1: 
            {
                spr_array: [-1, spr_h_lilith_big_idle_head, spr_h_lilith_big_idle_breast, spr_h_lilith_hand, spr_h_lilith_big_idle_leg, -1],
                spr_c_array: [-1, spr_h_lilith_big_idle_head, spr_h_lilith_big_idle_breast_c, spr_h_lilith_hand_c, spr_h_lilith_big_idle_leg_c, -1]
            },
            phase_2: 
            {
                spr_array: [-1, spr_h_lilith_big_loop_head, spr_h_lilith_big_loop_breast, spr_h_lilith_hand, spr_h_lilith_big_loop_leg, -1],
                spr_c_array: [-1, spr_h_lilith_big_loop_head, spr_h_lilith_big_loop_breast_c, spr_h_lilith_hand_c, spr_h_lilith_big_loop_leg_c, -1]
            }
        },
        clothing_tent: 
        {
            phase_1: 
            {
                spr_array: [-1, spr_h_lilith_tent_idle_head, spr_h_lilith_tent_idle_breast, spr_h_lilith_hand, spr_h_lilith_tent_idle_leg, spr_h_lilith_tent_idle_leg_part],
                spr_c_array: [-1, spr_h_lilith_tent_idle_head, spr_h_lilith_tent_idle_breast_c, spr_h_lilith_hand_c, spr_h_lilith_tent_idle_leg_c, spr_h_lilith_tent_idle_leg_part_c]
            },
            phase_2: 
            {
                spr_array: [-1, spr_h_lilith_tent_loop_head, spr_h_lilith_tent_loop_breast, spr_h_lilith_hand, spr_h_lilith_tent_loop_leg, spr_h_lilith_tent_loop_leg_part],
                spr_c_array: [-1, spr_h_lilith_tent_loop_head, spr_h_lilith_tent_loop_breast_c, spr_h_lilith_hand_c, spr_h_lilith_tent_loop_leg_c, spr_h_lilith_tent_loop_leg_part_c]
            },
            phase_4: 
            {
                spr_array: [-1, spr_h_lilith_tent_birth_head, spr_h_lilith_tent_birth_breast, spr_h_lilith_hand, spr_h_lilith_tent_birth_leg, spr_h_lilith_tent_birth_leg_part],
                spr_c_array: [-1, spr_h_lilith_tent_birth_head, spr_h_lilith_tent_birth_breast_c, spr_h_lilith_hand_c, spr_h_lilith_tent_birth_leg_c, spr_h_lilith_tent_birth_leg_part_c]
            }
        }
    };
    ds_map_add(global.class_registry, 8, _class);
    _class = 
    {
        name: "giant",
        is_special: true,
        has_hair: false,
        hand_sprite: -1,
        hand_color: -1,
        cape_sprite: -1,
        clothing_standard: 
        {
            phase_1: 
            {
                spr_array: [spr_giant_idle_middle, spr_giant_idle_head, spr_giant_idle_breast, spr_giant_idle_hand, spr_giant_idle_leg_1, spr_giant_idle_leg_2, spr_giant_idle_middle],
                spr_c_array: [-1, -1, spr_giant_idle_breast_c, spr_giant_idle_hand_c, spr_giant_idle_leg_1_c, spr_giant_idle_leg_2_c]
            },
            phase_2: 
            {
                spr_array: [-1, spr_giant_loop_head, spr_giant_loop_breast, spr_giant_loop_hand, spr_giant_loop_leg_1, spr_giant_loop_leg_2, spr_giant_loop_middle],
                spr_c_array: [-1, -1, spr_giant_loop_breast_c, spr_giant_loop_hand_c, spr_giant_loop_leg_1_c, spr_giant_loop_leg_2_c]
            }
        }
    };
    ds_map_add(global.class_registry, 11, _class);
    // Normalize: some hardcoded special entries omit has_hair. Default it to false
    // (specials carry their hair in their sprites; no separate GNX hair layer).
    var _hh_key = ds_map_find_first(global.class_registry);
    while (!is_undefined(_hh_key))
    {
        var _hh_e = ds_map_find_value(global.class_registry, _hh_key);
        if (is_struct(_hh_e) && !variable_struct_exists(_hh_e, "has_hair"))
            _hh_e.has_hair = false;
        _hh_key = ds_map_find_next(global.class_registry, _hh_key);
    }
    global.gnx_registered_cells = [];
    // Free a prior pool map (and its inner ds_lists) on re-entry, e.g. menu return.
    if (variable_global_exists("gnx_encounter_pools") && ds_exists(global.gnx_encounter_pools, ds_type_map))
    {
        var _epk = ds_map_find_first(global.gnx_encounter_pools);
        repeat (ds_map_size(global.gnx_encounter_pools))
        {
            var _epv = ds_map_find_value(global.gnx_encounter_pools, _epk);
            if (!is_undefined(_epv) && ds_exists(_epv, ds_type_list))
                ds_list_destroy(_epv);
            _epk = ds_map_find_next(global.gnx_encounter_pools, _epk);
        }
        ds_map_destroy(global.gnx_encounter_pools);
    }
    global.gnx_encounter_pools = ds_map_create();
    global.gnx_has_tools = false;
    global.gnx_tools_enabled = false;
    global.gnx_tool_registry = [];
    // GNX-PERF: draw culling counters (only active when gnx_perf_enabled)
    global.gnx_perf_enabled = false;
    global.gnx_debug_verbose = false;
    global.gnx_perf_slots_drawn = 0;
    global.gnx_perf_slots_culled = 0;
    global.gnx_perf_mons_drawn = 0;
    global.gnx_perf_mons_culled = 0;
    global.gnx_perf_frame = 0;
    global.gnx_keybinds = [];
    global.gnx_continuous_effects = [];
    // GNX sound system
    global.gnx_has_sounds = false;
    // Free prior voice maps on re-entry (values are arrays/structs, GC'd; sounds live in the cache).
    if (variable_global_exists("gnx_voice_banks") && ds_exists(global.gnx_voice_banks, ds_type_map))
        ds_map_destroy(global.gnx_voice_banks);
    global.gnx_voice_banks = ds_map_create();
    global.gnx_voice_bank_names = [];
    if (variable_global_exists("gnx_voice_class_map") && ds_exists(global.gnx_voice_class_map, ds_type_map))
        ds_map_destroy(global.gnx_voice_class_map);
    global.gnx_voice_class_map = ds_map_create();  // class_id -> {bank (prefixed), pitch}
    global.gnx_sfx_orgasm = [];
    global.gnx_sfx_bj_slurp = [];
    global.gnx_sfx_bj_gag = [];
    global.gnx_sfx_bj_moan = [];
    global.gnx_sfx_bj_breathe = [];
    global.gnx_runtime_sounds = [];
    if (!variable_global_exists("gnx_sound_cache") || !ds_exists(global.gnx_sound_cache, ds_type_map))
        global.gnx_sound_cache = ds_map_create();
    scr_gnx_init_encounter_pools();

    scr_gnx_load_mods();
    var _gnx_ak = ds_map_find_first(global.cell_registry);
    
    while (_gnx_ak != undefined)
    {
        var _gnx_ac = ds_map_find_value(global.cell_registry, _gnx_ak);
        var _gnx_ap = _gnx_ac.physical;
        
        if (array_length(_gnx_ap.sp_y) < 2)
            _gnx_ap.sp_y = [_gnx_ap.sp_y[0], _gnx_ap.sp_y[0]];
        
        if (array_length(_gnx_ap.sq_y) < 2)
            _gnx_ap.sq_y = [_gnx_ap.sq_y[0], _gnx_ap.sq_y[0]];
        
        _gnx_ak = ds_map_find_next(global.cell_registry, _gnx_ak);
    }
    
    scr_gnx_build_expected();
    scr_gnx_test_suite();
    scr_gnx_test_dispatch_routing();

    // [SHELVED 1.3.11] GMLC smoke test + lazy singleton
    // Restore from gml_shelved/ to re-enable
    global.gnx_gmlc_env = -1;

    // (multi-map globals moved to scr_gnx_load_mods, before mod discovery)

    draw_set_font(fnt_base_font_eng);
    display_set_gui_size(480, 270);
    window_set_cursor(cr_none);
    
    if (room == rm_init)
        room_goto(rm_logo);
}

function gnx_resolve_script(arg0)
{
    var _idx = asset_get_index(arg0);
    
    if (_idx < 0)
    {
        var _log = file_text_open_append(GNX_LOG);
        file_text_write_string(_log, "[GNX] WARNING: script not found: " + arg0 + "\n");
        file_text_close(_log);
    }
    
    return _idx;
}

function gnx_resolve_layer_sprite(arg0, arg1, arg2)
{
    if (is_real(arg0))
        return arg0;
    
    if (!is_string(arg0))
        return -1;
    
    if (string_copy(arg0, 1, 4) == "gnx:")
    {
        var _key = string_delete(arg0, 1, 4);
        
        if (arg1 != undefined && variable_struct_exists(arg1, _key))
            return gnx_resolve_sprite(arg1, _key, arg2, -1);
        
        return -1;
    }
    
    var _idx = asset_get_index(arg0);
    return (_idx >= 0) ? _idx : -1;
}

function gnx_resolve_sprite(arg0, arg1, arg2, arg3)
{
    if (!variable_struct_exists(arg0, arg1))
        return arg3;

    var _s = variable_struct_get(arg0, arg1);
    var _xo = (is_struct(_s) && variable_struct_exists(_s, "xorig")) ? _s.xorig : 0;
    var _yo = (is_struct(_s) && variable_struct_exists(_s, "yorig")) ? _s.yorig : 0;

    // Cache key must identify the actual asset (strip/path/frames), not just the
    // "gnx:<key>" lookup name — different classes/cells reuse common key names
    // (idle_head, loop_breast, ...) for entirely different sprites in their own
    // "sprites" dict, and keying on arg1 alone caused cache collisions where the
    // second entry silently returned the first one's sprite.
    var _cache_key;

    if (is_struct(_s) && variable_struct_exists(_s, "strip"))
        _cache_key = arg2 + _s.strip;
    else if (is_struct(_s) && variable_struct_exists(_s, "frames") && is_array(_s.frames))
    {
        _cache_key = arg2;
        for (var _ci = 0; _ci < array_length(_s.frames); _ci++)
            _cache_key += "|" + string(_s.frames[_ci]);
    }
    else if (is_struct(_s) && variable_struct_exists(_s, "path"))
        _cache_key = arg2 + _s.path;
    else if (!is_struct(_s))
        _cache_key = arg2 + string(_s);
    else
        _cache_key = arg2 + arg1;

    // Cache hit: return previously loaded sprite
    if (ds_map_exists(global.gnx_sprite_cache, _cache_key))
    {
        var _cached = ds_map_find_value(global.gnx_sprite_cache, _cache_key);
        if (sprite_exists(_cached))
            return _cached;
        ds_map_delete(global.gnx_sprite_cache, _cache_key);
    }

    if (is_struct(_s) && variable_struct_exists(_s, "strip"))
    {
        var _path = arg2 + _s.strip;
        var _n_imgs = is_real(_s.frames) ? _s.frames : 1;
        _loaded = sprite_add(_path, _n_imgs, false, false, _xo, _yo);
        if (_loaded != -1)
        {
            array_push(global.gnx_runtime_sprites, _loaded);
            ds_map_set(global.gnx_sprite_cache, _cache_key, _loaded);
        }
        _log = file_text_open_append(GNX_LOG);
        file_text_write_string(_log, "[GNX] " + arg1 + ": strip frames=" + string(_n_imgs) + " idx=" + string(_loaded) + "\n");
        file_text_close(_log);
        return (_loaded != -1) ? _loaded : arg3;
    }

    var _fps = [];

    if (!is_struct(_s))
    {
        array_push(_fps, arg2 + string(_s));
    }
    else if (variable_struct_exists(_s, "frames") && is_array(_s.frames))
    {
        var _fa = _s.frames;

        for (var _fi = 0; _fi < array_length(_fa); _fi++)
            array_push(_fps, arg2 + _fa[_fi]);
    }
    else if (variable_struct_exists(_s, "path"))
    {
        array_push(_fps, arg2 + _s.path);
    }
    else
    {
        _log = file_text_open_append(GNX_LOG);
        file_text_write_string(_log, "[GNX] WARN " + arg1 + ": no strip/path/frames, returning fallback\n");
        file_text_close(_log);
        return arg3;
    }

    var _loaded = gnx_load_sprite_frames(_fps, _xo, _yo);
    if (_loaded != -1)
        ds_map_set(global.gnx_sprite_cache, _cache_key, _loaded);
    var _log = file_text_open_append(GNX_LOG);
    file_text_write_string(_log, "[GNX] " + arg1 + ": frames=" + string(array_length(_fps)) + " idx=" + string(_loaded) + " xo=" + string(_xo) + " yo=" + string(_yo) + "\n");
    file_text_close(_log);
    return (_loaded != -1) ? _loaded : arg3;
}

function gnx_load_sprite_frames(arg0, arg1, arg2)
{
    var _n = array_length(arg0);
    
    if (_n == 0)
        return -1;
    
    var _spr = sprite_add(arg0[0], 1, false, false, arg1, arg2);

    if (_spr == -1)
        return -1;

    array_push(global.gnx_runtime_sprites, _spr);

    if (_n == 1)
        return _spr;

    var _w = sprite_get_width(_spr);
    var _h = sprite_get_height(_spr);
    
    for (var _i = 1; _i < _n; _i++)
    {
        var _tmp = sprite_add(arg0[_i], 1, false, false, 0, 0);
        
        if (_tmp == -1)
            continue;
        
        var _surf = surface_create(_w, _h);
        surface_set_target(_surf);
        draw_clear_alpha(c_black, 0);
        draw_sprite(_tmp, 0, 0, 0);
        surface_reset_target();
        sprite_add_from_surface(_spr, _surf, 0, 0, _w, _h, false, false);
        surface_free(_surf);
        sprite_delete(_tmp);
    }
    
    return _spr;
}

/// @desc Records a mod-loading problem so it can be surfaced to the player
///       (not just gnx_debug.txt). Also writes to GNX_LOG.
/// @arg {string} arg0  human-readable error message
function gnx_report_mod_error(arg0)
{
    if (!variable_global_exists("gnx_mod_errors") || !is_array(global.gnx_mod_errors))
        global.gnx_mod_errors = [];

    array_push(global.gnx_mod_errors, arg0);

    var _log = file_text_open_append(GNX_LOG);
    file_text_write_string(_log, "[GNX] ERROR: " + arg0 + "\n");
    file_text_close(_log);
}

function scr_gnx_load_mods()
{
    global.gnx_mods_root = program_directory + "GNX_mods/";
    var _log = file_text_open_write(GNX_LOG);
    file_text_close(_log);
    _log = file_text_open_append(GNX_LOG);
    file_text_write_string(_log, "[GNX] loader start\n");
    file_text_write_string(_log, "[GNX] mods_root=" + global.gnx_mods_root + "\n");
    file_text_close(_log);

    global.gnx_indexed_mods = [];
    global.gnx_loaded_mods = [];
    global.gnx_mod_map_decl = {};
    // [SHELVED 1.3.11] Multi-map disabled for this release
    global.gnx_multimap_enabled = false;
    // Multi-map globals (persist across scr_create_initials re-calls during travel)
    if (!variable_global_exists("gnx_active_map"))
        global.gnx_active_map = "vanilla";
    if (!variable_global_exists("gnx_inactive_maps"))
        global.gnx_inactive_maps = {};
    // gnx_travel_data: guarded so compiled state machine (scr_create_initials -> scr_load_slot)
    // doesn't wipe the in-flight travel snapshot between the two calls
    if (!variable_global_exists("gnx_travel_data") || global.gnx_travel_data == -1)
        global.gnx_travel_data = -1;
    // gnx_trigger_load: deferred flag, always reset (consumed by obj_control_Step_0)
    global.gnx_trigger_load = false;
    global.gnx_travel_locations = [];
    global.gnx_map_sprite = -1;
    global.gnx_runtime_sprites = [];
    global.gnx_mod_errors = [];
    global.gnx_class_name_to_id = ds_map_create();
    global.gnx_cell_name_to_id = ds_map_create();
    if (variable_global_exists("gnx_quest_events") && ds_exists(global.gnx_quest_events, ds_type_map))
        ds_map_destroy(global.gnx_quest_events);
    global.gnx_quest_events = ds_map_create();
    global.gnx_quest_triggers = [];
    global.gnx_active_quests = [];
    global.gnx_active_notis = [];
    if (variable_global_exists("gnx_portraits") && ds_exists(global.gnx_portraits, ds_type_map))
        ds_map_destroy(global.gnx_portraits);
    global.gnx_portraits = ds_map_create();
    if (variable_global_exists("gnx_popups") && ds_exists(global.gnx_popups, ds_type_map))
        ds_map_destroy(global.gnx_popups);
    global.gnx_popups = ds_map_create();
    if (!variable_global_exists("gnx_sprite_cache") || !ds_exists(global.gnx_sprite_cache, ds_type_map))
        global.gnx_sprite_cache = ds_map_create();
    if (!variable_global_exists("gnx_sound_cache") || !ds_exists(global.gnx_sound_cache, ds_type_map))
        global.gnx_sound_cache = ds_map_create();

    if (!directory_exists(global.gnx_mods_root))
    {
        _log = file_text_open_append(GNX_LOG);
        file_text_write_string(_log, "[GNX] mods/ folder not found, no mods loaded\n");
        file_text_close(_log);
        exit;
    }

    // Auto-discover mod folders: any direct subfolder of mods/ containing a manifest.json.
    // (Replaces the old mods/index.txt list so mod managers like G3M can drop/remove
    // mod folders via extra_files without maintaining a separate index file.)
    var _name = file_find_first(global.gnx_mods_root + "*", fa_directory);

    while (_name != "")
    {
        if (_name != "." && _name != ".." && directory_exists(global.gnx_mods_root + _name))
        {
            if (file_exists(global.gnx_mods_root + _name + "/manifest.json"))
            {
                array_push(global.gnx_indexed_mods, _name);
            }
            else
            {
                _log = file_text_open_append(GNX_LOG);
                file_text_write_string(_log, "[GNX-WARN] folder '" + _name + "' has no manifest.json, skipped\n");
                file_text_close(_log);
            }
        }

        _name = file_find_next();
    }

    file_find_close();

    // Deterministic load order regardless of filesystem enumeration order
    array_sort(global.gnx_indexed_mods, true);

    for (var _mi = 0; _mi < array_length(global.gnx_indexed_mods); _mi++)
        scr_gnx_load_mod(global.gnx_indexed_mods[_mi]);

    scr_gnx_resolve_birth_classes();
    scr_gnx_deferred_resolve_class_map();

    ds_map_destroy(global.gnx_class_name_to_id);
    ds_map_destroy(global.gnx_cell_name_to_id);

    scr_gnx_apply_unlocks();
    scr_gnx_register_goblin_sprites();
    // GNX framework debug tools (always available)
    var _gnx_fw_entry = {
        mod_name: "_gnx",
        categories: [{
            label: "GNX DEBUG",
            buttons: [
                {
                    label: "PERF LOG",
                    toggle: "perf",
                    actions: [{ type: "set_var", key: "gnx_perf_enabled", value: 1 }],
                    undo_actions: [{ type: "set_var", key: "gnx_perf_enabled", value: 0 }],
                    popup: "Perf logging ON (gnx_debug.txt)",
                    undo_popup: "Perf logging OFF",
                    guard: -1,
                    guard_fail_popup: ""
                },
                {
                    label: "VERBOSE LOG",
                    toggle: "verbose",
                    actions: [{ type: "set_var", key: "gnx_debug_verbose", value: 1 }],
                    undo_actions: [{ type: "set_var", key: "gnx_debug_verbose", value: 0 }],
                    popup: "Verbose debug logging ON",
                    undo_popup: "Verbose debug logging OFF",
                    guard: -1,
                    guard_fail_popup: ""
                }
            ]
        }]
    };
    array_push(global.gnx_tool_registry, _gnx_fw_entry);
    global.gnx_has_tools = true;
    global.gnx_tools_enabled = true;
    global.gnx_continuous_effects = [];

    _log = file_text_open_append(GNX_LOG);
    file_text_write_string(_log, "[GNX] loader done\n");
    if (global.gnx_has_tools)
        file_text_write_string(_log, "[GNX] tool system available (" + string(array_length(global.gnx_tool_registry)) + " mod(s) with tools)\n");
    if (global.gnx_has_sounds)
        file_text_write_string(_log, "[GNX] sound system active (banks=" + string(array_length(global.gnx_voice_bank_names)) + " orgasm=" + string(array_length(global.gnx_sfx_orgasm)) + " bj=" + string(array_length(global.gnx_sfx_bj_slurp) + array_length(global.gnx_sfx_bj_gag) + array_length(global.gnx_sfx_bj_moan) + array_length(global.gnx_sfx_bj_breathe)) + ")\n");
    file_text_close(_log);

    // Auto-add return button when on a non-vanilla map
    if (global.gnx_multimap_enabled && global.gnx_active_map != "vanilla")
    {
        var _rx = 200; var _ry = 80; var _rl = "Return";
        for (var _ti = 0; _ti < array_length(global.gnx_travel_locations); _ti++)
        {
            if (global.gnx_travel_locations[_ti].target == global.gnx_active_map)
            {
                _rx = global.gnx_travel_locations[_ti].return_x;
                _ry = global.gnx_travel_locations[_ti].return_y;
                _rl = global.gnx_travel_locations[_ti].return_label;
                global.gnx_map_sprite = global.gnx_travel_locations[_ti].map_sprite;
                break;
            }
        }
        var _ret = {};
        _ret.target = "vanilla";
        _ret.show_on = global.gnx_active_map;
        _ret.label = _rl;
        _ret.x = _rx;
        _ret.y = _ry;
        _ret.mod_name = "_gnx";
        _ret.map_sprite = -1;
        array_push(global.gnx_travel_locations, _ret);
    }
    else
    {
        global.gnx_map_sprite = -1;
    }

    // Sanitize orphaned maps (mod removed while save references its map)
    if (global.gnx_multimap_enabled)
        scr_gnx_sanitize_maps();

    if (array_length(global.gnx_mod_errors) > 0)
    {
        var _msg = "Mod loading problem(s):\n\n";
        for (var _ei = 0; _ei < array_length(global.gnx_mod_errors); _ei++)
            _msg += "- " + global.gnx_mod_errors[_ei] + "\n";
        _msg += "\nDetails in gnx_debug.txt.";
        show_message(_msg);
    }
}

/// @desc Remove orphaned map snapshots and reset active map if its mod was removed.
///       A map name is valid if it's "vanilla" or if any mod declares "map": <name>.
function scr_gnx_sanitize_maps()
{
    // Build set of valid map names from gnx_mod_map_decl values
    var _valid_maps = {};
    variable_struct_set(_valid_maps, "vanilla", true);
    var _decl_keys = variable_struct_get_names(global.gnx_mod_map_decl);
    for (var _i = 0; _i < array_length(_decl_keys); _i++)
    {
        var _map_val = variable_struct_get(global.gnx_mod_map_decl, _decl_keys[_i]);
        if (_map_val != "all")
            variable_struct_set(_valid_maps, _map_val, true);
    }

    // Purge orphaned inactive map snapshots
    var _inactive_keys = variable_struct_get_names(global.gnx_inactive_maps);
    for (var _i = 0; _i < array_length(_inactive_keys); _i++)
    {
        var _mk = _inactive_keys[_i];
        if (!variable_struct_exists(_valid_maps, _mk))
        {
            variable_struct_remove(global.gnx_inactive_maps, _mk);
            var _log = file_text_open_append(GNX_LOG);
            file_text_write_string(_log, "[GNX-SANITIZE] orphaned map snapshot '" + _mk + "' removed (mod no longer present)\n");
            file_text_close(_log);
        }
    }

    // Reset active map if its mod was removed
    if (global.gnx_active_map != "vanilla" && !variable_struct_exists(_valid_maps, global.gnx_active_map))
    {
        var _old = global.gnx_active_map;
        global.gnx_active_map = "vanilla";
        var _log = file_text_open_append(GNX_LOG);
        file_text_write_string(_log, "[GNX-SANITIZE] active map '" + _old + "' invalid (mod removed), reset to vanilla\n");
        file_text_close(_log);
    }
}

/// @desc Second-pass resolution of birth_classes string refs.
/// Called after all mods are loaded, while gnx_class_name_to_id still exists.
/// Resolves "mod_folder.ClassName" strings to integer class_ids in-place.
function scr_gnx_resolve_birth_classes()
{
    var _key = ds_map_find_first(global.class_registry);
    repeat (ds_map_size(global.class_registry))
    {
        var _rc = ds_map_find_value(global.class_registry, _key);
        if (is_struct(_rc) && variable_struct_exists(_rc, "birth_classes"))
        {
            var _bc = _rc.birth_classes;
            var _bc_len = array_length(_bc);
            var _bc_out = [];
            for (var _bi = 0; _bi < _bc_len; _bi++)
            {
                var _bv = _bc[_bi];
                if (is_string(_bv))
                {
                    var _bm = ds_map_find_value(global.gnx_class_name_to_id, _bv);
                    array_push(_bc_out, (_bm != undefined) ? _bm : _bv);
                }
                else
                    array_push(_bc_out, _bv);
            }
            _rc.birth_classes = _bc_out;
        }
        _key = ds_map_find_next(global.class_registry, _key);
    }
}

function scr_gnx_deferred_resolve_class_map()
{
    // Post-load pass: resolve any unresolved string class refs in class_map cells.
    // At load time, cross-mod refs may not be in gnx_class_name_to_id yet.
    // Now all mods are loaded, so all refs should be resolvable.
    var _key = ds_map_find_first(global.cell_registry);
    repeat (ds_map_size(global.cell_registry))
    {
        var _cell = ds_map_find_value(global.cell_registry, _key);
        if (is_struct(_cell) && variable_struct_exists(_cell, "human_spr"))
        {
            var _hspr = _cell.human_spr;
            if (is_struct(_hspr) && variable_struct_exists(_hspr, "mode") && _hspr.mode == "class_map"
                && variable_struct_exists(_hspr, "classes"))
            {
                var _cls = _hspr.classes;
                var _cls_keys = variable_struct_get_names(_cls);
                var _needs_remap = false;
                var _ci = 0;
                repeat (array_length(_cls_keys))
                {
                    var _ck = _cls_keys[_ci++];
                    // Check if key is a string ref (contains ".", not a pure number)
                    if (string_pos(".", _ck) > 0)
                    {
                        var _rid = ds_map_find_value(global.gnx_class_name_to_id, _ck);
                        if (_rid != undefined)
                        {
                            var _val = variable_struct_get(_cls, _ck);
                            variable_struct_remove(_cls, _ck);
                            variable_struct_set(_cls, string(_rid), _val);
                            _needs_remap = true;
                        }
                        else
                        {
                            var _log = file_text_open_append(GNX_LOG);
                            file_text_write_string(_log, "[GNX-WARN] class_map h=" + string(_key) + " unresolved ref: " + _ck + "\n");
                            file_text_close(_log);
                        }
                    }
                }
                if (_needs_remap)
                {
                    var _log = file_text_open_append(GNX_LOG);
                    file_text_write_string(_log, "[GNX] class_map h=" + string(_key) + " deferred refs resolved\n");
                    file_text_close(_log);
                }
            }
        }
        _key = ds_map_find_next(global.cell_registry, _key);
    }
}

function scr_gnx_apply_unlocks()
{
    var _n = array_length(global.gnx_registered_cells);
    
    for (var _i = 0; _i < _n; _i++)
    {
        var _entry = global.gnx_registered_cells[_i];
        var _h = _entry.h_type;
        var _cat = _entry.category;

        // Category maps directly to a global.unlock field of the same name
        // (breed/utility/pleasure + b_breed/b_utility/b_other + t_breed/t_utility).
        if (!variable_struct_exists(global.unlock, _cat))
            continue;
        var _arr = variable_struct_get(global.unlock, _cat);
        if (!is_array(_arr))
            continue;

        var _found = false;
        
        for (var _j = 0; _j < array_length(_arr); _j++)
        {
            if (_arr[_j] == _h)
            {
                _found = true;
                break;
            }
        }
        
        if (!_found)
            array_push(_arr, _h);
    }
}

function scr_gnx_migrate_unlocks()
{
    var _cats = ["breed", "utility", "pleasure", "b_breed", "b_utility", "b_other", "t_breed", "t_utility"];
    var _ci = 0;
    repeat (array_length(_cats))
    {
        var _fname = _cats[_ci++];
        var _src = variable_struct_get(global.unlock, _fname);
        if (!is_array(_src))
            continue;
        var _out = [];
        var _si = 0;
        repeat (array_length(_src))
        {
            var _h = _src[_si++];
            if (ds_map_find_value(global.cell_registry, _h) != undefined)
                array_push(_out, _h);
        }
        variable_struct_set(global.unlock, _fname, _out);
    }
    scr_gnx_apply_unlocks();
}

function scr_gnx_cleanup_sprites()
{
    if (!variable_global_exists("gnx_runtime_sprites"))
        return;
    var _arr = global.gnx_runtime_sprites;
    var _n = array_length(_arr);
    for (var _i = 0; _i < _n; _i++)
    {
        if (sprite_exists(_arr[_i]))
            sprite_delete(_arr[_i]);
    }
    global.gnx_runtime_sprites = [];
}

function scr_gnx_load_mod(arg0)
{
    var _manifest_path = global.gnx_mods_root + arg0 + "/manifest.json";
    
    if (!file_exists(_manifest_path))
    {
        gnx_report_mod_error("Mod '" + arg0 + "': manifest.json not found");
        exit;
    }

    var _f = file_text_open_read(_manifest_path);
    var _raw = "";

    while (!file_text_eof(_f))
        _raw += file_text_readln(_f);

    file_text_close(_f);

    var _manifest = undefined;
    try
    {
        _manifest = json_parse(_raw);
    }
    catch (_e)
    {
        gnx_report_mod_error("Mod '" + arg0 + "': manifest.json invalid (" + string(_e.message) + ")");
        exit;
    }

    var _versions = variable_struct_exists(_manifest, "compatible_game_versions") ? _manifest.compatible_game_versions : [];
    var _game_ver = string(global.val.version);
    var _ok = false;

    for (var _i = 0; _i < array_length(_versions); _i++)
    {
        if (_versions[_i] == _game_ver)
        {
            _ok = true;
            break;
        }
    }

    if (!_ok)
    {
        gnx_report_mod_error("Mod '" + arg0 + "': incompatible with game version " + _game_ver + " (compatible: " + string(_versions) + ")");
        exit;
    }
    
    var _log = file_text_open_append(GNX_LOG);
    file_text_write_string(_log, "[GNX] loading: " + string(_manifest.name) + " v" + string(_manifest.version) + "\n");
    file_text_close(_log);

    scr_gnx_init_mod_state(arg0, _manifest);

    // GNX multi-map: parse "map" field and skip content if map doesn't match
    var _mod_map = variable_struct_exists(_manifest, "map") ? _manifest.map : "vanilla";
    variable_struct_set(global.gnx_mod_map_decl, arg0, _mod_map);

    if (global.gnx_multimap_enabled)
    {
        // Parse map_button BEFORE skip (travel locations needed from all maps)
        if (variable_struct_exists(_manifest, "map_button") && _mod_map != "vanilla" && _mod_map != "all")
        {
            var _mb = _manifest.map_button;
            var _tl = {};
            _tl.target = _mod_map;
            _tl.show_on = "vanilla";
            _tl.label = variable_struct_exists(_mb, "label") ? _mb.label : _mod_map;
            _tl.x = variable_struct_exists(_mb, "x") ? _mb.x : 210;
            _tl.y = variable_struct_exists(_mb, "y") ? _mb.y : 70;
            _tl.mod_name = arg0;
            // Load map sprite if provided
            if (variable_struct_exists(_mb, "map_sprite"))
            {
                var _ms_path = global.gnx_mods_root + arg0 + "/sprites/" + _mb.map_sprite;
                var _ms_cache = _ms_path;
                if (ds_map_exists(global.gnx_sprite_cache, _ms_cache) && sprite_exists(ds_map_find_value(global.gnx_sprite_cache, _ms_cache)))
                    _tl.map_sprite = ds_map_find_value(global.gnx_sprite_cache, _ms_cache);
                else
                {
                    var _ms = sprite_add(_ms_path, 1, false, false, 0, 0);
                    if (_ms != -1)
                    {
                        array_push(global.gnx_runtime_sprites, _ms);
                        ds_map_set(global.gnx_sprite_cache, _ms_cache, _ms);
                    }
                    _tl.map_sprite = _ms;
                }
            }
            else
                _tl.map_sprite = -1;
            // Return button config for this map
            _tl.return_x = variable_struct_exists(_mb, "return_x") ? _mb.return_x : 200;
            _tl.return_y = variable_struct_exists(_mb, "return_y") ? _mb.return_y : 80;
            _tl.return_label = variable_struct_exists(_mb, "return_label") ? _mb.return_label : "Return";
            array_push(global.gnx_travel_locations, _tl);
            _log = file_text_open_append(GNX_LOG);
            file_text_write_string(_log, "[GNX-MAP] travel location: '" + _tl.label + "' -> " + _tl.target + " at (" + string(_tl.x) + "," + string(_tl.y) + ")\n");
            file_text_close(_log);
        }

        if (_mod_map != "all" && _mod_map != global.gnx_active_map)
        {
            _log = file_text_open_append(GNX_LOG);
            file_text_write_string(_log, "[GNX] mod '" + arg0 + "' skipped (map='" + _mod_map + "', active='" + global.gnx_active_map + "')\n");
            file_text_close(_log);
            if (is_array(global.gnx_loaded_mods))
                array_push(global.gnx_loaded_mods, arg0);
            exit;
        }
    }

    if (variable_struct_exists(_manifest, "classes"))
        scr_gnx_load_classes(arg0, _manifest.classes);

    if (variable_struct_exists(_manifest, "cells"))
        scr_gnx_load_cells(arg0, _manifest.cells);

    if (variable_struct_exists(_manifest, "quests"))
        scr_gnx_load_quests(arg0, _manifest.quests);

    if (variable_struct_exists(_manifest, "tools"))
        scr_gnx_load_tools(arg0, _manifest.tools);

    if (variable_struct_exists(_manifest, "sounds"))
        scr_gnx_load_sounds(arg0, _manifest.sounds);

    // Warn about data files present on disk but not declared in manifest
    var _data_files = ["classes.json", "cells.json", "quests.json", "tools.json", "sounds.json"];
    var _data_keys  = ["classes",      "cells",      "quests",      "tools",      "sounds"];
    var _mod_dir = global.gnx_mods_root + arg0 + "/";
    for (var _wi = 0; _wi < array_length(_data_files); _wi++)
    {
        if (file_exists(_mod_dir + _data_files[_wi]) && !variable_struct_exists(_manifest, _data_keys[_wi]))
        {
            _log = file_text_open_append(GNX_LOG);
            file_text_write_string(_log, "[GNX-WARN] mod '" + arg0 + "': " + _data_files[_wi] + " exists but is not declared in manifest.json\n");
            file_text_close(_log);
        }
    }

    if (is_array(global.gnx_loaded_mods))
        array_push(global.gnx_loaded_mods, arg0);
}

/// @desc Initialize or merge per-mod persistent state from manifest save_state block.
///       Called during mod load. If save already has data for this mod, merges new defaults.
/// @arg {string} arg0  mod folder name (unique key)
/// @arg {struct} arg1  parsed manifest
function scr_gnx_init_mod_state(arg0, arg1)
{
    var _mod_name = arg0;
    var _has_save_state = variable_struct_exists(arg1, "save_state");
    var _defaults = {};
    var _schema_ver = 0;

    if (_has_save_state)
    {
        var _ss = arg1.save_state;
        _schema_ver = variable_struct_exists(_ss, "version") ? _ss.version : 1;
        if (variable_struct_exists(_ss, "fields"))
            _defaults = _ss.fields;
    }

    // Store defaults for re-merge after save load (old saves lack gnx_mod_data)
    variable_struct_set(global.gnx_save_state_defaults, _mod_name,
        { version: _schema_ver, fields: _defaults });

    // Check if save already has data for this mod (loaded from save file)
    var _existing = variable_struct_exists(global.val.gnx_mod_data, _mod_name)
        ? variable_struct_get(global.val.gnx_mod_data, _mod_name)
        : undefined;

    if (_existing == undefined)
    {
        // Fresh init: copy all defaults + set _version
        var _state = {};
        _state._version = _schema_ver;
        var _keys = variable_struct_get_names(_defaults);
        for (var _i = 0; _i < array_length(_keys); _i++)
            variable_struct_set(_state, _keys[_i], variable_struct_get(_defaults, _keys[_i]));
        variable_struct_set(global.val.gnx_mod_data, _mod_name, _state);
        _existing = _state;
    }
    else
    {
        // Merge: add any new default fields missing from saved data
        var _keys = variable_struct_get_names(_defaults);
        for (var _i = 0; _i < array_length(_keys); _i++)
        {
            var _k = _keys[_i];
            if (!variable_struct_exists(_existing, _k))
                variable_struct_set(_existing, _k, variable_struct_get(_defaults, _k));
        }
        // Bump schema version if manifest is newer
        var _saved_ver = variable_struct_exists(_existing, "_version") ? _existing._version : 0;
        if (_schema_ver > _saved_ver)
            _existing._version = _schema_ver;
    }

    // Runtime alias for fast access (not persisted)
    variable_struct_set(global.gnx_mod_state, _mod_name, _existing);

    var _log = file_text_open_append(GNX_LOG);
    var _n_keys = array_length(variable_struct_get_names(_existing));
    file_text_write_string(_log, "[GNX] mod_state init: " + _mod_name + " v" + string(_existing._version) + " keys=" + string(_n_keys) + "\n");
    file_text_close(_log);
}

/// @desc Get a value from a mod's persistent state. Returns undefined if mod or key not found.
/// @arg {string} arg0  mod folder name
/// @arg {string} arg1  key
function scr_gnx_get_state(arg0, arg1)
{
    if (!variable_struct_exists(global.gnx_mod_state, arg0))
        return undefined;
    var _state = variable_struct_get(global.gnx_mod_state, arg0);
    if (!variable_struct_exists(_state, arg1))
        return undefined;
    return variable_struct_get(_state, arg1);
}

/// @desc Set a value in a mod's persistent state. Creates the key if it doesn't exist.
///       Returns the previous value, or undefined if key was new.
/// @arg {string} arg0  mod folder name
/// @arg {string} arg1  key
/// @arg           arg2  value
function scr_gnx_set_state(arg0, arg1, arg2)
{
    if (!variable_struct_exists(global.gnx_mod_state, arg0))
    {
        // Mod has no state struct yet -- create one on the fly
        var _state = { _version: 0 };
        variable_struct_set(global.val.gnx_mod_data, arg0, _state);
        variable_struct_set(global.gnx_mod_state, arg0, _state);
    }
    var _state = variable_struct_get(global.gnx_mod_state, arg0);
    var _prev = variable_struct_exists(_state, arg1) ? variable_struct_get(_state, arg1) : undefined;
    variable_struct_set(_state, arg1, arg2);
    return _prev;
}

function scr_gnx_load_cells(arg0, arg1)
{
    var _path = global.gnx_mods_root + arg0 + "/" + arg1;
    
    if (!file_exists(_path))
    {
        gnx_report_mod_error("Mod '" + arg0 + "': cells file '" + arg1 + "' not found");
        exit;
    }

    var _f = file_text_open_read(_path);
    var _raw = "";

    while (!file_text_eof(_f))
        _raw += file_text_readln(_f);

    file_text_close(_f);

    var _cells;
    try
    {
        _cells = json_parse(_raw);
    }
    catch (_e)
    {
        gnx_report_mod_error("Mod '" + arg0 + "': " + arg1 + " invalid (" + string(_e.message) + ")");
        exit;
    }

    var _count = array_length(_cells);
    
    for (var _i = 0; _i < _count; _i++)
        scr_gnx_register_cell(_cells[_i], arg0);
    
    var _log = file_text_open_append(GNX_LOG);
    file_text_write_string(_log, "[GNX] registered " + string(_count) + " cell(s)\n");
    file_text_close(_log);
}

function scr_gnx_register_cell(arg0, arg1)
{
    var _h;
    if (variable_struct_exists(arg0, "h_type"))
        _h = arg0.h_type;
    else
    {
        var _cname = variable_struct_exists(arg0, "name") ? arg0.name : "";
        _h = gnx_hash_cell_id(arg1 + "." + _cname);
        while (ds_map_exists(global.cell_registry, _h))
            _h = 100 + ((_h - 100 + 1) mod 9900);
    }

    if (ds_map_find_value(global.cell_registry, _h) != undefined)
    {
        scr_gnx_patch_cell(_h, arg0, arg1);
        exit;
    }

    if (variable_struct_exists(arg0, "name"))
        ds_map_add(global.gnx_cell_name_to_id, arg1 + "." + arg0.name, _h);
    
    var _phys = arg0.physical;
    var _sprites_dict = variable_struct_exists(arg0, "sprites") ? arg0.sprites : undefined;
    var _base_dir = global.gnx_mods_root + arg1 + "/";
    var _char_row = variable_struct_exists(_phys, "character_row") ? _phys.character_row : 0;
    var _spr_row_pos = _h - _char_row - 1;
    var _raw_layers = _phys.layers;
    var _n_layers = array_length(_raw_layers);
    var _spr_slot = array_create(_n_layers);
    
    for (var _li = 0; _li < _n_layers; _li++)
    {
        var _rl = _raw_layers[_li];
        var _spr = gnx_resolve_layer_sprite(_rl[1], _sprites_dict, _base_dir);

        if (array_length(_rl) >= 5)
            _spr_slot[_li] = [_rl[0], _spr, _rl[2], _rl[3], _rl[4]];
        else
            _spr_slot[_li] = [_rl[0], _spr, _rl[2], _rl[3]];
    }

    // [GNX] Auto-inject essential body layers for fixed/class_map cells.
    // scr_set_slot_spr_part populates spr_slot entries by type (10=head, 6=breast,
    // 7=hand, 8=leg, 9=leg_part). If the modder's layers omit these, body parts
    // won't render even though spr_array defines them.
    var _hspr_mode = variable_struct_exists(arg0, "human_spr") && variable_struct_exists(arg0.human_spr, "mode") ? arg0.human_spr.mode : "base+class";
    if (_hspr_mode == "fixed" || _hspr_mode == "class_map")
    {
        var _essential_types = [10, 6, 7, 8, 9];
        for (var _ei = 0; _ei < array_length(_essential_types); _ei++)
        {
            var _etype = _essential_types[_ei];
            var _found = false;
            for (var _li2 = 0; _li2 < array_length(_spr_slot); _li2++)
            {
                if (_spr_slot[_li2][0] == _etype) { _found = true; break; }
            }
            if (!_found)
            {
                // Inject placeholder matching vanilla format.
                // Type 10 (head): [type, spr, -2, c_spr, false, hair_spr] (6 fields)
                // Others: [type, spr, false, c_spr, false] (5 fields)
                if (_etype == 10)
                    array_push(_spr_slot, [_etype, -1, -2, -1, false, -1]);
                else
                    array_push(_spr_slot, [_etype, -1, false, -1, false]);
            }
        }
    }

    var _scr_idle = gnx_resolve_script(_phys.scr_idle);
    var _raw_h = _phys.scr_h;
    var _n_h = array_length(_raw_h);
    var _scr_h = array_create(_n_h);
    
    for (var _si = 0; _si < _n_h; _si++)
        _scr_h[_si] = gnx_resolve_script(_raw_h[_si]);
    
    var _scr_draw = gnx_resolve_script(_phys.scr_draw);
    var _sp_spr_raw = variable_struct_exists(_phys, "sp_spr") ? _phys.sp_spr : -1;
    var _sp_spr = gnx_resolve_layer_sprite(_sp_spr_raw, _sprites_dict, _base_dir);
    var _spr_wall = -1;
    
    if (_sprites_dict != undefined && variable_struct_exists(_sprites_dict, "wall"))
        _spr_wall = gnx_resolve_sprite(_sprites_dict, "wall", _base_dir, -1);
    
    var _cell = 
    {
        h_type: _h,
        slot_type: variable_struct_exists(arg0, "slot_type") ? arg0.slot_type : 0,
        name: arg0.name,
        gnx_price: variable_struct_exists(arg0, "price") ? arg0.price : 100,
        gnx_code_text: variable_struct_exists(arg0, "code_text") ? arg0.code_text : -1,
        gnx_spawn_info: variable_struct_exists(arg0, "spawn_info") ? arg0.spawn_info : -1,
        physical: 
        {
            allow_preg: _phys.allow_preg,
            max_mon_num: _phys.max_mon_num,
            anal: _phys.anal,
            spr_row_pos: _spr_row_pos,
            slot_dirt_init: _phys.slot_dirt_init,
            spr_slot_template: _spr_slot,
            scr_slot_template: 
            {
                idle: _scr_idle,
                h: _scr_h
            },
            scr_draw_special: _scr_draw,
            hand_x: _phys.hand_x,
            hand_y: _phys.hand_y,
            hand_xscale: _phys.hand_xscale,
            hand_angle: _phys.hand_angle,
            sp_spr: _sp_spr,
            sq_x: _phys.sq_x,
            sq_y: _phys.sq_y,
            sp_x: _phys.sp_x,
            sp_y: _phys.sp_y,
            sp_anim_x: _phys.sp_anim_x,
            sp_anim_y: _phys.sp_anim_y
        },
        gnx_spr_wall: _spr_wall,
        human_spr: 
        {
            mode: arg0.human_spr.mode,
            base_body: arg0.human_spr.base_body
        },
        mon_spr: gnx_resolve_mon_spr(variable_struct_exists(arg0, "mon_spr") ? arg0.mon_spr : undefined, _sprites_dict, _base_dir)
    };
    var _cp = _cell.physical;
    
    if (variable_struct_exists(_phys, "hand_frames"))
        _cp.hand_frames = _phys.hand_frames;
    
    if (variable_struct_exists(_phys, "sign_y_base"))
    {
        _cp.sign_y_base = _phys.sign_y_base;
        _cp.sign_y_jitter = variable_struct_exists(_phys, "sign_y_jitter") ? _phys.sign_y_jitter : 2;
    }
    
    if (variable_struct_exists(_phys, "milk_step"))
        _cp.milk_step = _phys.milk_step;
    
    if (variable_struct_exists(_phys, "drink_num"))
        _cp.drink_num = _phys.drink_num;
    
    if (variable_struct_exists(_phys, "mon_index"))
        _cp.mon_index = _phys.mon_index;
    
    if (variable_struct_exists(_phys, "blink_spr"))
        _cp.blink_spr = gnx_resolve_layer_sprite(_phys.blink_spr, _sprites_dict, _base_dir);
    
    if (variable_struct_exists(_phys, "anim_struct_overrides"))
        _cp.anim_struct_overrides = _phys.anim_struct_overrides;
    
    if (variable_struct_exists(_phys, "visual"))
        _cp.visual = _phys.visual;
    
    if (variable_struct_exists(_phys, "slot_front"))
        _cp.slot_front = gnx_resolve_layer_sprite(_phys.slot_front, _sprites_dict, _base_dir);
    
    if (variable_struct_exists(_phys, "sp_place_init"))
        _cp.sp_place_init = _phys.sp_place_init;
    
    if (variable_struct_exists(_phys, "set_timer"))
        _cp.set_timer = _phys.set_timer;
    
    if (variable_struct_exists(_phys, "slot_range"))
        _cp.slot_range = _phys.slot_range;
    
    if (variable_struct_exists(_phys, "slot_h"))
        _cp.slot_h = _phys.slot_h;
    
    if (variable_struct_exists(_phys, "scr_slot_step"))
        _cp.scr_slot_step = asset_get_index(_phys.scr_slot_step);
    
    if (variable_struct_exists(_phys, "scr_slot_base"))
        _cp.scr_slot_base = asset_get_index(_phys.scr_slot_base);
    
    if (variable_struct_exists(_phys, "candle_index"))
        _cp.candle_index = _phys.candle_index;
    
    if (variable_struct_exists(_phys, "milk_num"))
        _cp.milk_num = _phys.milk_num;
    
    if (variable_struct_exists(_phys, "clone_wait"))
        _cp.clone_wait = _phys.clone_wait;
    
    if (variable_struct_exists(_phys, "bar_glow_rep"))
        _cp.bar_glow_rep = _phys.bar_glow_rep;
    
    if (variable_struct_exists(_phys, "extra_spawn_part"))
        _cp.extra_spawn_part = _phys.extra_spawn_part;
    
    if (variable_struct_exists(_phys, "dirt_fix_inc"))
        _cp.dirt_fix_inc = _phys.dirt_fix_inc;
    
    if (variable_struct_exists(_phys, "death_fix_inc"))
        _cp.death_fix_inc = _phys.death_fix_inc;
    
    if (variable_struct_exists(_phys, "del_item_type"))
        _cp.del_item_type = _phys.del_item_type;

    if (variable_struct_exists(_phys, "required_class"))
    {
        _cp.required_class = _phys.required_class;
        if (is_array(_cp.required_class))
        {
            var _rc = _cp.required_class;
            var _rc_len = array_length(_rc);
            var _rc_out = [];
            var _ri = 0;
            repeat (_rc_len)
            {
                var _rv = _rc[_ri];
                var _rm = ds_map_find_value(global.gnx_class_name_to_id, _rv);
                if (_rm != undefined)
                    array_push(_rc_out, _rm);
                else
                {
                    array_push(_rc_out, _rv);
                    var _wlog = file_text_open_append(GNX_LOG);
                    file_text_write_string(_wlog, "[GNX-WARN] cell h=" + string(_h) + " required_class ref '" + string(_rv) + "' not found. Check: folder name + class name must match exactly (case-sensitive).\n");
                    file_text_close(_wlog);
                }
                _ri++;
            }
            _cp.required_class = _rc_out;
        }
        else
        {
            var _rm = ds_map_find_value(global.gnx_class_name_to_id, _cp.required_class);
            if (_rm != undefined)
                _cp.required_class = _rm;
            else
            {
                var _wlog = file_text_open_append(GNX_LOG);
                file_text_write_string(_wlog, "[GNX-WARN] cell h=" + string(_h) + " required_class ref '" + string(_cp.required_class) + "' not found. Check: folder name + class name must match exactly (case-sensitive).\n");
                file_text_close(_wlog);
            }
        }
    }

    if (variable_struct_exists(_phys, "range_draw_func"))
        _cp.range_draw_func = gnx_resolve_script(_phys.range_draw_func);

    if (variable_struct_exists(_phys, "scr_unoccupy"))
        _cp.scr_unoccupy = gnx_resolve_script(_phys.scr_unoccupy);

    // GNX sound: cell sfx_type (e.g. "bj")
    if (variable_struct_exists(arg0, "sfx_type"))
        _cell.sfx_type = arg0.sfx_type;

    // Resolve human_spr phases for fixed + class_map modes
    var _hspr = arg0.human_spr;
    var _chspr = _cell.human_spr;

    if (_chspr.mode == "fixed")
    {
        if (variable_struct_exists(_hspr, "phase_0"))
            _chspr.phase_0 = gnx_resolve_special_phase(_hspr.phase_0, _sprites_dict, _base_dir);
        if (variable_struct_exists(_hspr, "phase_1"))
            _chspr.phase_1 = gnx_resolve_special_phase(_hspr.phase_1, _sprites_dict, _base_dir);
        if (variable_struct_exists(_hspr, "phase_2"))
            _chspr.phase_2 = gnx_resolve_special_phase(_hspr.phase_2, _sprites_dict, _base_dir);
        if (variable_struct_exists(_hspr, "phase_4"))
            _chspr.phase_4 = gnx_resolve_special_phase(_hspr.phase_4, _sprites_dict, _base_dir);
    }
    else if (_chspr.mode == "class_map")
    {
        // Resolve default entry phases
        if (variable_struct_exists(_hspr, "default"))
        {
            var _def_src = variable_struct_get(_hspr, "default");
            var _def_out = {};
            if (variable_struct_exists(_def_src, "phase_0"))
                _def_out.phase_0 = gnx_resolve_special_phase(_def_src.phase_0, _sprites_dict, _base_dir);
            if (variable_struct_exists(_def_src, "phase_1"))
                _def_out.phase_1 = gnx_resolve_special_phase(_def_src.phase_1, _sprites_dict, _base_dir);
            if (variable_struct_exists(_def_src, "phase_2"))
                _def_out.phase_2 = gnx_resolve_special_phase(_def_src.phase_2, _sprites_dict, _base_dir);
            if (variable_struct_exists(_def_src, "phase_4"))
                _def_out.phase_4 = gnx_resolve_special_phase(_def_src.phase_4, _sprites_dict, _base_dir);
            variable_struct_set(_chspr, "default", _def_out);
        }

        // Resolve per-class entries
        if (variable_struct_exists(_hspr, "classes"))
        {
            var _cls_src = _hspr.classes;
            var _cls_out = {};
            var _cls_keys = variable_struct_get_names(_cls_src);
            var _ci = 0;
            repeat (array_length(_cls_keys))
            {
                var _ck = _cls_keys[_ci++];
                var _ce = variable_struct_get(_cls_src, _ck);
                var _ce_out = {};
                if (variable_struct_exists(_ce, "phase_0"))
                    _ce_out.phase_0 = gnx_resolve_special_phase(_ce.phase_0, _sprites_dict, _base_dir);
                if (variable_struct_exists(_ce, "phase_1"))
                    _ce_out.phase_1 = gnx_resolve_special_phase(_ce.phase_1, _sprites_dict, _base_dir);
                if (variable_struct_exists(_ce, "phase_2"))
                    _ce_out.phase_2 = gnx_resolve_special_phase(_ce.phase_2, _sprites_dict, _base_dir);
                if (variable_struct_exists(_ce, "phase_4"))
                    _ce_out.phase_4 = gnx_resolve_special_phase(_ce.phase_4, _sprites_dict, _base_dir);

                // Resolve string class ref to int key (cross-mod refs deferred)
                var _resolved_key = _ck;
                var _rid = ds_map_find_value(global.gnx_class_name_to_id, _ck);
                if (_rid != undefined)
                    _resolved_key = string(_rid);

                variable_struct_set(_cls_out, _resolved_key, _ce_out);
            }
            _chspr.classes = _cls_out;
        }
    }

    if (variable_struct_exists(arg0, "mon_spr_hob"))
        _cell.mon_spr_hob = gnx_resolve_mon_spr(arg0.mon_spr_hob, _sprites_dict, _base_dir);

    if (variable_struct_exists(arg0, "mon_spr_ogr"))
        _cell.mon_spr_ogr = gnx_resolve_mon_spr(arg0.mon_spr_ogr, _sprites_dict, _base_dir);

    if (variable_struct_exists(arg0, "mon_types"))
        _cell.mon_types = arg0.mon_types;

    ds_map_add(global.cell_registry, _h, _cell);
    var _log2 = file_text_open_append(GNX_LOG);
    file_text_write_string(_log2, "[GNX] cell sprites h=" + string(_h) + ":");
    
    for (var _di = 0; _di < array_length(_spr_slot); _di++)
        file_text_write_string(_log2, " [" + string(_di) + "]=" + string(_spr_slot[_di][1]));
    
    file_text_write_string(_log2, "\n");
    file_text_close(_log2);
    var _cat = arg0.category;

    // Build-menu order arrays. Small cells: breed/utility/pleasure.
    // Big cells: b_breed/b_utility/b_other (note b_other uses b_pleasure_order).
    // Tent cells: t_breed/t_utility.
    switch (_cat)
    {
        case "breed":     array_push(global.breed_order, _h);      break;
        case "utility":   array_push(global.utility_order, _h);    break;
        case "pleasure":  array_push(global.pleasure_order, _h);   break;
        case "b_breed":   array_push(global.b_breed_order, _h);    break;
        case "b_utility": array_push(global.b_utility_order, _h);  break;
        case "b_other":   array_push(global.b_pleasure_order, _h); break;
        case "t_breed":   array_push(global.t_breed_order, _h);    break;
        case "t_utility": array_push(global.t_utility_order, _h);  break;
    }

    array_push(global.gnx_registered_cells,
    {
        h_type: _h,
        category: _cat
    });
    var _log = file_text_open_append(GNX_LOG);
    file_text_write_string(_log, "[GNX] cell OK: h=" + string(_h) + " name=" + string(arg0.name) + " cat=" + string(_cat) + "\n");
    file_text_close(_log);
}

function scr_gnx_patch_cell(arg0, arg1, arg2)
{
    var _cell = ds_map_find_value(global.cell_registry, arg0);
    
    if (_cell == undefined)
    {
        _log = file_text_open_append(GNX_LOG);
        file_text_write_string(_log, "[GNX] patch h=" + string(arg0) + " not in registry, aborting\n");
        file_text_close(_log);
        exit;
    }
    
    // Warn if patching a vanilla h_type (1-42) — modder likely wants a new cell, not an override
    if (arg0 >= 1 && arg0 <= 42)
    {
        var _log = file_text_open_append(GNX_LOG);
        file_text_write_string(_log, "[GNX-WARN] mod '" + arg2 + "' patches vanilla cell h=" + string(arg0) + " (h_type 1-42 are vanilla). Remove 'h_type' from cells.json to auto-assign a unique ID.\n");
        file_text_close(_log);
    }

    var _base_dir = global.gnx_mods_root + arg2 + "/";
    var _sprites_dict = variable_struct_exists(arg1, "sprites") ? arg1.sprites : undefined;

    if (variable_struct_exists(arg1, "name"))
        _cell.name = arg1.name;

    if (variable_struct_exists(arg1, "price"))
        _cell.gnx_price = arg1.price;

    if (variable_struct_exists(arg1, "code_text"))
        _cell.gnx_code_text = arg1.code_text;

    if (variable_struct_exists(arg1, "spawn_info"))
        _cell.gnx_spawn_info = arg1.spawn_info;
    
    if (variable_struct_exists(arg1, "slot_type"))
        _cell.slot_type = arg1.slot_type;
    
    if (variable_struct_exists(arg1, "human_spr"))
    {
        var _hs = arg1.human_spr;
        
        if (variable_struct_exists(_hs, "mode"))
            _cell.human_spr.mode = _hs.mode;
        
        if (variable_struct_exists(_hs, "base_body"))
            _cell.human_spr.base_body = _hs.base_body;
    }
    
    if (variable_struct_exists(arg1, "physical"))
    {
        var _phys = arg1.physical;
        var _cp = _cell.physical;
        
        if (variable_struct_exists(_phys, "allow_preg"))
            _cp.allow_preg = _phys.allow_preg;
        
        if (variable_struct_exists(_phys, "max_mon_num"))
            _cp.max_mon_num = _phys.max_mon_num;
        
        if (variable_struct_exists(_phys, "anal"))
            _cp.anal = _phys.anal;
        
        if (variable_struct_exists(_phys, "slot_dirt_init"))
            _cp.slot_dirt_init = _phys.slot_dirt_init;
        
        if (variable_struct_exists(_phys, "hand_x"))
            _cp.hand_x = _phys.hand_x;
        
        if (variable_struct_exists(_phys, "hand_y"))
            _cp.hand_y = _phys.hand_y;
        
        if (variable_struct_exists(_phys, "hand_xscale"))
            _cp.hand_xscale = _phys.hand_xscale;
        
        if (variable_struct_exists(_phys, "hand_angle"))
            _cp.hand_angle = _phys.hand_angle;
        
        if (variable_struct_exists(_phys, "hand_frames"))
            _cp.hand_frames = _phys.hand_frames;
        
        if (variable_struct_exists(_phys, "sq_x"))
            _cp.sq_x = _phys.sq_x;
        
        if (variable_struct_exists(_phys, "sq_y"))
            _cp.sq_y = _phys.sq_y;
        
        if (variable_struct_exists(_phys, "sp_x"))
            _cp.sp_x = _phys.sp_x;
        
        if (variable_struct_exists(_phys, "sp_y"))
            _cp.sp_y = _phys.sp_y;
        
        if (variable_struct_exists(_phys, "sp_anim_x"))
            _cp.sp_anim_x = _phys.sp_anim_x;
        
        if (variable_struct_exists(_phys, "sp_anim_y"))
            _cp.sp_anim_y = _phys.sp_anim_y;
        
        if (variable_struct_exists(_phys, "character_row"))
            _cp.spr_row_pos = arg0 - _phys.character_row - 1;
        
        if (variable_struct_exists(_phys, "sp_spr"))
            _cp.sp_spr = gnx_resolve_layer_sprite(_phys.sp_spr, _sprites_dict, _base_dir);
        
        if (variable_struct_exists(_phys, "layers"))
        {
            var _raw_layers = _phys.layers;
            var _n_layers = array_length(_raw_layers);
            var _spr_slot = array_create(_n_layers);
            
            for (var _li = 0; _li < _n_layers; _li++)
            {
                var _rl = _raw_layers[_li];
                var _spr = gnx_resolve_layer_sprite(_rl[1], _sprites_dict, _base_dir);
                
                if (array_length(_rl) >= 5)
                    _spr_slot[_li] = [_rl[0], _spr, _rl[2], _rl[3], _rl[4]];
                else
                    _spr_slot[_li] = [_rl[0], _spr, _rl[2], _rl[3]];
            }
            
            _cp.spr_slot_template = _spr_slot;
        }
        
        if (variable_struct_exists(_phys, "scr_idle"))
            _cp.scr_slot_template.idle = gnx_resolve_script(_phys.scr_idle);
        
        if (variable_struct_exists(_phys, "scr_h"))
        {
            var _raw_h = _phys.scr_h;
            var _n_h = array_length(_raw_h);
            var _scr_h = array_create(_n_h);
            
            for (var _si = 0; _si < _n_h; _si++)
                _scr_h[_si] = gnx_resolve_script(_raw_h[_si]);
            
            _cp.scr_slot_template.h = _scr_h;
        }
        
        if (variable_struct_exists(_phys, "scr_draw"))
            _cp.scr_draw_special = gnx_resolve_script(_phys.scr_draw);

        if (variable_struct_exists(_phys, "required_class"))
        {
            _cp.required_class = _phys.required_class;
            if (is_array(_cp.required_class))
            {
                var _rc = _cp.required_class;
                var _rc_len = array_length(_rc);
                var _rc_out = [];
                var _ri = 0;
                repeat (_rc_len)
                {
                    var _rv = _rc[_ri];
                    var _rm = ds_map_find_value(global.gnx_class_name_to_id, _rv);
                    if (_rm != undefined)
                        array_push(_rc_out, _rm);
                    else
                    {
                        array_push(_rc_out, _rv);
                        var _wlog = file_text_open_append(GNX_LOG);
                        file_text_write_string(_wlog, "[GNX-WARN] cell h=" + string(arg0) + " required_class ref '" + string(_rv) + "' not found. Check: folder name + class name must match exactly (case-sensitive).\n");
                        file_text_close(_wlog);
                    }
                    _ri++;
                }
                _cp.required_class = _rc_out;
            }
            else
            {
                var _rm = ds_map_find_value(global.gnx_class_name_to_id, _cp.required_class);
                if (_rm != undefined)
                    _cp.required_class = _rm;
                else
                {
                    var _wlog = file_text_open_append(GNX_LOG);
                    file_text_write_string(_wlog, "[GNX-WARN] cell h=" + string(arg0) + " required_class ref '" + string(_cp.required_class) + "' not found. Check: folder name + class name must match exactly (case-sensitive).\n");
                    file_text_close(_wlog);
                }
            }
        }

        if (variable_struct_exists(_phys, "range_draw_func"))
            _cp.range_draw_func = gnx_resolve_script(_phys.range_draw_func);

        if (variable_struct_exists(_phys, "scr_unoccupy"))
            _cp.scr_unoccupy = gnx_resolve_script(_phys.scr_unoccupy);
    }

    if (variable_struct_exists(arg1, "mon_spr"))
        _cell.mon_spr = gnx_resolve_mon_spr(arg1.mon_spr, _sprites_dict, _base_dir);
    
    if (variable_struct_exists(arg1, "mon_spr_hob"))
        _cell.mon_spr_hob = gnx_resolve_mon_spr(arg1.mon_spr_hob, _sprites_dict, _base_dir);
    
    if (variable_struct_exists(arg1, "mon_spr_ogr"))
        _cell.mon_spr_ogr = gnx_resolve_mon_spr(arg1.mon_spr_ogr, _sprites_dict, _base_dir);

    if (variable_struct_exists(arg1, "mon_types"))
        _cell.mon_types = arg1.mon_types;

    if (variable_struct_exists(arg1, "sfx_type"))
        _cell.sfx_type = arg1.sfx_type;

    if (_sprites_dict != undefined && variable_struct_exists(_sprites_dict, "wall"))
        _cell.gnx_spr_wall = gnx_resolve_sprite(_sprites_dict, "wall", _base_dir, -1);

    _cell.gnx_patched = true;
    var _log = file_text_open_append(GNX_LOG);
    file_text_write_string(_log, "[GNX] patched h=" + string(arg0) + " by mod=" + string(arg2) + "\n");
    file_text_close(_log);
}

function gnx_resolve_mspr_spr(arg0, arg1, arg2)
{
    if (arg0 == undefined || arg0 == -1)
        return -1;
    
    return gnx_resolve_layer_sprite(arg0, arg1, arg2);
}

function gnx_resolve_mspr_pair(arg0, arg1, arg2)
{
    if (arg0 == undefined)
        return [-1, -1];
    
    if (is_struct(arg0) && variable_struct_exists(arg0, "alpha"))
    {
        var _a = gnx_resolve_layer_sprite(arg0.alpha, arg1, arg2);
        var _l = variable_struct_exists(arg0, "line") ? gnx_resolve_layer_sprite(arg0.line, arg1, arg2) : -1;
        return [_a, _l];
    }
    
    return [gnx_resolve_layer_sprite(arg0, arg1, arg2), -1];
}

function gnx_resolve_mspr_body_variants(arg0, arg1, arg2, arg3, arg4)
{
    var _vkeys = ["leg_any", "leg_1", "leg_2", "cow", "lilith"];
    var _bsuffs = ["_any", "_leg1", "_leg2", "_cow", "_lilith"];
    
    for (var _i = 0; _i < 5; _i++)
    {
        var _entry = (arg0 != undefined && variable_struct_exists(arg0, _vkeys[_i])) ? variable_struct_get(arg0, _vkeys[_i]) : undefined;
        var _pair = gnx_resolve_mspr_pair(_entry, arg1, arg2);
        variable_struct_set(arg3, arg4 + "_body_b" + _bsuffs[_i], _pair[0]);
        variable_struct_set(arg3, arg4 + "_body_l" + _bsuffs[_i], _pair[1]);
    }
}

function gnx_resolve_mspr_hand_variants(arg0, arg1, arg2, arg3, arg4)
{
    var _vkeys = ["leg_any", "leg_1", "leg_2", "cow"];
    var _bsuffs = ["_any", "_leg1", "_leg2", "_cow"];
    
    for (var _i = 0; _i < 4; _i++)
    {
        var _entry = (arg0 != undefined && variable_struct_exists(arg0, _vkeys[_i])) ? variable_struct_get(arg0, _vkeys[_i]) : undefined;
        var _pair = gnx_resolve_mspr_pair(_entry, arg1, arg2);
        variable_struct_set(arg3, arg4 + "_hand_b" + _bsuffs[_i], _pair[0]);
        variable_struct_set(arg3, arg4 + "_hand_l" + _bsuffs[_i], _pair[1]);
    }
}

function gnx_resolve_mspr_class_variants(arg0, arg1, arg2, arg3, arg4)
{
    var _ckeys = ["default", "cow", "nyx", "lilith", "morrigan", "cat"];
    var _csuffs = ["_def", "_cow", "_nyx", "_lilith", "_morrigan", "_cat"];
    
    for (var _i = 0; _i < 6; _i++)
    {
        var _val;
        
        if (arg0 == undefined)
            _val = undefined;
        else if (is_string(arg0))
            _val = (_i == 0) ? arg0 : undefined;
        else if (is_struct(arg0))
            _val = variable_struct_exists(arg0, _ckeys[_i]) ? variable_struct_get(arg0, _ckeys[_i]) : undefined;
        else
            _val = undefined;
        
        variable_struct_set(arg3, arg4 + _csuffs[_i], gnx_resolve_mspr_spr(_val, arg1, arg2));
    }
}

function gnx_resolve_mon_spr(arg0, arg1, arg2)
{
    if (arg0 == undefined || arg0 == -1)
        return undefined;
    
    var _out = {};
    var _s = variable_struct_exists(arg0, "start") ? arg0.start : undefined;
    var _lo = variable_struct_exists(arg0, "loop") ? arg0.loop : undefined;
    gnx_resolve_mspr_body_variants((_s != undefined && variable_struct_exists(_s, "body")) ? _s.body : undefined, arg1, arg2, _out, "s");
    var _hp = gnx_resolve_mspr_pair((_s != undefined && variable_struct_exists(_s, "hand")) ? _s.hand : undefined, arg1, arg2);
    _out.s_hand_b = _hp[0];
    _out.s_hand_l = _hp[1];
    _out.s_pen = gnx_resolve_mspr_spr((_s != undefined && variable_struct_exists(_s, "pen")) ? _s.pen : undefined, arg1, arg2);
    gnx_resolve_mspr_class_variants((_s != undefined && variable_struct_exists(_s, "touch")) ? _s.touch : undefined, arg1, arg2, _out, "s_touch");
    _out.s_hand_xscale_random = _s != undefined && variable_struct_exists(_s, "hand_xscale") && _s.hand_xscale == "random";
    var _head = (_lo != undefined && variable_struct_exists(_lo, "head")) ? _lo.head : undefined;
    
    if (is_array(_head) && array_length(_head) >= 1)
    {
        var _h0 = gnx_resolve_mspr_pair(_head[0], arg1, arg2);
        var _h1 = (array_length(_head) >= 2) ? gnx_resolve_mspr_pair(_head[1], arg1, arg2) : _h0;
        _out.lo_head_b_0 = _h0[0];
        _out.lo_head_l_0 = _h0[1];
        _out.lo_head_b_1 = _h1[0];
        _out.lo_head_l_1 = _h1[1];
    }
    else
    {
        var _hp2 = gnx_resolve_mspr_pair(_head, arg1, arg2);
        _out.lo_head_b_0 = _hp2[0];
        _out.lo_head_l_0 = _hp2[1];
        _out.lo_head_b_1 = _hp2[0];
        _out.lo_head_l_1 = _hp2[1];
    }
    
    gnx_resolve_mspr_body_variants((_lo != undefined && variable_struct_exists(_lo, "body")) ? _lo.body : undefined, arg1, arg2, _out, "lo");
    gnx_resolve_mspr_hand_variants((_lo != undefined && variable_struct_exists(_lo, "hand")) ? _lo.hand : undefined, arg1, arg2, _out, "lo");
    _out.lo_pen = gnx_resolve_mspr_spr((_lo != undefined && variable_struct_exists(_lo, "pen")) ? _lo.pen : undefined, arg1, arg2);
    gnx_resolve_mspr_class_variants((_lo != undefined && variable_struct_exists(_lo, "touch")) ? _lo.touch : undefined, arg1, arg2, _out, "lo_touch");
    gnx_resolve_mspr_class_variants((_lo != undefined && variable_struct_exists(_lo, "enter")) ? _lo.enter : undefined, arg1, arg2, _out, "lo_enter");
    var _ej = variable_struct_exists(arg0, "ej") ? arg0.ej : undefined;
    
    if (_ej != undefined)
    {
        gnx_resolve_mspr_body_variants(variable_struct_exists(_ej, "body") ? _ej.body : undefined, arg1, arg2, _out, "ej");
        gnx_resolve_mspr_hand_variants(variable_struct_exists(_ej, "hand") ? _ej.hand : undefined, arg1, arg2, _out, "ej");
        _out.ej_pen = gnx_resolve_mspr_spr(variable_struct_exists(_ej, "pen") ? _ej.pen : undefined, arg1, arg2);
        gnx_resolve_mspr_class_variants(variable_struct_exists(_ej, "touch") ? _ej.touch : undefined, arg1, arg2, _out, "ej_touch");
        gnx_resolve_mspr_class_variants(variable_struct_exists(_ej, "enter") ? _ej.enter : undefined, arg1, arg2, _out, "ej_enter");
        var _ej_head = variable_struct_exists(_ej, "head") ? _ej.head : undefined;
        
        if (is_array(_ej_head) && array_length(_ej_head) >= 1)
        {
            var _h0 = gnx_resolve_mspr_pair(_ej_head[0], arg1, arg2);
            var _h1 = (array_length(_ej_head) >= 2) ? gnx_resolve_mspr_pair(_ej_head[1], arg1, arg2) : _h0;
            _out.ej_head_b_0 = _h0[0];
            _out.ej_head_l_0 = _h0[1];
            _out.ej_head_b_1 = _h1[0];
            _out.ej_head_l_1 = _h1[1];
        }
    }
    
    return _out;
}

/// @desc Load quests.json for a mod: portraits, events, triggers.
/// @arg {string} arg0  mod folder name
/// @arg {string} arg1  quests filename (from manifest)
function scr_gnx_load_quests(arg0, arg1)
{
    var _path = global.gnx_mods_root + arg0 + "/" + arg1;

    if (!file_exists(_path))
    {
        gnx_report_mod_error("Mod '" + arg0 + "': quests file '" + arg1 + "' not found");
        exit;
    }

    var _f = file_text_open_read(_path);
    var _raw = "";
    while (!file_text_eof(_f))
        _raw += file_text_readln(_f);
    file_text_close(_f);

    var _data;
    try { _data = json_parse(_raw); }
    catch (_e)
    {
        gnx_report_mod_error("Mod '" + arg0 + "': " + arg1 + " invalid (" + string(_e.message) + ")");
        exit;
    }

    var _base_dir = global.gnx_mods_root + arg0 + "/";
    var _log = file_text_open_append(GNX_LOG);
    var _portrait_count = 0;
    var _popup_count = 0;
    var _event_count = 0;
    var _trigger_count = 0;

    // --- Load portraits ---
    if (variable_struct_exists(_data, "portraits"))
    {
        var _pkeys = variable_struct_get_names(_data.portraits);
        for (var _pi = 0; _pi < array_length(_pkeys); _pi++)
        {
            var _pk = _pkeys[_pi];
            var _pdef = variable_struct_get(_data.portraits, _pk);
            var _strip_path = _base_dir + "portraits/" + _pdef.strip;
            var _frames = variable_struct_exists(_pdef, "frames") ? _pdef.frames : 1;
            var _full_key = arg0 + "." + _pk;

            if (file_exists(_strip_path))
            {
                // Check sprite cache first
                var _cache_key = _strip_path;
                var _spr = ds_map_find_value(global.gnx_sprite_cache, _cache_key);
                if (_spr == undefined)
                {
                    _spr = sprite_add(_strip_path, _frames, false, false, 0, 0);
                    if (_spr != -1)
                    {
                        array_push(global.gnx_runtime_sprites, _spr);
                        ds_map_add(global.gnx_sprite_cache, _cache_key, _spr);
                    }
                }
                if (_spr != -1)
                {
                    ds_map_add(global.gnx_portraits, _full_key, _spr);
                    _portrait_count++;
                }
                else
                    file_text_write_string(_log, "[GNX] portrait '" + _full_key + "': sprite_add failed\n");
            }
            else
                file_text_write_string(_log, "[GNX] portrait '" + _full_key + "': file not found (" + _strip_path + ")\n");
        }
    }

    // --- Load popups ---
    if (variable_struct_exists(_data, "popups"))
    {
        var _pkeys = variable_struct_get_names(_data.popups);
        for (var _pi = 0; _pi < array_length(_pkeys); _pi++)
        {
            var _pk = _pkeys[_pi];
            var _full_key = arg0 + "." + _pk;
            var _text = variable_struct_get(_data.popups, _pk);
            ds_map_add(global.gnx_popups, _full_key, _text);
            file_text_write_string(_log, "[GNX] popup " + _full_key + " = \"" + string(_text) + "\"\n");
            _popup_count++;
        }
    }

    // --- Load events ---
    if (variable_struct_exists(_data, "events"))
    {
        var _ekeys = variable_struct_get_names(_data.events);
        for (var _ei = 0; _ei < array_length(_ekeys); _ei++)
        {
            var _ek = _ekeys[_ei];
            var _edef = variable_struct_get(_data.events, _ek);
            var _full_id = arg0 + "." + _ek;

            // Stamp mod_name + full_id onto the event struct for runtime use
            _edef.mod_name = arg0;
            _edef.event_id = _full_id;

            // Resolve portrait refs in dialog lines: string key -> runtime sprite id
            if (variable_struct_exists(_edef, "dialog"))
            {
                var _dlines = _edef.dialog;
                for (var _di = 0; _di < array_length(_dlines); _di++)
                {
                    var _line = _dlines[_di];
                    if (is_string(_line.portrait))
                    {
                        var _pref = arg0 + "." + _line.portrait;
                        var _pspr = ds_map_find_value(global.gnx_portraits, _pref);
                        _line.portrait_spr = (_pspr != undefined) ? _pspr : -1;
                    }
                    else
                        _line.portrait_spr = _line.portrait; // -1 or numeric = vanilla
                }
            }

            // Resolve next_event to full id
            if (variable_struct_exists(_edef, "next_event") && is_string(_edef.next_event))
                _edef.next_event = arg0 + "." + _edef.next_event;

            // Resolve string refs in completion conditions
            if (variable_struct_exists(_edef, "completion"))
                scr_gnx_resolve_condition_refs(_edef.completion, arg0);

            // Resolve string refs in side_effects
            if (variable_struct_exists(_edef, "side_effects"))
            {
                var _se = _edef.side_effects;
                for (var _si = 0; _si < array_length(_se); _si++)
                    scr_gnx_resolve_side_effect_refs(_se[_si], arg0);
            }

            ds_map_add(global.gnx_quest_events, _full_id, _edef);
            file_text_write_string(_log, "[GNX] event " + _full_id + " type=" + _edef.type);
            if (_edef.type == "quest")
                file_text_write_string(_log, " text=\"" + string(_edef.quest_text) + "\"");
            if (variable_struct_exists(_edef, "dialog"))
                file_text_write_string(_log, " dialog=" + string(array_length(_edef.dialog)) + " lines");
            if (variable_struct_exists(_edef, "next_event") && _edef.next_event != undefined)
                file_text_write_string(_log, " next=" + string(_edef.next_event));
            file_text_write_string(_log, "\n");
            _event_count++;
        }
    }

    // --- Load triggers ---
    if (variable_struct_exists(_data, "triggers"))
    {
        var _trigs = _data.triggers;
        for (var _ti = 0; _ti < array_length(_trigs); _ti++)
        {
            var _tdef = _trigs[_ti];
            _tdef.mod_name = arg0;

            // Resolve event ref to full id
            if (is_string(_tdef.event))
                _tdef.event = arg0 + "." + _tdef.event;

            // Resolve string refs in conditions
            if (variable_struct_exists(_tdef, "conditions"))
            {
                var _conds = _tdef.conditions;
                for (var _ci = 0; _ci < array_length(_conds); _ci++)
                    scr_gnx_resolve_condition_refs(_conds[_ci], arg0);
            }

            array_push(global.gnx_quest_triggers, _tdef);
            var _nconds = variable_struct_exists(_tdef, "conditions") ? array_length(_tdef.conditions) : 0;
            file_text_write_string(_log, "[GNX] trigger hook=" + _tdef.hook + " event=" + string(_tdef.event) + " conditions=" + string(_nconds) + "\n");
            _trigger_count++;
        }
    }

    file_text_write_string(_log, "[GNX] quests loaded: " + string(_event_count) + " events, "
        + string(_trigger_count) + " triggers, " + string(_portrait_count) + " portraits, "
        + string(_popup_count) + " popups\n");
    file_text_close(_log);
}

/// @desc Resolve string class/cell refs in a condition struct to integer IDs.
/// @arg {struct} arg0  condition struct
/// @arg {string} arg1  mod folder name (for unqualified refs)
function scr_gnx_resolve_condition_refs(arg0, arg1)
{
    // class ref (e.g. boss_captured condition)
    if (variable_struct_exists(arg0, "class") && is_string(arg0.class))
    {
        var _ref = arg0.class;
        if (string_pos(".", _ref) == 0) _ref = arg1 + "." + _ref;
        var _cid = ds_map_find_value(global.gnx_class_name_to_id, _ref);
        if (_cid != undefined)
            arg0.class = _cid;
    }

    // h_type ref (e.g. cell_built / cell_occupied condition)
    if (variable_struct_exists(arg0, "h_type") && is_string(arg0.h_type))
    {
        var _ref = arg0.h_type;
        if (string_pos(".", _ref) == 0) _ref = arg1 + "." + _ref;
        var _hid = ds_map_find_value(global.gnx_cell_name_to_id, _ref);
        if (_hid != undefined)
            arg0.h_type = _hid;
    }
}

/// @desc Resolve string refs in a side_effect struct.
/// @arg {struct} arg0  side_effect struct
/// @arg {string} arg1  mod folder name
function scr_gnx_resolve_side_effect_refs(arg0, arg1)
{
    // unlock_cell h_type
    if (variable_struct_exists(arg0, "h_type") && is_string(arg0.h_type))
    {
        var _ref = arg0.h_type;
        if (string_pos(".", _ref) == 0) _ref = arg1 + "." + _ref;
        var _hid = ds_map_find_value(global.gnx_cell_name_to_id, _ref);
        if (_hid != undefined)
            arg0.h_type = _hid;
    }

    // unlock_class class ref
    if (variable_struct_exists(arg0, "class") && is_string(arg0.class))
    {
        var _ref = arg0.class;
        if (string_pos(".", _ref) == 0) _ref = arg1 + "." + _ref;
        var _cid = ds_map_find_value(global.gnx_class_name_to_id, _ref);
        if (_cid != undefined)
            arg0.class = _cid;
    }
}

/// @desc Check all GNX triggers for a given hook point. Fires matching events.
/// @arg {string} arg0  hook name ("post_raid_win", "post_raid", "frame")
function scr_gnx_check_triggers(arg0)
{
    var _n = array_length(global.gnx_quest_triggers);
    for (var _i = 0; _i < _n; _i++)
    {
        var _trig = global.gnx_quest_triggers[_i];
        if (_trig.hook != arg0) continue;

        // Check all conditions
        var _pass = true;
        if (variable_struct_exists(_trig, "conditions"))
        {
            var _conds = _trig.conditions;
            for (var _ci = 0; _ci < array_length(_conds); _ci++)
            {
                if (!scr_gnx_eval_condition(_conds[_ci], _trig.mod_name))
                {
                    _pass = false;
                    break;
                }
            }
        }

        if (_pass)
            scr_gnx_fire_event(_trig.event);
    }
}

/// @desc Evaluate a single condition struct against current game state.
/// @arg {struct} arg0  condition struct
/// @arg {string} arg1  mod folder name
/// @return {bool}
function scr_gnx_eval_condition(arg0, arg1)
{
    var _type = arg0.type;

    switch (_type)
    {
        case "state_equals":
            return scr_gnx_get_state(arg1, arg0.key) == arg0.value;

        case "state_gte":
            var _v = scr_gnx_get_state(arg1, arg0.key);
            return (_v != undefined && _v >= arg0.value);

        case "state_lte":
            var _v = scr_gnx_get_state(arg1, arg0.key);
            return (_v != undefined && _v <= arg0.value);

        case "stage_discovered":
            var _s = arg0.stage;
            return (global.val.stage_info[_s] != -1);

        case "stage_cleared":
            var _s = arg0.stage;
            var _ml = arg0.min_level;
            return (global.val.stage_info[_s] != -1 && global.val.stage_info[_s].max_lvl >= _ml);

        case "boss_captured":
            // Check if any unit in cage[] has matching class and state==1
            var _cls = arg0.class;
            var _cage = global.val.cage;
            for (var _ci = 0; _ci < array_length(_cage); _ci++)
            {
                if (_cage[_ci] != -1 && is_struct(_cage[_ci])
                    && variable_struct_exists(_cage[_ci], "class")
                    && _cage[_ci].class == _cls)
                    return true;
            }
            return false;

        case "cell_built":
            var _h = arg0.h_type;
            if (instance_exists(obj_slot))
            {
                with (obj_slot)
                {
                    if (slot_data.h_type == _h)
                        return true;
                }
            }
            return false;

        case "cell_occupied":
            var _h = arg0.h_type;
            if (instance_exists(obj_slot))
            {
                with (obj_slot)
                {
                    if (slot_data.h_type == _h && unit_data != -1)
                        return true;
                }
            }
            return false;

        case "unit_count":
            var _need = variable_struct_exists(arg0, "value") ? arg0.value : 1;
            if (variable_struct_exists(arg0, "class"))
            {
                // Count units of a specific class
                var _cls_ref = arg0.class;
                // Resolve string ref to class_id
                if (is_string(_cls_ref))
                {
                    var _resolved = ds_map_find_value(global.gnx_class_name_to_id, _cls_ref);
                    if (_resolved != undefined)
                        _cls_ref = _resolved;
                    else
                        return false;
                }
                var _count = 0;
                var _unum = ds_list_size(global.unit_list);
                for (var _ui = 0; _ui < _unum; _ui++)
                {
                    var _ud = ds_list_find_value(global.unit_list, _ui);
                    if (_ud != -1 && is_struct(_ud) && variable_struct_exists(_ud, "class") && _ud.class == _cls_ref)
                        _count++;
                }
                return (_count >= _need);
            }
            return (scr_all_mon_num_cal() >= _need);

        case "raid_won":
            return true;

        case "gold_gte":
            return (global.val.money >= arg0.value);

        case "floor_gte":
            return (global.val.floor >= arg0.value);

        case "cell_count":
            var _h = arg0.h_type;
            var _need = variable_struct_exists(arg0, "value") ? arg0.value : 1;
            var _count = 0;
            if (instance_exists(obj_slot))
            {
                with (obj_slot)
                {
                    if (slot_data.h_type == _h)
                        _count++;
                }
            }
            return (_count >= _need);
    }

    return false;
}

/// @desc Fire a GNX event by full id (e.g. "test_mod.test_intro").
/// @desc Create a popup toast with custom text (replicates vanilla scr_pop_up_create).
/// @arg {string} arg0  popup key (mod_name.popup_key) OR raw text string
function scr_gnx_pop_up_create(arg0)
{
    var _text = ds_map_find_value(global.gnx_popups, arg0);
    if (_text == undefined)
        _text = arg0; // fallback: treat arg as raw text

    var _x = 240;
    var _y = 27;
    var _exists = false;

    if (instance_exists(obj_pop_up))
    {
        _exists = true;
        with (obj_pop_up)
        {
            if (pop_up_data.timer > 60)
                pop_up_data.timer = max(60, floor(pop_up_data.timer * 0.5));
            pop_up_data.yto -= 10;
        }
    }

    with (instance_create_depth(_x, _y, -9998, obj_pop_up))
    {
        pop_up_data.timer = 180 + (7 * _exists);
        pop_up_data.scr_pop_up_step = scr_pop_up_step_timer;
        pop_up_data.scr_pop_up_draw = scr_pop_up_draw;
        pop_up_data.text_type = _text;
        pop_up_data.yto = _y;
    }
}

/// @desc Check all caged units for post-raid escape behaviors. Called after raid win.
///       Requires raid_data.ap and stage_info to be available (called within raid window scope).
function scr_gnx_check_post_raid_escape()
{
    var _cage = global.val.cage;
    var _cage_len = array_length(_cage);
    var _stg = raid_data.stage;
    var _lvl = global.val.stage_lvl_sel[_stg];

    // Compute over_diff (player power / enemy power)
    var _si = global.val.stage_info[_stg];
    if (_si == -1) exit;
    var _sdata = _si.info[_lvl];
    var _enemy_total = _sdata.en_ap[0] + _sdata.en_ap[1];
    if (_enemy_total <= 0) _enemy_total = 1; // prevent div/0
    var _over_diff = (raid_data.ap[0] + raid_data.ap[1]) / _enemy_total;

    for (var _ci = 0; _ci < _cage_len; _ci++)
    {
        var _unit = _cage[_ci];
        if (_unit == -1 || !is_struct(_unit)) continue;
        if (!variable_struct_exists(_unit, "class")) continue;

        var _cls = _unit.class;
        if (!ds_map_exists(global.class_registry, _cls)) continue;

        var _cr = ds_map_find_value(global.class_registry, _cls);
        if (!variable_struct_exists(_cr, "post_raid")) continue;

        var _pr = _cr.post_raid;
        if (!variable_struct_exists(_pr, "cage_escape")) continue;

        var _ce = _pr.cage_escape;
        var _mn = _pr.mod_name;

        // Check condition
        if (variable_struct_exists(_ce, "condition"))
        {
            if (!scr_gnx_eval_condition(_ce.condition, _mn))
                continue;
        }

        // Compute escape chance
        var _base = variable_struct_exists(_ce, "base_chance") ? _ce.base_chance : 0;
        var _scale = variable_struct_exists(_ce, "over_diff_scale") ? _ce.over_diff_scale : 300;
        // Frieren formula: irandom(1,100) <= (irandom(1,100) - scale + scale*(over_diff-1))
        // Simplifies: at over_diff=1, chance ~ 0%. At over_diff=2, chance ~ 50%.
        var _escape_roll = irandom_range(1, 100);
        var _threshold = _base + irandom_range(1, 100) - _scale + (_scale * (_over_diff - 1));
        var _escaped = (_escape_roll <= _threshold);

        if (_escaped)
        {
            // Remove from cage data
            global.val.cage[_ci] = -1;

            // Destroy the cage head button instance (interact_type 20, matching slot)
            with (obj_button)
            {
                if (interact_type == 20 && button_num == _ci)
                    instance_destroy();
            }

            // Show popup
            if (variable_struct_exists(_ce, "popup"))
                scr_gnx_pop_up_create(_ce.popup);

            // Increment escape counter in mod state
            if (variable_struct_exists(_ce, "counter_key"))
            {
                var _ck = _ce.counter_key;
                var _cv = scr_gnx_get_state(_mn, _ck);
                if (_cv == undefined) _cv = 0;
                scr_gnx_set_state(_mn, _ck, _cv + 1);

                // Fire hint event after N escapes
                if (variable_struct_exists(_ce, "on_escape_event") && variable_struct_exists(_ce, "escape_event_threshold"))
                {
                    if ((_cv + 1) >= _ce.escape_event_threshold)
                        scr_gnx_fire_event(_ce.on_escape_event);
                }
            }

            // Set state after escape (e.g. reset boss_state to hunt-active)
            if (variable_struct_exists(_ce, "on_escape_state"))
            {
                var _oes = _ce.on_escape_state;
                scr_gnx_set_state(_mn, _oes.key, _oes.value);
            }

            var _log = file_text_open_append(GNX_LOG);
            file_text_write_string(_log, "[GNX-ESCAPE] class=" + string(_cls) + " cage_slot=" + string(_ci) + " over_diff=" + string(_over_diff) + " roll=" + string(_escape_roll) + " threshold=" + string(_threshold) + "\n");
            file_text_close(_log);
        }
        else
        {
            // Escape failed: unit stays captured. Set survive state if configured.
            if (variable_struct_exists(_ce, "on_survive_state"))
            {
                var _oss = _ce.on_survive_state;
                scr_gnx_set_state(_mn, _oss.key, _oss.value);
            }
            if (variable_struct_exists(_ce, "on_survive_event"))
                scr_gnx_fire_event(_ce.on_survive_event);

            var _log = file_text_open_append(GNX_LOG);
            file_text_write_string(_log, "[GNX-SURVIVE] class=" + string(_cls) + " cage_slot=" + string(_ci) + " over_diff=" + string(_over_diff) + " roll=" + string(_escape_roll) + " threshold=" + string(_threshold) + "\n");
            file_text_close(_log);
        }
    }
}

///       Notifications go to noti_list; quests go to quest_list.
/// @arg {string} arg0  full event id
function scr_gnx_fire_event(arg0)
{
    var _evt = ds_map_find_value(global.gnx_quest_events, arg0);
    if (_evt == undefined) return;

    var _log = file_text_open_append(GNX_LOG);
    file_text_write_string(_log, "[GNX-QUEST] fire event: " + arg0 + " type=" + _evt.type + "\n");
    file_text_close(_log);

    if (_evt.type == "notification")
    {
        // Check not already in noti_list
        var _nnum = ds_list_size(global.noti_list);
        for (var _i = 0; _i < _nnum; _i++)
        {
            var _existing = ds_list_find_value(global.noti_list, _i);
            if (variable_struct_exists(_existing, "gnx_event_id") && _existing.gnx_event_id == arg0)
                return; // already queued
        }

        var _data = {};
        _data.noti_type = arg0; // string, won't collide with vanilla enum ints
        _data.text_type = scr_gnx_dialog_render;
        _data.event_after = -1; // we handle chaining via gnx_next
        _data.gnx_event_id = arg0;
        _data.gnx_event = _evt;
        _data.gnx_next = variable_struct_exists(_evt, "next_event") ? _evt.next_event : undefined;
        _data.gnx_mod_name = _evt.mod_name;

        // Apply side effects immediately when notification fires
        if (variable_struct_exists(_evt, "side_effects"))
            scr_gnx_apply_side_effects(_evt.side_effects, _evt.mod_name);

        ds_list_add(global.noti_list, _data);

        // Create notification bell button if not already present
        var _btn_exists = false;
        if (instance_exists(obj_button))
        {
            with (obj_button)
            {
                if (interact_type == UnknownEnum.Value_33)
                    _btn_exists = true;
            }
        }
        if (!_btn_exists)
        {
            with (obj_np)
                scr_create_button(416, 242, -2000, spr_notification, UnknownEnum.Value_33, -1, scr_create_notification_button, -1, scr_draw_hover_button, 0, 0);
        }
    }
    else if (_evt.type == "quest")
    {
        // Check not already in quest_list
        var _qnum = ds_list_size(global.quest_list);
        for (var _i = 0; _i < _qnum; _i++)
        {
            var _existing = ds_list_find_value(global.quest_list, _i);
            if (variable_struct_exists(_existing, "gnx_event_id") && _existing.gnx_event_id == arg0)
                return;
        }

        var _data = {};
        _data.quest_clear = false;
        _data.quest_type = arg0; // string, vanilla switch default will skip it
        _data.quest_text = _evt.quest_text;
        _data.quest_reward = scr_gnx_make_reward(_evt.reward);
        _data.gnx_event_id = arg0;
        _data.gnx_event = _evt;
        _data.gnx_next = variable_struct_exists(_evt, "next_event") ? _evt.next_event : undefined;
        _data.gnx_mod_name = _evt.mod_name;
        _data.event_after = -1;

        ds_list_add(global.quest_list, _data);
        scr_pop_up_create(UnknownEnum.Value_12);

        with (obj_np.quest_button)
        {
            global.val.quest_new = true;
            with (child_window)
            {
                var _y = 0;
                with (quest_slider)
                {
                    _y = y - y_start;
                    instance_destroy();
                }
                quest_slider = scr_create_quest_slider(_y);
            }
        }
    }
}

/// @desc Apply an array of side effects.
/// @arg {array} arg0  side_effects array
/// @arg {string} arg1  mod_name
function scr_gnx_apply_side_effects(arg0, arg1)
{
    for (var _i = 0; _i < array_length(arg0); _i++)
    {
        var _se = arg0[_i];
        var _type = _se.type;

        switch (_type)
        {
            case "set_state":
                scr_gnx_set_state(arg1, _se.key, _se.value);
                break;

            case "add_gold":
                global.val.money += _se.amount;
                break;

            case "add_food":
                global.val.food += _se.amount;
                break;

            case "unlock_cell":
                scr_add_new_slot_h_type(_se.h_type, false);
                break;

            case "unlock_class":
                // Add class to raid encounter pool so units can be captured
                // _se.class is pre-resolved to integer at load time
                var _cls = _se.class;
                if (ds_map_exists(global.class_registry, _cls))
                {
                    var _cr = ds_map_find_value(global.class_registry, _cls);
                    if (variable_struct_exists(_cr, "raid_spawns"))
                    {
                        var _rs = _cr.raid_spawns;
                        for (var _ri = 0; _ri < array_length(_rs); _ri++)
                        {
                            var _sp = _rs[_ri];
                            var _stage = _sp.stage;
                            var _pool = ds_map_find_value(global.gnx_encounter_pools, _stage);
                            if (_pool != undefined)
                                ds_list_add(_pool, { class_id: _cls, level_range: _sp.level_range, weight: variable_struct_exists(_sp, "weight") ? _sp.weight : 1 });
                        }
                    }
                }
                break;

            case "add_shop_item":
                // Future: add to trade pool
                break;
        }
    }
}

/// @desc Convert a reward definition from JSON to the game's item data format.
/// @arg {struct} arg0  reward struct from quests.json
/// @return item data struct (or -1 if no reward)
function scr_gnx_make_reward(arg0)
{
    if (arg0 == undefined || arg0 == -1)
        return scr_set_item_data(UnknownEnum.Value_0, 0, -1);

    var _type = arg0.type;

    if (_type == "gold")
        return scr_set_item_data(UnknownEnum.Value_0, arg0.amount, -1);
    else if (_type == "food")
        return scr_set_item_data(UnknownEnum.Value_1, arg0.amount, -1);
    else if (_type == "blueprint")
    {
        // lvl 3 or 7 = complete blueprint (instant unlock, all 3 pips lit)
        // other lvl = fragment (need 3 to combine). Default: complete.
        var _lvl = UnknownEnum.Value_3;
        if (variable_struct_exists(arg0, "fragment") && arg0.fragment == true)
            _lvl = variable_struct_exists(arg0, "lvl") ? arg0.lvl : 1;
        return scr_set_item_data(UnknownEnum.Value_5, arg0.h_type, _lvl);
    }
    else if (_type == "prop")
        return scr_set_item_data(UnknownEnum.Value_7, arg0.prop_id, 0);

    return scr_set_item_data(UnknownEnum.Value_0, 0, -1);
}

/// @desc Check GNX quest completion for quests using the given hook.
/// @arg {string} arg0  completion_hook ("frame" or "post_raid")
function scr_gnx_check_quest_completion(arg0)
{
    if (!ds_exists(global.quest_list, ds_type_list)) return;
    var _qnum = ds_list_size(global.quest_list);

    for (var _i = 0; _i < _qnum; _i++)
    {
        var _q = ds_list_find_value(global.quest_list, _i);
        if (!variable_struct_exists(_q, "gnx_event")) continue;
        if (_q.quest_clear) continue;

        var _evt = _q.gnx_event;
        var _hook = variable_struct_exists(_evt, "completion_hook") ? _evt.completion_hook : "frame";
        if (_hook != arg0) continue;

        var _comp = _evt.completion;
        if (scr_gnx_eval_condition(_comp, _q.gnx_mod_name))
        {
            _q.quest_clear = true;
            global.val.quest_clear = true;

            var _log = file_text_open_append(GNX_LOG);
            file_text_write_string(_log, "[GNX-QUEST] quest complete: " + _q.gnx_event_id + "\n");
            file_text_close(_log);

            // Fire gnx_next at completion detection (matches vanilla event_after behavior)
            if (variable_struct_exists(_q, "gnx_next") && _q.gnx_next != undefined)
                scr_gnx_fire_event(_q.gnx_next);
        }
    }
}

/// @desc Called when a GNX quest reward is claimed. Grants reward and fires next event.
/// @arg {struct} arg0  quest data struct from quest_list
function scr_gnx_claim_quest_reward(arg0)
{
    // Reward is already in quest_reward format, granted by vanilla scr_gain_reward
    // Fire next event in chain
    if (variable_struct_exists(arg0, "gnx_next") && arg0.gnx_next != undefined)
        scr_gnx_fire_event(arg0.gnx_next);
}

/// @desc Generic dialog renderer for GNX notification events.
///       Called via script_execute(text_data.text_type) from scr_create_textbox.
///       Populates text_name[], text_spr[], text_ar[] from text_data.gnx_event.dialog[].
/// @desc Save minimal GNX quest/noti state into global.val for serialization.
function scr_gnx_save_quest_state()
{
    var _qs = {};
    _qs.quests = [];
    _qs.notis = [];

    for (var _i = 0; _i < ds_list_size(global.quest_list); _i++)
    {
        var _q = ds_list_find_value(global.quest_list, _i);
        if (variable_struct_exists(_q, "gnx_event_id"))
            array_push(_qs.quests, { event_id: _q.gnx_event_id, quest_clear: _q.quest_clear });
    }

    for (var _i = 0; _i < ds_list_size(global.noti_list); _i++)
    {
        var _n = ds_list_find_value(global.noti_list, _i);
        if (variable_struct_exists(_n, "gnx_event_id"))
            array_push(_qs.notis, { event_id: _n.gnx_event_id });
    }

    global.val.gnx_quest_state = _qs;
}

/// @desc Restore GNX quests/notis from saved state. No side effects applied.
function scr_gnx_restore_quest_state()
{
    if (!variable_struct_exists(global.val, "gnx_quest_state")) return;
    var _qs = global.val.gnx_quest_state;

    // Restore quests
    if (variable_struct_exists(_qs, "quests"))
    {
        for (var _i = 0; _i < array_length(_qs.quests); _i++)
        {
            var _saved = _qs.quests[_i];
            var _evt = ds_map_find_value(global.gnx_quest_events, _saved.event_id);
            if (_evt == undefined) continue; // mod no longer loaded

            var _data = {};
            _data.quest_clear = _saved.quest_clear;
            _data.quest_type = _saved.event_id;
            _data.quest_text = _evt.quest_text;
            _data.quest_reward = scr_gnx_make_reward(_evt.reward);
            _data.gnx_event_id = _saved.event_id;
            _data.gnx_event = _evt;
            _data.gnx_next = variable_struct_exists(_evt, "next_event") ? _evt.next_event : undefined;
            _data.gnx_mod_name = _evt.mod_name;
            _data.event_after = -1;
            ds_list_add(global.quest_list, _data);
        }
    }

    // Restore notifications
    if (variable_struct_exists(_qs, "notis"))
    {
        for (var _i = 0; _i < array_length(_qs.notis); _i++)
        {
            var _saved = _qs.notis[_i];
            var _evt = ds_map_find_value(global.gnx_quest_events, _saved.event_id);
            if (_evt == undefined) continue;

            var _data = {};
            _data.noti_type = _saved.event_id;
            _data.text_type = scr_gnx_dialog_render;
            _data.event_after = -1;
            _data.gnx_event_id = _saved.event_id;
            _data.gnx_event = _evt;
            _data.gnx_next = variable_struct_exists(_evt, "next_event") ? _evt.next_event : undefined;
            _data.gnx_mod_name = _evt.mod_name;
            ds_list_add(global.noti_list, _data);
        }
    }

    // Ensure notification bell button exists if we restored notis
    if (variable_struct_exists(_qs, "notis") && array_length(_qs.notis) > 0 && ds_list_size(global.noti_list) > 0)
    {
        var _btn_exists = false;
        if (instance_exists(obj_button))
        {
            with (obj_button)
            {
                if (interact_type == UnknownEnum.Value_33)
                    _btn_exists = true;
            }
        }
        if (!_btn_exists)
        {
            with (obj_np)
                scr_create_button(416, 242, -2000, spr_notification, UnknownEnum.Value_33, -1, scr_create_notification_button, -1, scr_draw_hover_button, 0, 0);
        }
    }

    // Rebuild quest slider if we added quests
    if (variable_struct_exists(_qs, "quests") && array_length(_qs.quests) > 0)
    {
        with (obj_np.quest_button.child_window)
        {
            var _y = 0;
            with (quest_slider)
            {
                _y = y - y_start;
                instance_destroy();
            }
            quest_slider = scr_create_quest_slider(_y);
        }
    }
}

function scr_gnx_dialog_render()
{
    var _dialog = text_data.gnx_event.dialog;

    for (var _i = 0; _i < array_length(_dialog); _i++)
    {
        var _line = _dialog[_i];
        var _portrait = _line.portrait_spr;

        // -1 means vanilla Lilith portrait (Value_4 = Lilith sprite)
        if (_portrait == -1)
            _portrait = UnknownEnum.Value_4;

        scr_text(_line.speaker, _portrait, _line.text);
    }
}

function scr_gnx_register_goblin_sprites()
{
    var _gob = {};
    _gob.s_body_b_leg0 = spr_h_goblin_body_start_v1_alpha;
    _gob.s_body_b_leg1 = spr_h_goblin_body_start_v1_alpha;
    _gob.s_body_b_leg2 = spr_h_goblin_body_start_v2_alpha;
    _gob.s_body_b_cow = spr_h_goblin_body_start_cow_alpha;
    _gob.s_hand_b = spr_h_goblin_hand_start_alpha;
    _gob.s_pen = spr_h_goblin_pen_start;
    _gob.s_touch_def = spr_h_goblin_touch_start;
    _gob.s_touch_cow = spr_h_goblin_touch_start_cow;
    _gob.s_touch_nyx = spr_h_goblin_touch_start_nyx;
    _gob.s_touch_cat = spr_h_goblin_touch_start_cat;
    _gob.s_touch_morrigan = spr_h_goblin_touch_start_morrigan;
    _gob.s_touch_lilith = spr_h_goblin_touch_start_lilith;
    _gob.s_hand_xscale_random = true;
    _gob.lo_head_b_0 = spr_h_goblin_head_loop_d1_alpha;
    _gob.lo_head_b_1 = spr_h_goblin_head_loop_d2_alpha;
    _gob.lo_body_b_leg0 = spr_h_goblin_body_loop_v1_alpha;
    _gob.lo_body_b_leg1 = spr_h_goblin_body_loop_v1_alpha;
    _gob.lo_body_b_leg2 = spr_h_goblin_body_loop_v2_alpha;
    _gob.lo_body_b_cow = spr_h_goblin_body_loop_cow_alpha;
    _gob.lo_hand_b_leg0 = spr_h_goblin_hand_loop_v1_alpha;
    _gob.lo_hand_b_leg1 = spr_h_goblin_hand_loop_v1_alpha;
    _gob.lo_hand_b_leg2 = spr_h_goblin_hand_loop_v2_alpha;
    _gob.lo_hand_b_cow = spr_h_goblin_hand_loop_cow_alpha;
    _gob.lo_pen = spr_h_goblin_pen_loop;
    _gob.lo_touch_def = spr_h_goblin_touch_loop_v1;
    _gob.lo_touch_leg2 = spr_h_goblin_touch_loop_v2;
    _gob.lo_touch_cow = spr_h_goblin_touch_loop_cow;
    _gob.lo_touch_nyx = spr_h_goblin_touch_loop_nyx;
    _gob.lo_touch_morrigan = spr_h_goblin_touch_loop_morrigan;
    _gob.lo_touch_cat = spr_h_goblin_touch_loop_cat;
    _gob.lo_touch_lilith = spr_h_goblin_touch_loop_lilith;
    _gob.lo_enter_def = spr_h_goblin_enter_loop;
    _gob.lo_enter_cow = spr_h_goblin_enter_loop_cow;
    _gob.lo_enter_nyx = spr_h_goblin_enter_loop_nyx;
    _gob.lo_enter_morrigan = spr_h_goblin_enter_loop_morrigan;
    _gob.lo_enter_cat = spr_h_goblin_enter_loop_cat;
    _gob.lo_enter_lilith = spr_h_goblin_enter_loop_lilith;
    var _hob_def = {};
    _hob_def.s_body_b_leg1 = spr_h_hobgoblin_body_start_v1_alpha;
    _hob_def.s_body_b_leg2 = spr_h_hobgoblin_body_start_v2_alpha;
    _hob_def.s_body_b_leg0 = spr_h_hobgoblin_body_start_v3_alpha;
    _hob_def.s_body_b_cat = spr_h_hobgoblin_body_start_v3_alpha;
    _hob_def.lo_body_b_leg0 = spr_h_hobgoblin_body_loop_v3_alpha;
    _hob_def.s_hand_b = spr_h_hobgoblin_hand_start_d1_alpha;
    _hob_def.s_hand_b_cow = spr_h_hobgoblin_hand_start_cow_alpha;
    _hob_def.s_body_b_cow = spr_h_hobgoblin_body_start_cow_alpha;
    _hob_def.s_pen = spr_h_hobgoblin_pen_start;
    _hob_def.s_hand_xscale_random = true;
    _hob_def.lo_head_b_0 = spr_h_hobgoblin_head_loop_alpha;
    _hob_def.lo_head_b_1 = spr_h_hobgoblin_head_loop_alpha;
    _hob_def.lo_body_b_leg1 = spr_h_hobgoblin_body_loop_v1_alpha;
    _hob_def.lo_body_b_leg2 = spr_h_hobgoblin_body_loop_v2_alpha;
    _hob_def.lo_body_b_any = spr_h_hobgoblin_body_loop_v3_alpha;
    _hob_def.lo_body_b_cow = spr_h_hobgoblin_body_loop_cow_alpha;
    _hob_def.lo_body_b_cat = spr_h_hobgoblin_body_loop_v3_alpha;
    _hob_def.lo_hand_b_leg1 = spr_h_hobgoblin_hand_loop_v1_alpha;
    _hob_def.lo_hand_b_leg2 = spr_h_hobgoblin_hand_loop_v2_alpha;
    _hob_def.lo_hand_b_any = spr_h_hobgoblin_hand_loop_v1_alpha;
    _hob_def.lo_hand_b_cow = spr_h_hobgoblin_hand_loop_v1_d1_alpha;
    _hob_def.lo_hand_b_lilith = spr_h_hobgoblin_hand_loop_v1_d1_alpha;
    _hob_def.lo_pen = spr_h_hobgoblin_pen_loop;
    _hob_def.lo_touch_def = spr_h_hobgoblin_touch_loop;
    _hob_def.lo_touch_cow = spr_h_hobgoblin_touch_loop_cow;
    _hob_def.lo_touch_nyx = spr_h_hobgoblin_touch_loop_nyx;
    _hob_def.lo_touch_cat = spr_h_hobgoblin_touch_loop_cat;
    _hob_def.lo_touch_morrigan = spr_h_hobgoblin_touch_loop_morrigan;
    _hob_def.lo_touch_lilith = spr_h_hobgoblin_enter_loop_lilith;
    _hob_def.lo_enter_def = spr_h_hobgoblin_enter_loop;
    _hob_def.lo_enter_cow = spr_h_hobgoblin_enter_loop_cow;
    _hob_def.lo_enter_nyx = spr_h_hobgoblin_enter_loop_nyx;
    _hob_def.lo_enter_cat = spr_h_hobgoblin_enter_loop_cat;
    _hob_def.lo_enter_morrigan = spr_h_hobgoblin_enter_loop_morrigan;
    _hob_def.lo_enter_lilith = spr_h_hobgoblin_enter_loop_lilith;
    var _hob_wall = {};
    _hob_wall.ej_body_b_any = spr_h_hobgoblin_body_ej_alpha;
    _hob_wall.ej_hand_b_leg1 = spr_h_hobgoblin_hand_loop_v1_alpha;
    _hob_wall.ej_hand_b_leg2 = spr_h_hobgoblin_hand_loop_v2_alpha;
    _hob_wall.ej_hand_b_any = spr_h_hobgoblin_hand_loop_v1_alpha;
    _hob_wall.ej_hand_b_cow = spr_h_hobgoblin_hand_loop_v1_d1_alpha;
    _hob_wall.ej_hand_b_lilith = spr_h_hobgoblin_hand_loop_v1_d1_alpha;
    _hob_wall.ej_pen = spr_h_hobgoblin_pen_loop;
    _hob_wall.ej_touch_def = spr_h_hobgoblin_touch_loop;
    _hob_wall.ej_touch_cow = spr_h_hobgoblin_touch_loop_cow;
    _hob_wall.ej_touch_nyx = spr_h_hobgoblin_touch_loop_nyx;
    _hob_wall.ej_touch_cat = spr_h_hobgoblin_touch_loop_cat;
    _hob_wall.ej_touch_morrigan = spr_h_hobgoblin_touch_loop_morrigan;
    _hob_wall.ej_touch_lilith = spr_h_hobgoblin_enter_loop_lilith;
    _hob_wall.ej_enter_def = spr_h_hobgoblin_enter_loop;
    _hob_wall.ej_enter_cow = spr_h_hobgoblin_enter_loop_cow;
    _hob_wall.ej_enter_nyx = spr_h_hobgoblin_enter_loop_nyx;
    _hob_wall.ej_enter_cat = spr_h_hobgoblin_enter_loop_cat;
    _hob_wall.ej_enter_morrigan = spr_h_hobgoblin_enter_loop_morrigan;
    _hob_wall.ej_enter_lilith = spr_h_hobgoblin_enter_loop_lilith;
    var _hob_keys = variable_struct_get_names(_hob_def);
    var _ki = 0;
    
    repeat (array_length(_hob_keys))
    {
        variable_struct_set(_hob_wall, _hob_keys[_ki], variable_struct_get(_hob_def, _hob_keys[_ki]));
        _ki++;
    }
    
    var _hob_fp = {};
    var _hw_keys = variable_struct_get_names(_hob_wall);
    _ki = 0;
    
    repeat (array_length(_hw_keys))
    {
        variable_struct_set(_hob_fp, _hw_keys[_ki], variable_struct_get(_hob_wall, _hw_keys[_ki]));
        _ki++;
    }
    
    _hob_fp.lo_hand_xscale_random = true;
    _hob_fp.ej_hand_b_any = spr_h_hobgoblin_hand_ej_alpha;
    var _ogr = {};
    _ogr.s_body_b_leg1 = spr_h_ogre_body_start;
    _ogr.s_body_b_leg2 = spr_h_ogre_body_start;
    _ogr.s_body_b_any = spr_h_ogre_body_start_v3;
    _ogr.s_body_b_cow = spr_h_ogre_body_start_cow;
    _ogr.lo_body_b_leg1 = spr_h_ogre_body_loop;
    _ogr.lo_body_b_leg2 = spr_h_ogre_body_loop;
    _ogr.lo_body_b_any = spr_h_ogre_body_loop_v3;
    _ogr.lo_body_b_cow = spr_h_ogre_body_loop_cow;
    _ogr.lo_body_b_lilith = spr_h_ogre_body_loop_lilith;
    var _gob_gb1 = {};
    _gob_gb1.lo_body_b_leg0 = spr_h_goblin_gb_1_v3_loop_alpha;
    _gob_gb1.lo_body_b_leg1 = spr_h_goblin_gb_1_loop_alpha;
    _gob_gb1.lo_body_b_leg2 = spr_h_goblin_gb_1_loop_alpha;
    _gob_gb1.lo_body_b_cow = spr_h_goblin_gb_1_cow_loop_alpha;
    _gob_gb1.lo_body_b_lilith = spr_h_goblin_gb_1_lilith_loop_alpha;
    _gob_gb1.s_body_b_leg0 = spr_h_goblin_gb_1_v3_loop_alpha;
    _gob_gb1.s_body_b_leg1 = spr_h_goblin_gb_1_loop_alpha;
    _gob_gb1.s_body_b_leg2 = spr_h_goblin_gb_1_loop_alpha;
    _gob_gb1.s_body_b_cow = spr_h_goblin_gb_1_cow_loop_alpha;
    _gob_gb1.s_body_b_lilith = spr_h_goblin_gb_1_lilith_loop_alpha;
    var _hob_gb1 = {};
    _hob_gb1.lo_body_b_leg0 = spr_h_hobgoblin_gb_1_v3_loop_alpha;
    _hob_gb1.lo_body_b_leg1 = spr_h_hobgoblin_gb_1_loop_alpha;
    _hob_gb1.lo_body_b_leg2 = spr_h_hobgoblin_gb_1_loop_alpha;
    _hob_gb1.lo_body_b_lilith = spr_h_hobgoblin_gb_1_lilith_loop_alpha;
    _hob_gb1.s_body_b_leg0 = spr_h_hobgoblin_gb_1_v3_loop_alpha;
    _hob_gb1.s_body_b_leg1 = spr_h_hobgoblin_gb_1_loop_alpha;
    _hob_gb1.s_body_b_leg2 = spr_h_hobgoblin_gb_1_loop_alpha;
    _hob_gb1.s_body_b_lilith = spr_h_hobgoblin_gb_1_lilith_loop_alpha;
    var _gob_gb2 = {};
    _gob_gb2.lo_body_b_leg0 = spr_h_goblin_gb_2_v3_loop_alpha;
    _gob_gb2.lo_body_b_leg1 = spr_h_goblin_gb_2_loop_alpha;
    _gob_gb2.lo_body_b_leg2 = spr_h_goblin_gb_2_loop_alpha;
    _gob_gb2.lo_body_b_cow = spr_h_goblin_gb_2_cow_loop_alpha;
    _gob_gb2.lo_enter_def = spr_h_goblin_gb_2_loop_enter;
    _gob_gb2.lo_enter_cow = spr_h_goblin_gb_2_loop_enter_cow;
    _gob_gb2.lo_enter_nyx = spr_h_goblin_gb_2_loop_enter_nyx;
    _gob_gb2.lo_enter_lilith = spr_h_goblin_gb_2_loop_enter_lilith;
    _gob_gb2.lo_enter_morrigan = spr_h_goblin_gb_2_loop_enter_morrigan;
    _gob_gb2.lo_enter_cat = spr_h_goblin_gb_2_loop_enter_cat;
    _gob_gb2.s_body_b_leg0 = spr_h_goblin_gb_2_v3_loop_alpha;
    _gob_gb2.s_body_b_leg1 = spr_h_goblin_gb_2_loop_alpha;
    _gob_gb2.s_body_b_leg2 = spr_h_goblin_gb_2_loop_alpha;
    _gob_gb2.s_body_b_cow = spr_h_goblin_gb_2_cow_loop_alpha;
    var _gob_gb3 = {};
    _gob_gb3.lo_body_b_any = spr_h_goblin_gb_3_loop_body_alpha;
    _gob_gb3.lo_hand_b_any = spr_h_goblin_gb_3_loop_hand_alpha;
    _gob_gb3.lo_hand_b_cow = spr_h_goblin_gb_3_cow_loop_hand_alpha;
    _gob_gb3.lo_hand_b_lilith = spr_h_goblin_gb_3_lilith_loop_hand_alpha;
    _gob_gb3.lo_enter_def = spr_h_goblin_gb_3_loop_enter;
    _gob_gb3.lo_enter_cow = spr_h_goblin_gb_3_cow_loop_enter;
    _gob_gb3.lo_enter_nyx = spr_h_goblin_gb_3_nyx_loop_enter;
    _gob_gb3.lo_enter_cat = spr_h_goblin_gb_3_cat_loop_enter;
    _gob_gb3.lo_enter_morrigan = spr_h_goblin_gb_3_morrigan_loop_enter;
    _gob_gb3.lo_enter_lilith = spr_h_goblin_gb_3_lilith_loop_enter;
    _gob_gb3.s_body_b_any = spr_h_goblin_gb_3_loop_body_alpha;
    _gob_gb3.s_hand_b_any = spr_h_goblin_gb_3_loop_hand_alpha;
    var _hob_gb3 = {};
    _hob_gb3.lo_body_b_any = spr_h_hobgoblin_gb_3_loop_body_alpha;
    _hob_gb3.lo_hand_b_any = spr_h_hobgoblin_gb_3_loop_hand_alpha;
    _hob_gb3.lo_hand_b_cow = spr_h_hobgoblin_gb_3_cow_loop_hand_alpha;
    _hob_gb3.lo_hand_b_lilith = spr_h_hobgoblin_gb_3_lilith_loop_hand_alpha;
    _hob_gb3.lo_enter_def = spr_h_hobgoblin_gb_3_loop_enter;
    _hob_gb3.lo_enter_cow = spr_h_hobgoblin_gb_3_cow_loop_enter;
    _hob_gb3.lo_enter_cat = spr_h_hobgoblin_gb_3_cat_loop_enter;
    _hob_gb3.lo_enter_nyx = spr_h_hobgoblin_gb_3_nyx_loop_enter;
    _hob_gb3.lo_enter_morrigan = spr_h_hobgoblin_gb_3_morrigan_loop_enter;
    _hob_gb3.s_body_b_any = spr_h_hobgoblin_gb_3_loop_body_alpha;
    _hob_gb3.s_hand_b_any = spr_h_hobgoblin_gb_3_loop_hand_alpha;
    // Fixed-sprite cells: body_b_any only, no head/hand/linework.
    // GNX pre-switch sets body_b correctly; vanilla switch re-sets same sprite + touch (harmless).
    var _dairy_gob = {};
    _dairy_gob.s_body_b_any = spr_h_goblin_dairy_loop_alpha;
    _dairy_gob.lo_body_b_any = spr_h_goblin_dairy_loop_alpha;
    _dairy_gob.ej_body_b_any = spr_h_goblin_dairy_loop_alpha;
    // GIANT cell: body-only dispatch (no hands/head). Vanilla switch overwrites body+pen+touch (harmless).
    var _giant_gob = {};
    _giant_gob.s_body_b_any = spr_h_goblin_body_start_alpha_giant;
    _giant_gob.lo_body_b_any = spr_h_goblin_body_alpha_giant;
    _giant_gob.ej_body_b_any = spr_h_goblin_body_alpha_giant;
    var _giant_hob = {};
    _giant_hob.s_body_b_any = spr_h_hobgoblin_body_start_alpha_giant;
    _giant_hob.lo_body_b_any = spr_h_hobgoblin_body_alpha_giant;
    _giant_hob.ej_body_b_any = spr_h_hobgoblin_body_alpha_giant;
    var _giant_ogr = {};
    _giant_ogr.s_body_b_any = spr_h_ogre_giant_start_alpha;
    _giant_ogr.lo_body_b_any = spr_h_ogre_giant_loop_alpha;
    _giant_ogr.ej_body_b_any = spr_h_ogre_giant_loop_alpha;
    var _all_cells = [[1, _gob, _hob_wall, _ogr], [2, _gob, _hob_wall, _ogr], [7, _gob, _hob_wall, _ogr], [8, _gob, _hob_wall, _ogr], [9, _gob, _hob_def, _ogr], [13, _gob, _hob_def, _ogr], [14, _gob, _hob_def, _ogr], [3, _gob, _hob_def, _ogr], [6, _gob, _hob_def, _ogr], [15, _gob, _hob_fp, _ogr], [4, _gob, _hob_def, _ogr], [5, _gob, _hob_def, _ogr], [10, _gob, _hob_def, _ogr], [11, _gob, _hob_def, _ogr], [12, _gob, _hob_def, _ogr], [18, _gob_gb1, _hob_gb1, _ogr], [19, _gob_gb2, _hob_def, _ogr], [20, _gob, _hob_def, _ogr], [21, _gob, _hob_def, _ogr], [22, _gob, _hob_def, _ogr], [23, _gob_gb3, _hob_gb3, _ogr], [36, _dairy_gob, -1, -1], [37, _giant_gob, _giant_hob, _giant_ogr], [38, _gob, _hob_def, _ogr], [39, _gob, _hob_def, _ogr], [40, _gob, _hob_def, _ogr], [41, _gob, _hob_def, _ogr], [42, _gob, _hob_def, _ogr], [17, _gob, _hob_def, _ogr], [24, _gob, _hob_def, _ogr], [25, _gob, _hob_def, _ogr], [27, _gob, _hob_def, _ogr], [28, _gob, _hob_def, _ogr], [29, _gob, _hob_def, _ogr], [30, _gob, _hob_def, _ogr], [31, _gob, _hob_def, _ogr], [32, _gob, _hob_def, _ogr], [33, _gob, _hob_def, _ogr], [34, _gob, _hob_def, _ogr]];
    var _i = 0;
    
    repeat (array_length(_all_cells))
    {
        var _entry = _all_cells[_i];
        var _ht = _entry[0];
        
        if (ds_map_exists(global.cell_registry, _ht))
        {
            var _cell = ds_map_find_value(global.cell_registry, _ht);
            
            if (!variable_struct_exists(_cell, "mon_spr") || _cell.mon_spr == undefined)
                _cell.mon_spr = _entry[1];
            
            if (!variable_struct_exists(_cell, "mon_spr_hob") || _cell.mon_spr_hob == undefined)
                _cell.mon_spr_hob = _entry[2];
            
            if (!variable_struct_exists(_cell, "mon_spr_ogr") || _cell.mon_spr_ogr == undefined)
                _cell.mon_spr_ogr = _entry[3];
        }
        
        _i++;
    }
    
    if (ds_map_exists(global.cell_registry, 18))
        ds_map_find_value(global.cell_registry, 18).placement1_body_skip = true;
}

/// @arg {int} arg0 stage
/// @arg {int} arg1 level
/// @arg {int} arg2 class_id
/// @arg {int} arg3 weight
/// @arg {int} arg4 min_lvl
/// @arg {int} arg5 max_lvl
/// @arg {struct|undefined} arg6 condition (optional)
/// @arg {string} arg7 mod_name (optional, required if condition set)
function gnx_pool_add()
{
    var _stage = argument[0];
    var _level = argument[1];
    var _cls   = argument[2];
    var _w     = argument[3];
    var _min   = argument[4];
    var _max   = argument[5];

    var _key = (_stage * 100) + _level;
    var _pool;

    if (ds_map_exists(global.gnx_encounter_pools, _key))
    {
        _pool = ds_map_find_value(global.gnx_encounter_pools, _key);
    }
    else
    {
        _pool = ds_list_create();
        ds_map_add(global.gnx_encounter_pools, _key, _pool);
    }

    var _entry = {
        class_id: _cls,
        weight: _w,
        min_lvl: _min,
        max_lvl: _max
    };
    if (argument_count > 6 && argument[6] != undefined)
        _entry.condition = argument[6];
    if (argument_count > 7 && argument[7] != undefined)
        _entry.mod_name = argument[7];
    if (argument_count > 8 && argument[8] != undefined)
        _entry.max_per_encounter = argument[8];
    if (argument_count > 9 && argument[9] != undefined)
        _entry.ap_override = argument[9];
    ds_list_add(_pool, _entry);
}

function gnx_pool_pick()
{
    // arg0=stage, arg1=level, arg2=optional exclusion array (from max_per_encounter)
    var _stage = argument[0];
    var _level = argument[1];
    var _exclude = (argument_count > 2 && is_array(argument[2])) ? argument[2] : -1;
    var _key = (_stage * 100) + _level;

    if (!ds_map_exists(global.gnx_encounter_pools, _key))
    {
        var _log = file_text_open_append(GNX_LOG);
        file_text_write_string(_log, "[GNX] pool_pick: no pool stage=" + string(_stage) + " lvl=" + string(_level) + "\n");
        file_text_close(_log);
        return { class_id: 0, lvl: 0 };
    }

    var _pool = ds_map_find_value(global.gnx_encounter_pools, _key);
    var _count = ds_list_size(_pool);

    // First pass: sum weights of eligible entries (condition + exclusion check)
    var _total = 0;
    var _i = 0;
    repeat (_count)
    {
        var _e = ds_list_find_value(_pool, _i);
        var _eligible = true;
        if (variable_struct_exists(_e, "condition") && variable_struct_exists(_e, "mod_name"))
            _eligible = scr_gnx_eval_condition(_e.condition, _e.mod_name);
        // max_per_encounter exclusion: skip if class_id is in exclude list
        if (_eligible && _exclude != -1 && variable_struct_exists(_e, "max_per_encounter"))
        {
            var _exc_count = 0;
            for (var _ei = 0; _ei < array_length(_exclude); _ei++)
            {
                if (_exclude[_ei] == _e.class_id)
                    _exc_count++;
            }
            if (_exc_count >= _e.max_per_encounter)
                _eligible = false;
        }
        if (_eligible)
            _total += _e.weight;
        _i++;
    }

    // All entries filtered out: fall back to vanilla peasant
    if (_total <= 0)
        return { class_id: 0, lvl: 0 };

    // Second pass: weighted pick among eligible entries
    var _roll = irandom_range(1, _total);
    var _cum = 0;
    var _entry = ds_list_find_value(_pool, 0);
    _i = 0;
    repeat (_count)
    {
        _entry = ds_list_find_value(_pool, _i);
        var _elig = true;
        if (variable_struct_exists(_entry, "condition") && variable_struct_exists(_entry, "mod_name"))
            _elig = scr_gnx_eval_condition(_entry.condition, _entry.mod_name);
        if (_elig && _exclude != -1 && variable_struct_exists(_entry, "max_per_encounter"))
        {
            var _exc_count = 0;
            for (var _ei = 0; _ei < array_length(_exclude); _ei++)
            {
                if (_exclude[_ei] == _entry.class_id)
                    _exc_count++;
            }
            if (_exc_count >= _entry.max_per_encounter)
                _elig = false;
        }

        if (_elig)
        {
            _cum += _entry.weight;
            if (_roll <= _cum)
                break;
        }
        _i++;
    }

    var _lvl = irandom_range(_entry.min_lvl, _entry.max_lvl);
    var _result = { class_id: _entry.class_id, lvl: _lvl };
    if (variable_struct_exists(_entry, "ap_override"))
        _result.ap_override = _entry.ap_override;
    if (global.gnx_debug_verbose)
    {
        var _log = file_text_open_append(GNX_LOG);
        file_text_write_string(_log, "[GNX] pool_pick stage=" + string(_stage) + " lvl=" + string(_level) + " roll=" + string(_roll) + "/" + string(_total) + " class=" + string(_entry.class_id) + " picked_lvl=" + string(_lvl) + ((variable_struct_exists(_result, "ap_override")) ? " AP_OVERRIDE" : "") + "\n");
        file_text_close(_log);
    }
    return _result;
}

function scr_gnx_init_encounter_pools()
{
    gnx_pool_add(0, 1, 0, 50, 1, 2);
    gnx_pool_add(0, 1, 4, 50, 0, 0);
    gnx_pool_add(0, 2, 0, 30, 1, 2);
    gnx_pool_add(0, 2, 4, 50, 0, 1);
    gnx_pool_add(0, 2, 2, 20, 0, 1);
    gnx_pool_add(1, 0, 0, 35, 0, 1);
    gnx_pool_add(1, 0, 6, 65, 0, 1);
    gnx_pool_add(1, 1, 2, 50, 0, 0);
    gnx_pool_add(1, 1, 6, 50, 0, 1);
    gnx_pool_add(1, 2, 6, 30, 2, 3);
    gnx_pool_add(1, 2, 2, 30, 2, 3);
    gnx_pool_add(1, 2, 7, 40, 1, 2);
    gnx_pool_add(2, 0, 1, 50, 0, 1);
    gnx_pool_add(2, 0, 2, 50, 1, 2);
    gnx_pool_add(2, 1, 3, 65, 0, 1);
    gnx_pool_add(2, 1, 1, 35, 1, 2);
    gnx_pool_add(2, 2, 5, 30, 0, 1);
    gnx_pool_add(2, 2, 3, 30, 1, 2);
    gnx_pool_add(2, 2, 1, 40, 2, 3);
    gnx_pool_add(3, 0, 0, 25, 1, 3);
    gnx_pool_add(3, 0, 1, 25, 1, 3);
    gnx_pool_add(3, 0, 2, 25, 1, 3);
    gnx_pool_add(3, 0, 3, 25, 1, 3);
    gnx_pool_add(3, 1, 4, 50, 2, 4);
    gnx_pool_add(3, 1, 5, 50, 2, 4);
    gnx_pool_add(3, 2, 0, 17, 3, 4);
    gnx_pool_add(3, 2, 1, 17, 3, 4);
    gnx_pool_add(3, 2, 2, 17, 3, 4);
    gnx_pool_add(3, 2, 3, 17, 3, 4);
    gnx_pool_add(3, 2, 4, 16, 3, 4);
    gnx_pool_add(3, 2, 5, 16, 3, 4);
    gnx_pool_add(4, 0, 0, 12, 3, 4);
    gnx_pool_add(4, 0, 1, 12, 3, 4);
    gnx_pool_add(4, 0, 2, 12, 3, 4);
    gnx_pool_add(4, 0, 3, 12, 3, 4);
    gnx_pool_add(4, 0, 4, 12, 3, 4);
    gnx_pool_add(4, 0, 5, 12, 3, 4);
    gnx_pool_add(4, 0, 6, 12, 3, 4);
    gnx_pool_add(4, 0, 7, 12, 3, 4);
    gnx_pool_add(4, 1, 0, 12, 3, 4);
    gnx_pool_add(4, 1, 1, 12, 3, 4);
    gnx_pool_add(4, 1, 2, 12, 3, 4);
    gnx_pool_add(4, 1, 3, 12, 3, 4);
    gnx_pool_add(4, 1, 4, 12, 3, 4);
    gnx_pool_add(4, 1, 5, 12, 3, 4);
    gnx_pool_add(4, 1, 6, 12, 3, 4);
    gnx_pool_add(4, 1, 7, 12, 3, 4);
    var _log = file_text_open_append(GNX_LOG);
    file_text_write_string(_log, "[GNX] encounter pools initialized\n");
    file_text_close(_log);
}

function gnx_resolve_class_leg_variant(arg0, arg1, arg2, arg3)
{
    if (arg0 == undefined)
        return undefined;
    
    var _out = 
    {
        hair: gnx_resolve_layer_sprite(variable_struct_exists(arg0, "hair") ? arg0.hair : -1, arg1, arg2),
        head: gnx_resolve_layer_sprite(variable_struct_exists(arg0, "head") ? arg0.head : -1, arg1, arg2),
        breast: gnx_resolve_layer_sprite(variable_struct_exists(arg0, "breast") ? arg0.breast : -1, arg1, arg2),
        leg: gnx_resolve_layer_sprite(variable_struct_exists(arg0, "leg") ? arg0.leg : -1, arg1, arg2),
        leg_part: gnx_resolve_layer_sprite(variable_struct_exists(arg0, "leg_part") ? arg0.leg_part : -1, arg1, arg2)
    };
    
    if (arg3)
        _out.hand = gnx_resolve_layer_sprite(variable_struct_exists(arg0, "hand") ? arg0.hand : -1, arg1, arg2);
    
    return _out;
}

function gnx_resolve_class_phase(arg0, arg1, arg2, arg3)
{
    if (arg0 == undefined)
        return undefined;
    
    var _out = {};
    var _keys = ["leg_1", "leg_2", "leg_0", "leg_any"];
    var _i = 0;
    
    repeat (array_length(_keys))
    {
        var _k = _keys[_i++];
        
        if (variable_struct_exists(arg0, _k))
            variable_struct_set(_out, _k, gnx_resolve_class_leg_variant(variable_struct_get(arg0, _k), arg1, arg2, arg3));
    }
    
    if (variable_struct_exists(arg0, "cape"))
        _out.cape = gnx_resolve_layer_sprite(arg0.cape, arg1, arg2);
    
    return _out;
}

function gnx_resolve_class_big_phase(arg0, arg1, arg2)
{
    if (arg0 == undefined)
        return undefined;
    
    var _out = 
    {
        head: gnx_resolve_layer_sprite(variable_struct_exists(arg0, "head") ? arg0.head : -1, arg1, arg2),
        breast: gnx_resolve_layer_sprite(variable_struct_exists(arg0, "breast") ? arg0.breast : -1, arg1, arg2)
    };
    
    if (variable_struct_exists(arg0, "hair"))
        _out.hair = gnx_resolve_layer_sprite(arg0.hair, arg1, arg2);
    
    var _lkeys = ["leg_1", "leg_2", "leg_any"];
    var _i = 0;
    
    repeat (array_length(_lkeys))
    {
        var _k = _lkeys[_i++];
        
        if (variable_struct_exists(arg0, _k))
            variable_struct_set(_out, _k, gnx_resolve_layer_sprite(variable_struct_get(arg0, _k), arg1, arg2));
    }
    
    return _out;
}

function gnx_resolve_special_phase(arg0, arg1, arg2)
{
    if (arg0 == undefined)
        return undefined;
    
    var _out = 
    {
        spr_array: [],
        spr_c_array: []
    };
    
    if (variable_struct_exists(arg0, "spr_array"))
    {
        var _arr = arg0.spr_array;
        var _i = 0;
        
        repeat (array_length(_arr))
            array_push(_out.spr_array, gnx_resolve_layer_sprite(_arr[_i++], arg1, arg2));
    }
    
    if (variable_struct_exists(arg0, "spr_c_array"))
    {
        var _arr = arg0.spr_c_array;
        var _i = 0;
        
        repeat (array_length(_arr))
            array_push(_out.spr_c_array, gnx_resolve_layer_sprite(_arr[_i++], arg1, arg2));
    }
    
    return _out;
}

// gnx_get_mso(_class) — returns mon_spr_overrides struct for a modded class, or undefined
function gnx_get_mso(arg0)
{
    if (arg0 < 14) return undefined;
    var _rc = ds_map_find_value(global.class_registry, arg0);
    if (_rc == undefined) return undefined;
    if (!variable_struct_exists(_rc, "mon_spr_overrides")) return undefined;
    return _rc.mon_spr_overrides;
}

function gnx_resolve_naked_big_phase(arg0, arg1, arg2)
{
    if (arg0 == undefined)
        return undefined;

    var _out =
    {
        head: gnx_resolve_layer_sprite(variable_struct_exists(arg0, "head") ? arg0.head : -1, arg1, arg2),
        breast: gnx_resolve_layer_sprite(variable_struct_exists(arg0, "breast") ? arg0.breast : -1, arg1, arg2)
    };

    if (variable_struct_exists(arg0, "leg_1"))
        _out.leg_1 = gnx_resolve_layer_sprite(arg0.leg_1, arg1, arg2);
    if (variable_struct_exists(arg0, "leg_2"))
        _out.leg_2 = gnx_resolve_layer_sprite(arg0.leg_2, arg1, arg2);
    if (variable_struct_exists(arg0, "leg_any"))
        _out.leg_any = gnx_resolve_layer_sprite(arg0.leg_any, arg1, arg2);

    if (variable_struct_exists(arg0, "leg_0") && is_struct(arg0.leg_0))
    {
        var _l0 = arg0.leg_0;
        _out.leg_0 = {
            head: gnx_resolve_layer_sprite(variable_struct_exists(_l0, "head") ? _l0.head : -1, arg1, arg2),
            breast: gnx_resolve_layer_sprite(variable_struct_exists(_l0, "breast") ? _l0.breast : -1, arg1, arg2),
            leg: gnx_resolve_layer_sprite(variable_struct_exists(_l0, "leg") ? _l0.leg : -1, arg1, arg2)
        };
    }

    return _out;
}

function gnx_get_carry_base(arg0, arg1, arg2)
{
    // arg0 = class_id, arg1 = leg (0/1/2), arg2 = default _base sprite
    if (!ds_map_exists(global.class_registry, arg0))
        return arg2;
    var _rc = ds_map_find_value(global.class_registry, arg0);
    if (!variable_struct_exists(_rc, "carry_base_spr"))
        return arg2;
    var _cbs = _rc.carry_base_spr;
    if (is_struct(_cbs))
    {
        var _k = (arg1 == 0) ? "leg_0" : ((arg1 == 2) ? "leg_2" : "leg_1");
        if (variable_struct_exists(_cbs, _k) && sprite_exists(variable_struct_get(_cbs, _k)))
            return variable_struct_get(_cbs, _k);
        return arg2;
    }
    if (sprite_exists(_cbs))
        return _cbs;
    return arg2;
}

function gnx_hash_class_id(arg0, arg1)
{
    // arg0 = mod_name (folder), arg1 = class_name
    // Returns a stable class_id in [14, 9999] via djb2 hash, probing on collision.
    var _str = arg0 + "." + arg1;
    var _len = string_length(_str);
    var _h = 5381;
    for (var _i = 1; _i <= _len; _i++)
        _h = ((_h * 33) + ord(string_char_at(_str, _i))) & 0xFFFFFF;
    var _id = 14 + (_h mod 9986);
    while (ds_map_exists(global.class_registry, _id))
    {
        _id++;
        if (_id > 9999) _id = 14;
    }
    return _id;
}

function gnx_hash_cell_id(arg0)
{
    var _h = 5381;
    var _len = string_length(arg0);
    var _i = 1;
    repeat (_len)
    {
        _h = ((_h * 33) + ord(string_char_at(arg0, _i))) & 0xFFFFFF;
        _i++;
    }
    return 100 + (_h mod 9900);
}

function gnx_resolve_class(arg0, arg1)
{
    var _base_dir = global.gnx_mods_root + arg1 + "/";
    var _sprites = variable_struct_exists(arg0, "sprites") ? arg0.sprites : {};
    var _class_name = variable_struct_exists(arg0, "name") ? arg0.name : "UNKNOWN";
    var _allow_override = variable_struct_exists(arg0, "override") && arg0.override;
    var _class_id;
    if (_allow_override && variable_struct_exists(arg0, "class_id"))
        _class_id = arg0.class_id;
    else
        _class_id = gnx_hash_class_id(arg1, _class_name);
    ds_map_add(global.gnx_class_name_to_id, arg1 + "." + _class_name, _class_id);

    if (ds_map_exists(global.class_registry, _class_id) && !_allow_override)
    {
        var _log = file_text_open_append(GNX_LOG);
        file_text_write_string(_log, "[GNX] class_id " + string(_class_id) + " hash collision (probe failed) — skipped\n");
        file_text_close(_log);
        exit;
    }

    // Merge support: when overriding a class that already has a registry entry,
    // preserve the base entry's fields that this override does not explicitly set
    // (prevents a minimal override, e.g. voice/birth-only, from blanking vanilla sprites).
    var _is_merge = _allow_override && ds_map_exists(global.class_registry, _class_id);
    var _base = _is_merge ? ds_map_find_value(global.class_registry, _class_id) : undefined;

    if (_allow_override)
    {
        var _log = file_text_open_append(GNX_LOG);
        file_text_write_string(_log, "[GNX] class_id " + string(_class_id) + " override" + (_is_merge ? " (merge)" : "") + "\n");
        file_text_close(_log);
    }

    var _rclass =
    {
        name: variable_struct_exists(arg0, "name") ? arg0.name : "UNKNOWN",
        // On a merge, inherit is_special from the base entry when the override omits it,
        // so the clothing resolver below picks the right special/non-special path.
        is_special: variable_struct_exists(arg0, "is_special") ? arg0.is_special : ((_is_merge && is_struct(_base) && variable_struct_exists(_base, "is_special")) ? _base.is_special : false),
        has_hair: variable_struct_exists(arg0, "has_hair") ? arg0.has_hair : true,
        fap_mul: variable_struct_exists(arg0, "fap_mul") ? arg0.fap_mul : 1,
        bap_mul: variable_struct_exists(arg0, "bap_mul") ? arg0.bap_mul : 0,
        preg_c_override: variable_struct_exists(arg0, "preg_c_override") ? arg0.preg_c_override : -999,
        hand_color: gnx_resolve_layer_sprite(variable_struct_exists(arg0, "hand_color") ? arg0.hand_color : -1, _sprites, _base_dir),
        icon_spr: gnx_resolve_layer_sprite(variable_struct_exists(arg0, "icon") ? arg0.icon : -1, _sprites, _base_dir),
        icon_hair_spr: gnx_resolve_layer_sprite(variable_struct_exists(arg0, "icon_hair") ? arg0.icon_hair : -1, _sprites, _base_dir),
        carry_head_spr: gnx_resolve_layer_sprite("gnx:carry_head", _sprites, _base_dir),
        carry_hair_spr: gnx_resolve_layer_sprite("gnx:carry_hair", _sprites, _base_dir),
        voice_bank: -1,
        voice_pitch: -1
    };
    // GNX sound: per-class voice config
    if (variable_struct_exists(arg0, "voice"))
    {
        var _vc = arg0.voice;
        if (variable_struct_exists(_vc, "bank"))
            _rclass.voice_bank = arg1 + "." + _vc.bank;
        if (variable_struct_exists(_vc, "pitch"))
            _rclass.voice_pitch = _vc.pitch;
    }
    var _log = file_text_open_append(GNX_LOG);
    var _ispr = _rclass.icon_spr;
    file_text_write_string(_log, "[GNX] class=" + string(_class_id) + " icon_spr=" + string(_ispr) + "\n");
    
    if (_ispr != -1)
        file_text_write_string(_log, "  mod  icon: xo=" + string(sprite_get_xoffset(_ispr)) + " yo=" + string(sprite_get_yoffset(_ispr)) + " w=" + string(sprite_get_width(_ispr)) + " h=" + string(sprite_get_height(_ispr)) + "\n");
    
    var _ref = spr_unit_icon_head;
    file_text_write_string(_log, "  vanilla icon (class 0 frame 0): xo=" + string(sprite_get_xoffset(_ref)) + " yo=" + string(sprite_get_yoffset(_ref)) + " w=" + string(sprite_get_width(_ref)) + " h=" + string(sprite_get_height(_ref)) + "\n");
    file_text_close(_log);
    
    if (variable_struct_exists(arg0, "clothing_standard"))
    {
        var _cs_def = arg0.clothing_standard;
        var _cs = {};
        var _sp = ["phase_1", "phase_2"];
        var _si = 0;
        
        repeat (array_length(_sp))
        {
            var _sk = _sp[_si++];
            
            if (variable_struct_exists(_cs_def, _sk))
                variable_struct_set(_cs, _sk, _rclass.is_special ? gnx_resolve_special_phase(variable_struct_get(_cs_def, _sk), _sprites, _base_dir) : gnx_resolve_class_phase(variable_struct_get(_cs_def, _sk), _sprites, _base_dir, false));
        }
        
        if (variable_struct_exists(_cs_def, "max_row"))
            _cs.max_row = _cs_def.max_row;

        _rclass.clothing_standard = _cs;
    }

    if (variable_struct_exists(arg0, "clothing_big"))
    {
        var _cb_def = arg0.clothing_big;
        var _cb = {};
        
        if (_rclass.is_special)
        {
            var _bps = ["phase_0", "phase_1", "phase_2"];
            var _bi = 0;
            
            repeat (array_length(_bps))
            {
                var _bk = _bps[_bi++];
                
                if (variable_struct_exists(_cb_def, _bk))
                    variable_struct_set(_cb, _bk, gnx_resolve_special_phase(variable_struct_get(_cb_def, _bk), _sprites, _base_dir));
            }
        }
        else
        {
            var _bp = ["start", "idle", "loop"];
            var _bi = 0;
            
            repeat (array_length(_bp))
            {
                var _bk = _bp[_bi++];
                
                if (variable_struct_exists(_cb_def, _bk))
                    variable_struct_set(_cb, _bk, gnx_resolve_class_big_phase(variable_struct_get(_cb_def, _bk), _sprites, _base_dir));
            }
        }
        
        _rclass.clothing_big = _cb;
    }
    
    if (variable_struct_exists(arg0, "clothing_tent"))
    {
        var _ct_def = arg0.clothing_tent;
        var _ct = {};
        var _tp = ["phase_1", "phase_2", "phase_4"];
        var _ti = 0;
        
        repeat (array_length(_tp))
        {
            var _tk = _tp[_ti++];
            
            if (variable_struct_exists(_ct_def, _tk))
                variable_struct_set(_ct, _tk, _rclass.is_special ? gnx_resolve_special_phase(variable_struct_get(_ct_def, _tk), _sprites, _base_dir) : gnx_resolve_class_phase(variable_struct_get(_ct_def, _tk), _sprites, _base_dir, true));
        }
        
        _rclass.clothing_tent = _ct;
    }
    
    // --- naked layer loaders ---
    if (variable_struct_exists(arg0, "naked_standard"))
    {
        var _ns_def = arg0.naked_standard;
        var _ns = {};
        if (variable_struct_exists(_ns_def, "hand"))
            _ns.hand = gnx_resolve_layer_sprite(_ns_def.hand, _sprites, _base_dir);
        var _nsp = ["phase_1", "phase_2"];
        var _nsi = 0;
        repeat (array_length(_nsp))
        {
            var _nsk = _nsp[_nsi++];
            if (variable_struct_exists(_ns_def, _nsk))
                variable_struct_set(_ns, _nsk, gnx_resolve_class_phase(variable_struct_get(_ns_def, _nsk), _sprites, _base_dir, false));
        }
        _rclass.naked_standard = _ns;
    }

    if (variable_struct_exists(arg0, "naked_big"))
    {
        var _nb_def = arg0.naked_big;
        var _nb = {};
        if (variable_struct_exists(_nb_def, "hand"))
            _nb.hand = gnx_resolve_layer_sprite(_nb_def.hand, _sprites, _base_dir);
        var _nbp = ["start", "idle", "loop"];
        var _nbi = 0;
        repeat (array_length(_nbp))
        {
            var _nbk = _nbp[_nbi++];
            if (variable_struct_exists(_nb_def, _nbk))
                variable_struct_set(_nb, _nbk, gnx_resolve_naked_big_phase(variable_struct_get(_nb_def, _nbk), _sprites, _base_dir));
        }
        _rclass.naked_big = _nb;
    }

    if (variable_struct_exists(arg0, "naked_tent"))
    {
        var _nt_def = arg0.naked_tent;
        var _nt = {};
        if (variable_struct_exists(_nt_def, "hand"))
            _nt.hand = gnx_resolve_layer_sprite(_nt_def.hand, _sprites, _base_dir);
        var _ntp = ["phase_1", "phase_2", "phase_4"];
        var _nti = 0;
        repeat (array_length(_ntp))
        {
            var _ntk = _ntp[_nti++];
            if (variable_struct_exists(_nt_def, _ntk))
                variable_struct_set(_nt, _ntk, gnx_resolve_class_phase(variable_struct_get(_nt_def, _ntk), _sprites, _base_dir, false));
        }
        _rclass.naked_tent = _nt;
    }

    if (variable_struct_exists(arg0, "carry_base_spr"))
    {
        var _cbs_def = arg0.carry_base_spr;
        if (is_string(_cbs_def))
        {
            _rclass.carry_base_spr = gnx_resolve_layer_sprite(_cbs_def, _sprites, _base_dir);
        }
        else if (is_struct(_cbs_def))
        {
            var _cbr = {};
            if (variable_struct_exists(_cbs_def, "leg_0"))
                _cbr.leg_0 = gnx_resolve_layer_sprite(_cbs_def.leg_0, _sprites, _base_dir);
            if (variable_struct_exists(_cbs_def, "leg_1"))
                _cbr.leg_1 = gnx_resolve_layer_sprite(_cbs_def.leg_1, _sprites, _base_dir);
            if (variable_struct_exists(_cbs_def, "leg_2"))
                _cbr.leg_2 = gnx_resolve_layer_sprite(_cbs_def.leg_2, _sprites, _base_dir);
            _rclass.carry_base_spr = _cbr;
        }
    }

    if (variable_struct_exists(arg0, "gb1_breast_d2"))
        _rclass.gb1_breast_d2 = gnx_resolve_layer_sprite(arg0.gb1_breast_d2, _sprites, _base_dir);

    if (variable_struct_exists(arg0, "mon_spr_overrides"))
    {
        var _mso_def = arg0.mon_spr_overrides;
        var _mso = {};
        var _mso_keys = variable_struct_get_names(_mso_def);
        for (var _mi = 0; _mi < array_length(_mso_keys); _mi++)
        {
            var _mso_key = _mso_keys[_mi];
            var _mso_val = variable_struct_get(_mso_def, _mso_key);
            var _mso_spr = gnx_resolve_layer_sprite(_mso_val, _sprites, _base_dir);
            if (_mso_spr != -1)
                variable_struct_set(_mso, _mso_key, _mso_spr);
        }
        _rclass.mon_spr_overrides = _mso;
    }

    if (variable_struct_exists(arg0, "preg_mon_type_override"))
        _rclass.preg_mon_type_override = arg0.preg_mon_type_override;

    if (variable_struct_exists(arg0, "birth_classes"))
        _rclass.birth_classes = arg0.birth_classes;

    // birth_class: maps human class → goblin class (0-3) per species for raid troops
    if (variable_struct_exists(arg0, "birth_class"))
    {
        var _bc_def = arg0.birth_class;
        var _bc_map = [0, 0, 0, 0]; // default all species to goblin class 0
        var _bc_keys = ["goblin", "hobgoblin", "tentacle", "ogre"];
        for (var _bci = 0; _bci < 4; _bci++)
        {
            if (variable_struct_exists(_bc_def, _bc_keys[_bci]))
            {
                var _v = variable_struct_get(_bc_def, _bc_keys[_bci]);
                _bc_map[_bci] = clamp(floor(_v), 0, 3);
            }
        }
        _rclass.birth_class = _bc_map;
    }

    if (variable_struct_exists(arg0, "default_leg"))
        _rclass.default_leg = arg0.default_leg;

    if (variable_struct_exists(arg0, "trade_stage"))
    {
        var _ts = arg0.trade_stage;
        if (_ts >= 0 && _ts < array_length(global.gnx_trade_list))
            array_push(global.gnx_trade_list[_ts], _class_id);
    }

    if (variable_struct_exists(arg0, "raid_spawns"))
    {
        var _rs_arr = arg0.raid_spawns;
        var _rs_len = array_length(_rs_arr);
        var _ri = 0;
        
        repeat (_rs_len)
        {
            var _rs_e = _rs_arr[_ri++];
            var _rs_stage = _rs_e.stage;
            var _rs_level = _rs_e.level;
            
            if (_rs_level != 0)
            {
                var _rs_w = variable_struct_exists(_rs_e, "weight") ? _rs_e.weight : 10;
                var _rs_min = variable_struct_exists(_rs_e, "min_lvl") ? _rs_e.min_lvl : 0;
                var _rs_max = variable_struct_exists(_rs_e, "max_lvl") ? _rs_e.max_lvl : 1;
                var _rs_cond = variable_struct_exists(_rs_e, "condition") ? _rs_e.condition : undefined;
                if (_rs_cond != undefined)
                    scr_gnx_resolve_condition_refs(_rs_cond, arg1);
                var _rs_mpe = variable_struct_exists(_rs_e, "max_per_encounter") ? _rs_e.max_per_encounter : undefined;
                var _rs_apo = undefined;
                if (variable_struct_exists(_rs_e, "ap_override") && is_array(_rs_e.ap_override) && array_length(_rs_e.ap_override) == 2)
                    _rs_apo = _rs_e.ap_override;
                gnx_pool_add(_rs_stage, _rs_level, _class_id, _rs_w, _rs_min, _rs_max, _rs_cond, arg1, _rs_mpe, _rs_apo);
                _log = file_text_open_append(GNX_LOG);
                file_text_write_string(_log, "[GNX] raid_spawn class=" + string(_class_id) + " stage=" + string(_rs_stage) + " level=" + string(_rs_level) + " w=" + string(_rs_w) + " lvl=" + string(_rs_min) + "-" + string(_rs_max) + ((_rs_cond != undefined) ? " CONDITIONAL" : "") + "\n");
                file_text_close(_log);
            }
            else
            {
                _log = file_text_open_append(GNX_LOG);
                file_text_write_string(_log, "[GNX] raid_spawn skipped level=0 class=" + string(_class_id) + " stage=" + string(_rs_stage) + "\n");
                file_text_close(_log);
            }
        }
    }

    // --- Load post_raid behaviors ---
    if (variable_struct_exists(arg0, "post_raid"))
    {
        var _pr = arg0.post_raid;
        _pr.mod_name = arg1;
        // Resolve condition refs in cage_escape
        if (variable_struct_exists(_pr, "cage_escape"))
        {
            var _ce = _pr.cage_escape;
            if (variable_struct_exists(_ce, "condition"))
                scr_gnx_resolve_condition_refs(_ce.condition, arg1);
            // Resolve on_escape_event to full id
            if (variable_struct_exists(_ce, "on_escape_event") && is_string(_ce.on_escape_event))
                _ce.on_escape_event = arg1 + "." + _ce.on_escape_event;
            // Resolve on_survive_event to full id
            if (variable_struct_exists(_ce, "on_survive_event") && is_string(_ce.on_survive_event))
                _ce.on_survive_event = arg1 + "." + _ce.on_survive_event;
            // Resolve popup key to full id
            if (variable_struct_exists(_ce, "popup") && is_string(_ce.popup))
                _ce.popup = arg1 + "." + _ce.popup;
        }
        _rclass.post_raid = _pr;
        _log = file_text_open_append(GNX_LOG);
        file_text_write_string(_log, "[GNX] post_raid loaded for class=" + string(_class_id) + "\n");
        file_text_close(_log);
    }

    // Merge pass: copy every base-entry field this override did NOT explicitly provide,
    // so vanilla sprites/clothing/flags survive a partial override.
    if (_is_merge && is_struct(_base))
    {
        var _prov = {};  // set of _rclass field names the JSON explicitly set
        if (variable_struct_exists(arg0, "name")) _prov.name = true;
        if (variable_struct_exists(arg0, "is_special")) _prov.is_special = true;
        if (variable_struct_exists(arg0, "has_hair")) _prov.has_hair = true;
        if (variable_struct_exists(arg0, "fap_mul")) _prov.fap_mul = true;
        if (variable_struct_exists(arg0, "bap_mul")) _prov.bap_mul = true;
        if (variable_struct_exists(arg0, "preg_c_override")) _prov.preg_c_override = true;
        if (variable_struct_exists(arg0, "hand_color")) _prov.hand_color = true;
        if (variable_struct_exists(arg0, "icon")) _prov.icon_spr = true;
        if (variable_struct_exists(arg0, "icon_hair")) _prov.icon_hair_spr = true;
        if (variable_struct_exists(arg0, "voice")) { _prov.voice_bank = true; _prov.voice_pitch = true; }
        if (variable_struct_exists(arg0, "sprites"))
        {
            if (variable_struct_exists(arg0.sprites, "gnx:carry_head")) _prov.carry_head_spr = true;
            if (variable_struct_exists(arg0.sprites, "gnx:carry_hair")) _prov.carry_hair_spr = true;
        }
        var _condk = ["clothing_standard", "clothing_big", "clothing_tent", "naked_standard", "naked_big", "naked_tent", "carry_base_spr", "gb1_breast_d2", "mon_spr_overrides", "preg_mon_type_override", "birth_classes", "birth_class", "default_leg", "post_raid", "scr_unit"];
        for (var _pki = 0; _pki < array_length(_condk); _pki++)
            if (variable_struct_exists(arg0, _condk[_pki])) variable_struct_set(_prov, _condk[_pki], true);

        var _bkeys = variable_struct_get_names(_base);
        for (var _bki = 0; _bki < array_length(_bkeys); _bki++)
        {
            var _bk = _bkeys[_bki];
            if (!variable_struct_exists(_prov, _bk))
                variable_struct_set(_rclass, _bk, variable_struct_get(_base, _bk));
        }
    }

    if (ds_map_exists(global.class_registry, _class_id))
        ds_map_replace(global.class_registry, _class_id, _rclass);
    else
        ds_map_add(global.class_registry, _class_id, _rclass);
    
    _log = file_text_open_append(GNX_LOG);
    file_text_write_string(_log, "[GNX] class " + string(_class_id) + " registered: " + string(variable_struct_exists(arg0, "name") ? arg0.name : "?") + "\n");
    file_text_close(_log);
}

function scr_gnx_load_classes(arg0, arg1)
{
    var _path = global.gnx_mods_root + arg0 + "/" + arg1;
    
    if (!file_exists(_path))
    {
        gnx_report_mod_error("Mod '" + arg0 + "': classes file '" + arg1 + "' not found");
        exit;
    }

    var _f = file_text_open_read(_path);
    var _json = "";

    while (!file_text_eof(_f))
        _json += file_text_readln(_f);

    file_text_close(_f);
    var _log = file_text_open_append(GNX_LOG);
    file_text_write_string(_log, "[GNX] classes json len=" + string(string_length(_json)) + " head=" + string_copy(_json, 1, 80) + "\n");
    file_text_close(_log);

    var _defs;
    try
    {
        _defs = json_parse(_json);
    }
    catch (_e)
    {
        gnx_report_mod_error("Mod '" + arg0 + "': " + arg1 + " invalid (" + string(_e.message) + ")");
        exit;
    }

    if (!is_array(_defs))
    {
        gnx_report_mod_error("Mod '" + arg0 + "': " + arg1 + " is not a JSON array");
        exit;
    }
    
    var _i = 0;

    repeat (array_length(_defs))
        gnx_resolve_class(_defs[_i++], arg0);

    // Resolve birth_classes string refs after all classes are registered
    _i = 0;
    repeat (array_length(_defs))
    {
        var _def = _defs[_i++];
        if (variable_struct_exists(_def, "class_name") && variable_struct_exists(_def, "birth_classes"))
        {
            var _cname = _def.class_name;
            var _cid = global.gnx_class_name_to_id[? (arg0 + "." + _cname)];
            if (_cid != undefined)
            {
                var _creg = global.class_registry[? _cid];
                if (_creg != undefined && variable_struct_exists(_creg, "birth_classes"))
                {
                    var _bc = _creg.birth_classes;
                    if (is_array(_bc))
                    {
                        var _bc_len = array_length(_bc);
                        var _bc_out = [];
                        var _bi = 0;
                        repeat (_bc_len)
                        {
                            var _bv = _bc[_bi];
                            var _bm = ds_map_find_value(global.gnx_class_name_to_id, _bv);
                            array_push(_bc_out, (_bm != undefined) ? _bm : _bv);
                            _bi++;
                        }
                        _creg.birth_classes = _bc_out;
                    }
                }
            }
        }
    }
}

function scr_gnx_unoccupy_log()
{
    var _log = file_text_open_append(GNX_LOG);
    file_text_write_string(_log, "[GNX] scr_gnx_unoccupy_log slot h=" + string(slot_data.h_type) + "\n");
    file_text_close(_log);
}

function scr_gnx_spr_ok(arg0)
{
    if (arg0 == -1)
        return true;

    if (is_string(arg0) || is_undefined(arg0) || is_struct(arg0) || is_array(arg0))
        return false;

    return sprite_exists(arg0);
}

function scr_gnx_collect_bad_spr(arg0, arg1)
{
    var _bad = "";

    if (is_array(arg0))
    {
        for (var _i = 0; _i < array_length(arg0); _i++)
        {
            if (!scr_gnx_spr_ok(arg0[_i]))
                _bad += arg1 + "[" + string(_i) + "] ";
        }

        return _bad;
    }

    if (!is_struct(arg0))
    {
        if (!scr_gnx_spr_ok(arg0))
            _bad += arg1 + " ";

        return _bad;
    }

    var _names = variable_struct_get_names(arg0);

    for (var _i = 0; _i < array_length(_names); _i++)
    {
        var _v = variable_struct_get(arg0, _names[_i]);

        if (is_struct(_v) || is_array(_v))
            _bad += scr_gnx_collect_bad_spr(_v, arg1 + "." + _names[_i]);
        else if (!scr_gnx_spr_ok(_v))
            _bad += arg1 + "." + _names[_i] + " ";
    }

    return _bad;
}

/// @desc Serialize the entire current game state into a deep-cloned struct.
///       Replicates scr_save_game data building without file I/O.
///       Returns a struct safe to store in gnx_inactive_maps (no shared refs).
function scr_gnx_snapshot_map()
{
    var _save_data = {};
    var _slot_hold_id = -1;
    var _hold_id = obj_control.hold_id;

    if (_hold_id != -1 && _hold_id.drag_type == UnknownEnum.Value_2)
        _slot_hold_id = _hold_id.source_id;

    // --- Slots ---
    var _slot_list = [];
    var _slot_num = 0;

    for (var i = 0; i <= global.val.floor; i++)
    {
        var _list = global.slot_list[i];
        var _num = ds_list_size(_list);

        for (var ii = 0; ii < _num; ii++)
        {
            var _slot_id = ds_list_find_value(_list, ii);
            var _data = {};

            with (_slot_id)
            {
                _data.slot_data = slot_data;

                if (_slot_hold_id == _slot_id)
                {
                    _data.unit_data = _hold_id.unit_data;
                    _data.slot_data.anim_struct.spr_type = UnknownEnum.Value_1;
                }
                else
                {
                    _data.unit_data = unit_data;
                }

                _data.pos = ii;
                var _prop_num = array_length(slot_data.prop);

                for (var iii = 0; iii < _prop_num; iii++)
                {
                    with (slot_data.prop[iii].prop_id)
                    {
                        _data.slot_data.prop[iii].x_pos = x;
                        _data.slot_data.prop[iii].y_pos = y;
                        _data.slot_data.prop[iii].d_pos = depth;
                        _data.slot_data.prop[iii].xscale = image_xscale;
                        _data.slot_data.prop[iii].yscale = image_yscale;
                        _data.slot_data.prop[iii].iindex = image_index;

                        if (prop_data.prop_type == UnknownEnum.Value_40)
                            _data.slot_data.prop[iii].mon_data = prop_data.mon_data;
                    }
                }
            }

            _slot_list[_slot_num] = _data;
            _slot_num++;
        }
    }

    _save_data.slot_list = _slot_list;

    // --- Goblins ---
    var _mon_list = [];
    var _num = 0;

    if (instance_exists(obj_mon))
    {
        with (obj_mon)
        {
            var _data = {};
            _data.x_pos = x;
            _data.y_pos = y;
            _data.d_pos = depth;
            _data.xscale = image_xscale;
            _data.yscale = image_yscale;
            _data.iindex = image_index;
            _data.ispeed = image_speed;
            _data.vis = visible;
            _data.mon_data = mon_data;
            _data.slot_pos = -1;

            if (mon_data.slot_id != -1)
                _data.slot_pos = ds_list_find_index(global.slot_list[mon_data.mon_floor], mon_data.slot_id);

            switch (mon_data.task)
            {
                case UnknownEnum.Value_3:
                    if (mon_data.placement_num == 0)
                    {
                        if (mon_data.carry_start_id != -1)
                            _data.carry_start_id = ds_list_find_index(global.slot_list[mon_data.mon_floor], mon_data.carry_start_id);

                        if (mon_data.carry_end_id != -1)
                            _data.carry_end_id = ds_list_find_index(global.slot_list[mon_data.mon_floor], mon_data.carry_end_id);
                    }
                    break;
            }

            _mon_list[_num] = _data;
            _num++;
        }
    }

    _save_data.mon_list = _mon_list;

    // --- Raid data ---
    with (obj_np.obj_raid)
    {
        raid_data.raid_pos = layer_sequence_get_headpos(seq_id);
        _save_data.raid_data = raid_data;
    }

    // --- Quest state ---
    scr_gnx_save_quest_state();

    // --- Globals + ds_lists ---
    var _global = {};
    _global.val = global.val;
    _global.unlock = global.unlock;
    _global.unit_num = scr_all_fem_num_cal();
    _global.mon_num = global.val.nest_num[0];

    var _list = [];
    _num = ds_list_size(global.unit_list);
    for (var i = 0; i < _num; i++)
        _list[i] = ds_list_find_value(global.unit_list, i);
    _global.unit_list = _list;

    _list = [];
    _num = ds_list_size(global.front_row);
    for (var i = 0; i < _num; i++)
        _list[i] = ds_list_find_value(global.front_row, i);
    _global.front_row = _list;

    _list = [];
    _num = ds_list_size(global.back_row);
    for (var i = 0; i < _num; i++)
        _list[i] = ds_list_find_value(global.back_row, i);
    _global.back_row = _list;

    _list = [];
    _num = ds_list_size(global.new_button_list);
    for (var i = 0; i < _num; i++)
        _list[i] = ds_list_find_value(global.new_button_list, i);
    _global.new_button_list = _list;

    _list = [];
    _num = ds_list_size(global.inv_list);
    for (var i = 0; i < _num; i++)
        _list[i] = ds_list_find_value(global.inv_list, i);
    _global.inv_list = _list;

    _list = [];
    _num = ds_list_size(global.raid_inv_list);
    for (var i = 0; i < _num; i++)
        _list[i] = ds_list_find_value(global.raid_inv_list, i);
    _global.raid_inv_list = _list;

    _list = [];
    _num = ds_list_size(global.quest_list);
    for (var i = 0; i < _num; i++)
    {
        var _qe = ds_list_find_value(global.quest_list, i);
        if (!variable_struct_exists(_qe, "gnx_event_id"))
            array_push(_list, _qe);
    }
    _global.quest_list = _list;

    _list = [];
    _num = ds_list_size(global.noti_list);
    for (var i = 0; i < _num; i++)
    {
        var _ne = ds_list_find_value(global.noti_list, i);
        if (!variable_struct_exists(_ne, "gnx_event_id"))
            array_push(_list, _ne);
    }
    _global.noti_list = _list;

    _list = [];
    _num = ds_list_size(global.new_guide_list);
    for (var i = 0; i < _num; i++)
        _list[i] = ds_list_find_value(global.new_guide_list, i);
    _global.new_guide_list = _list;

    _list = [];
    _num = ds_list_size(global.front_row_save);
    for (var i = 0; i < _num; i++)
        _list[i] = ds_list_find_value(global.front_row_save, i);
    _global.front_row_save = _list;

    _list = [];
    _num = ds_list_size(global.back_row_save);
    for (var i = 0; i < _num; i++)
        _list[i] = ds_list_find_value(global.back_row_save, i);
    _global.back_row_save = _list;

    _save_data.global_list = _global;

    // Deep clone via JSON round-trip to break all shared references.
    // _global.val = global.val is a reference; without this, mutations
    // during gameplay would corrupt the stored snapshot.
    return json_parse(json_stringify(_save_data));
}

/// @desc Travel from the active map to a target map.
///       Snapshots current state, stores it, restores or creates target.
/// @param {String} _target_mod  Mod name owning the target map, or "vanilla"
/// @returns {Bool} true if travel initiated, false if blocked
/// Path A: triggers the compiled save-load state machine (obj_np.load_state = Value_6)
/// instead of manually calling scr_create_initials + scr_load_slot. This ensures
/// all permanent HUD buttons (Value_32/34/35) are recreated by compiled code.
/// The load happens asynchronously (next frame via obj_np Step event, deferred
/// through gnx_trigger_load flag checked at top of obj_control_Step_0).
function scr_gnx_travel(_target_mod)
{
    // [SHELVED 1.3.11] Multi-map disabled
    if (!global.gnx_multimap_enabled) return false;

    // --- Blocking checks ---
    // Raid active
    var _raid_state = 0;
    with (obj_np.obj_raid) _raid_state = raid_data.raid_state;
    if (_raid_state != 0)
    {
        var _l = file_text_open_append(GNX_LOG);
        file_text_write_string(_l, "[GNX-MAP] travel blocked: raid active\n");
        file_text_close(_l);
        return false;
    }

    // Window/dialog open - allow raid window (4) and background slot windows (6,7,8,10,12)
    var _has_blocking_window = false;
    var _blocking_types = "";
    with (obj_window)
    {
        if (interact_type != 4 && interact_type != 6 && interact_type != 7 && interact_type != 8 && interact_type != 10 && interact_type != 12)
        {
            _has_blocking_window = true;
            _blocking_types += string(interact_type) + " ";
        }
    }
    if (_has_blocking_window)
    {
        var _l = file_text_open_append(GNX_LOG);
        file_text_write_string(_l, "[GNX-MAP] travel blocked: window types=" + _blocking_types + "\n");
        file_text_close(_l);
        return false;
    }

    // Drag in progress
    if (obj_control.hold_id != -1)
    {
        var _l = file_text_open_append(GNX_LOG);
        file_text_write_string(_l, "[GNX-MAP] travel blocked: drag in progress\n");
        file_text_close(_l);
        return false;
    }

    // Already on target
    if (global.gnx_active_map == _target_mod)
    {
        var _l = file_text_open_append(GNX_LOG);
        file_text_write_string(_l, "[GNX-MAP] travel skipped: already on " + _target_mod + "\n");
        file_text_close(_l);
        return true;
    }

    // Already a load pending (double trigger guard)
    if (variable_global_exists("gnx_trigger_load") && global.gnx_trigger_load)
    {
        var _l = file_text_open_append(GNX_LOG);
        file_text_write_string(_l, "[GNX-MAP] travel blocked: load already pending\n");
        file_text_close(_l);
        return false;
    }

    var _log = file_text_open_append(GNX_LOG);
    file_text_write_string(_log, "[GNX-MAP] travel: " + global.gnx_active_map + " -> " + _target_mod + "\n");
    file_text_close(_log);

    // --- Snapshot active map ---
    var _snapshot = scr_gnx_snapshot_map();
    variable_struct_set(global.gnx_inactive_maps, global.gnx_active_map, _snapshot);

    // --- Resolve target ---
    var _target_snapshot = variable_struct_get(global.gnx_inactive_maps, _target_mod);
    global.gnx_active_map = _target_mod;

    if (_target_snapshot != undefined)
    {
        // Returning to a previously visited map: load from snapshot
        variable_struct_remove(global.gnx_inactive_maps, _target_mod);
        global.gnx_travel_data = _target_snapshot;
    }
    else
    {
        // First visit: no snapshot. Leave gnx_travel_data = -1.
        // The trigger handler will use New Game path (load_file = -1),
        // and the compiled state machine creates entrance slots.
        global.gnx_travel_data = -1;
    }

    // --- Trigger deferred load (next frame) ---
    // obj_control_Step_0 sees gnx_trigger_load, calls scr_create_initials()
    // (compiled state machine doesn't do this from gameplay), then sets
    // load_state = 6. For restore: load_file = 0 forces Load Game path
    // (scr_load_slot consumes gnx_travel_data). For fresh: load_file = -1
    // triggers New Game path (entrance slot creation).
    global.gnx_trigger_load = true;

    return true;
}

/// @desc Create clickable travel buttons on the raid map screen.
///       Called after scr_create_map_buttons() at 3 sites.
/// @desc No-op. Travel buttons are drawn in GUI by scr_gnx_draw_travel_buttons_gui
///       and clicks are handled by scr_gnx_check_travel_click (Step context).
///       Kept as stub so the 3 call sites don't need changing.
function scr_gnx_create_travel_btn()
{
    gui = true;
}

function scr_gnx_draw_travel_button()
{
    // Visual handled by scr_gnx_draw_travel_buttons_gui in Draw GUI
    // This empty draw_func prevents obj_button from drawing its default sprite
}

function scr_gnx_create_travel_buttons()
{
    var _current = global.gnx_active_map;
    for (var _i = 0; _i < array_length(global.gnx_travel_locations); _i++)
    {
        var _tl = global.gnx_travel_locations[_i];
        if (_tl.show_on == _current)
        {
            // Use type=45 (known to compiled obj_button) with button_num 100+ to distinguish from real shop
            scr_create_button(_tl.x, _tl.y, depth - 5, spr_button_stage, 45, id, scr_gnx_create_travel_btn, -1, -1, 100 + _i, 0);
        }
    }
}

/// @desc Draw callback for travel buttons. Draws a tinted pulsing marker + label.
/// @desc Draw travel button markers in GUI space. Called from scr_draw_raid.
function scr_gnx_draw_travel_buttons_gui()
{
    var _current = global.gnx_active_map;
    for (var _i = 0; _i < array_length(global.gnx_travel_locations); _i++)
    {
        var _tl = global.gnx_travel_locations[_i];
        if (_tl.show_on == _current)
        {
            var _pulse = 0.6 + 0.4 * sin(current_time / 400);
            draw_sprite_ext(spr_button_stage, 0, _tl.x, _tl.y, 1, 1, 0, c_aqua, _pulse);
            draw_set_halign(fa_center);
            draw_set_color(c_white);
            draw_set_alpha(1);
            draw_text(_tl.x + 13, _tl.y + 28, _tl.label);
            draw_set_halign(fa_left);
        }
    }
}

/// @desc Check GUI-space click on travel buttons. Called from obj_control Step.
///       spr_button_stage is 27x27. Uses device_mouse_x/y_to_gui for GUI coords.

// scr_gnx_restore_map and scr_gnx_create_fresh_map REMOVED (Path A).
// Travel now triggers the compiled state machine (obj_np.load_state = Value_6)
// which handles all cleanup, scr_create_initials, scr_load_slot, and HUD recreation.
// gnx_travel_data carries the snapshot (or "fresh" sentinel) between the calls.

// [SHELVED 1.3.11] scr_gnx_gmlc_expose_functions removed (GMLC shelved)
// Restore from gml_shelved/ to re-enable

function scr_gnx_test_suite()
{
    var _log = file_text_open_append(GNX_LOG);
    var _pass = 0;
    var _fail = 0;
    file_text_write_string(_log, "[GNX-TEST] ============================================================\n");
    file_text_write_string(_log, "[GNX-TEST] Suite start\n");
    var _ok = ds_exists(global.cell_registry, ds_type_map);
    
    if (_ok)
    {
        file_text_write_string(_log, "[GNX-TEST] PASS  T01 cell_registry is a map\n");
        _pass++;
    }
    else
    {
        file_text_write_string(_log, "[GNX-TEST] FAIL  T01 cell_registry not a map\n");
        _fail++;
    }
    
    _ok = ds_exists(global.class_registry, ds_type_map);
    
    if (_ok)
    {
        file_text_write_string(_log, "[GNX-TEST] PASS  T02 class_registry is a map\n");
        _pass++;
    }
    else
    {
        file_text_write_string(_log, "[GNX-TEST] FAIL  T02 class_registry not a map\n");
        _fail++;
    }
    
    _ok = ds_exists(global.bl_lookup, ds_type_map);
    
    if (_ok)
    {
        file_text_write_string(_log, "[GNX-TEST] PASS  T03 bl_lookup is a map\n");
        _pass++;
    }
    else
    {
        file_text_write_string(_log, "[GNX-TEST] FAIL  T03 bl_lookup not a map\n");
        _fail++;
    }
    
    _ok = ds_exists(global.gnx_encounter_pools, ds_type_map);
    
    if (_ok)
    {
        file_text_write_string(_log, "[GNX-TEST] PASS  T04 gnx_encounter_pools is a map\n");
        _pass++;
    }
    else
    {
        file_text_write_string(_log, "[GNX-TEST] FAIL  T04 gnx_encounter_pools not a map\n");
        _fail++;
    }
    
    _ok = ds_exists(global.front_row, ds_type_list);
    
    if (_ok)
    {
        file_text_write_string(_log, "[GNX-TEST] PASS  T05 front_row is a list\n");
        _pass++;
    }
    else
    {
        file_text_write_string(_log, "[GNX-TEST] FAIL  T05 front_row not a list\n");
        _fail++;
    }
    
    _ok = ds_exists(global.back_row, ds_type_list);
    
    if (_ok)
    {
        file_text_write_string(_log, "[GNX-TEST] PASS  T06 back_row is a list\n");
        _pass++;
    }
    else
    {
        file_text_write_string(_log, "[GNX-TEST] FAIL  T06 back_row not a list\n");
        _fail++;
    }
    
    var _n = ds_map_size(global.cell_registry);
    _ok = _n >= 39;
    
    if (_ok)
    {
        file_text_write_string(_log, "[GNX-TEST] PASS  T07 cell_registry size=" + string(_n) + " (>=39)\n");
        _pass++;
    }
    else
    {
        file_text_write_string(_log, "[GNX-TEST] FAIL  T07 cell_registry size=" + string(_n) + " (<39)\n");
        _fail++;
    }
    
    _n = ds_map_size(global.class_registry);
    _ok = _n >= 14;

    if (_ok)
    {
        file_text_write_string(_log, "[GNX-TEST] PASS  T08 class_registry size=" + string(_n) + " (>=14)\n");
        _pass++;
    }
    else
    {
        file_text_write_string(_log, "[GNX-TEST] FAIL  T08 class_registry size=" + string(_n) + " (<14)\n");
        _fail++;
    }
    
    _ok = ds_exists(global.gnx_cov, ds_type_map);
    
    if (_ok)
    {
        file_text_write_string(_log, "[GNX-TEST] PASS  T09 gnx_cov is a map\n");
        _pass++;
    }
    else
    {
        file_text_write_string(_log, "[GNX-TEST] FAIL  T09 gnx_cov not a map\n");
        _fail++;
    }
    
    _n = ds_map_size(global.gnx_encounter_pools);
    _ok = _n > 0;
    
    if (_ok)
    {
        file_text_write_string(_log, "[GNX-TEST] PASS  T10 encounter_pools size=" + string(_n) + "\n");
        _pass++;
    }
    else
    {
        file_text_write_string(_log, "[GNX-TEST] FAIL  T10 encounter_pools empty\n");
        _fail++;
    }
    
    var _exp = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 17, 18, 19, 20, 21, 22, 23, 24, 25, 27, 28, 29, 30, 31, 32, 33, 34, 36, 37, 38, 39, 40, 41, 42];
    var _missing = "";
    var _i = 0;
    
    repeat (array_length(_exp))
    {
        var _ht = _exp[_i++];
        
        if (!ds_map_exists(global.cell_registry, _ht))
            _missing += (string(_ht) + " ");
    }
    
    if (_missing == "")
    {
        file_text_write_string(_log, "[GNX-TEST] PASS  T11 all 39 cells registered\n");
        _pass++;
    }
    else
    {
        file_text_write_string(_log, "[GNX-TEST] FAIL  T11 cells missing: " + _missing + "\n");
        _fail++;
    }
    var _missing_c = "";
    var _ci = 0;
    
    repeat (14)
    {
        if (!ds_map_exists(global.class_registry, _ci))
            _missing_c += (string(_ci) + " ");

        _ci++;
    }

    if (_missing_c == "")
    {
        file_text_write_string(_log, "[GNX-TEST] PASS  T12 classes 0-13 all registered\n");
        _pass++;
    }
    else
    {
        file_text_write_string(_log, "[GNX-TEST] FAIL  T12 classes missing: " + _missing_c + "\n");
        _fail++;
    }
    
    if (ds_map_exists(global.cell_registry, 1))
    {
        var _c1 = ds_map_find_value(global.cell_registry, 1);
        _ok = variable_struct_exists(_c1, "name") && variable_struct_exists(_c1, "physical") && variable_struct_exists(_c1, "human_spr");
        
        if (_ok)
        {
            var _p1 = _c1.physical;
            _ok = variable_struct_exists(_p1, "allow_preg") && variable_struct_exists(_p1, "max_mon_num") && variable_struct_exists(_p1, "anal") && variable_struct_exists(_p1, "spr_row_pos");
        }
        
        if (_ok)
        {
            file_text_write_string(_log, "[GNX-TEST] PASS  T13 WALL1 registry entry complete\n");
            _pass++;
        }
        else
        {
            file_text_write_string(_log, "[GNX-TEST] FAIL  T13 WALL1 registry entry missing fields\n");
            _fail++;
        }
    }
    else
    {
        file_text_write_string(_log, "[GNX-TEST] FAIL  T13 WALL1 (h=1) not in registry\n");
        _fail++;
    }
    
    if (ds_map_exists(global.cell_registry, 36))
    {
        var _c36 = ds_map_find_value(global.cell_registry, 36);
        _ok = variable_struct_exists(_c36, "human_spr") && _c36.human_spr.mode == "fixed";
        
        if (_ok)
        {
            file_text_write_string(_log, "[GNX-TEST] PASS  T14 DAIRY human_spr mode=fixed\n");
            _pass++;
        }
        else
        {
            file_text_write_string(_log, "[GNX-TEST] FAIL  T14 DAIRY human_spr mode wrong\n");
            _fail++;
        }
    }
    else
    {
        file_text_write_string(_log, "[GNX-TEST] FAIL  T14 DAIRY (h=36) not in registry\n");
        _fail++;
    }
    
    if (ds_map_exists(global.cell_registry, 27))
    {
        var _c27 = ds_map_find_value(global.cell_registry, 27);
        _ok = variable_struct_exists(_c27, "slot_type") && _c27.slot_type == 3;
        
        if (_ok)
        {
            file_text_write_string(_log, "[GNX-TEST] PASS  T15 BIND1 slot_type=3 (tent)\n");
            _pass++;
        }
        else
        {
            file_text_write_string(_log, "[GNX-TEST] FAIL  T15 BIND1 slot_type wrong (got " + string(_c27.slot_type) + ")\n");
            _fail++;
        }
    }
    else
    {
        file_text_write_string(_log, "[GNX-TEST] FAIL  T15 BIND1 (h=27) not in registry\n");
        _fail++;
    }
    
    // T16: any mod-added classes (id>=14) must be structurally complete.
    // Generic check - does not assume any specific mod class (e.g. test_mod's Elf).
    var _cls_n = ds_map_size(global.class_registry);
    var _bad_mod_classes = "";

    if (_cls_n > 14)
    {
        var _ck = ds_map_find_first(global.class_registry);

        while (_ck != undefined)
        {
            if (_ck >= 14)
            {
                var _mc = ds_map_find_value(global.class_registry, _ck);
                var _mc_ok = variable_struct_exists(_mc, "name") && variable_struct_exists(_mc, "is_special") && variable_struct_exists(_mc, "has_hair") && variable_struct_exists(_mc, "clothing_standard");

                if (!_mc_ok)
                    _bad_mod_classes += (string(_ck) + " ");
            }

            _ck = ds_map_find_next(global.class_registry, _ck);
        }
    }

    if (_bad_mod_classes == "")
    {
        file_text_write_string(_log, "[GNX-TEST] PASS  T16 mod classes valid (extra=" + string(max(0, _cls_n - 14)) + ")\n");
        _pass++;
    }
    else
    {
        file_text_write_string(_log, "[GNX-TEST] FAIL  T16 mod class entries invalid: " + _bad_mod_classes + "\n");
        _fail++;
    }
    
    // T17: gnx_registered_cells must be an array; any registered h_type must
    // resolve to a complete cell_registry entry. Empty array (no mods) is valid.
    _ok = is_array(global.gnx_registered_cells);
    var _rn = _ok ? array_length(global.gnx_registered_cells) : 0;
    var _bad_mod_cells = "";

    for (var _i = 0; _i < _rn; _i++)
    {
        var _rh = global.gnx_registered_cells[_i];
        var _rht = is_struct(_rh) ? _rh.h_type : _rh;
        var _rc = ds_map_find_value(global.cell_registry, _rht);
        var _rc_ok = (_rc != undefined) && variable_struct_exists(_rc, "name") && variable_struct_exists(_rc, "physical") && variable_struct_exists(_rc, "human_spr");

        if (!_rc_ok)
            _bad_mod_cells += (string(_rht) + " ");
    }

    if (_ok && _bad_mod_cells == "")
    {
        file_text_write_string(_log, "[GNX-TEST] PASS  T17 gnx_registered_cells valid (len=" + string(_rn) + ")\n");
        _pass++;
    }
    else if (!_ok)
    {
        file_text_write_string(_log, "[GNX-TEST] FAIL  T17 gnx_registered_cells not an array\n");
        _fail++;
    }
    else
    {
        file_text_write_string(_log, "[GNX-TEST] FAIL  T17 gnx_registered_cells invalid entries: " + _bad_mod_cells + "\n");
        _fail++;
    }
    
    _ok = global.use_legacy_dispatch == false;
    
    if (_ok)
    {
        file_text_write_string(_log, "[GNX-TEST] PASS  T18 use_legacy_dispatch=false\n");
        _pass++;
    }
    else
    {
        file_text_write_string(_log, "[GNX-TEST] FAIL  T18 use_legacy_dispatch=true (registry bypassed!)\n");
        _fail++;
    }

    // T19: gnx_mod_data exists as struct on global.val
    _ok = is_struct(global.val.gnx_mod_data);
    if (_ok)
    {
        file_text_write_string(_log, "[GNX-TEST] PASS  T19 gnx_mod_data is a struct\n");
        _pass++;
    }
    else
    {
        file_text_write_string(_log, "[GNX-TEST] FAIL  T19 gnx_mod_data not a struct\n");
        _fail++;
    }

    // T20: set_state / get_state round-trip (synthetic key, no mod required)
    var _selftest_mod = "_gnx_selftest";
    scr_gnx_set_state(_selftest_mod, "_test_rt", 42);
    var _rt = scr_gnx_get_state(_selftest_mod, "_test_rt");
    _ok = (_rt == 42);
    // Also verify it landed in global.val (persistence path)
    if (_ok)
        _ok = variable_struct_get(variable_struct_get(global.val.gnx_mod_data, _selftest_mod), "_test_rt") == 42;
    // Cleanup: remove the entire synthetic struct (created fresh by scr_gnx_set_state)
    if (variable_struct_exists(global.gnx_mod_state, _selftest_mod))
        variable_struct_remove(global.gnx_mod_state, _selftest_mod);
    if (variable_struct_exists(global.val.gnx_mod_data, _selftest_mod))
        variable_struct_remove(global.val.gnx_mod_data, _selftest_mod);
    if (_ok)
    {
        file_text_write_string(_log, "[GNX-TEST] PASS  T20 set/get round-trip + persistence path\n");
        _pass++;
    }
    else
    {
        file_text_write_string(_log, "[GNX-TEST] FAIL  T20 set/get round-trip: got " + string(_rt) + "\n");
        _fail++;
    }
    // T21: fixed-mode cells have phase_0/1/2/4 with valid spr_array & spr_c_array
    var _bad21 = "";
    var _k21 = ds_map_find_first(global.cell_registry);
    while (_k21 != undefined)
    {
        var _c21 = ds_map_find_value(global.cell_registry, _k21);
        if (is_struct(_c21) && variable_struct_exists(_c21, "human_spr") && is_struct(_c21.human_spr)
            && variable_struct_exists(_c21.human_spr, "mode") && _c21.human_spr.mode == "fixed")
        {
            var _phases21 = ["phase_0", "phase_1", "phase_2", "phase_4"];
            for (var _pi21 = 0; _pi21 < 4; _pi21++)
            {
                if (variable_struct_exists(_c21.human_spr, _phases21[_pi21]))
                    _bad21 += scr_gnx_collect_bad_spr(variable_struct_get(_c21.human_spr, _phases21[_pi21]), string(_k21) + "." + _phases21[_pi21]);
            }
        }
        _k21 = ds_map_find_next(global.cell_registry, _k21);
    }
    if (_bad21 == "")
    {
        file_text_write_string(_log, "[GNX-TEST] PASS  T21 fixed-mode cell sprites valid\n");
        _pass++;
    }
    else
    {
        file_text_write_string(_log, "[GNX-TEST] FAIL  T21 fixed-mode bad sprites: " + _bad21 + "\n");
        _fail++;
    }

    // T22: every class clothing table resolves to real sprites (arrays + leaf fields)
    var _bad22 = "";
    var _k22 = ds_map_find_first(global.class_registry);
    while (_k22 != undefined)
    {
        var _cl22 = ds_map_find_value(global.class_registry, _k22);
        if (is_struct(_cl22))
        {
            var _tabs22 = ["clothing_standard", "clothing_big", "clothing_tent"];
            for (var _t = 0; _t < 3; _t++)
            {
                if (variable_struct_exists(_cl22, _tabs22[_t]))
                    _bad22 += scr_gnx_collect_bad_spr(variable_struct_get(_cl22, _tabs22[_t]), "c" + string(_k22) + "." + _tabs22[_t]);
            }
        }
        _k22 = ds_map_find_next(global.class_registry, _k22);
    }
    if (_bad22 == "")
    {
        file_text_write_string(_log, "[GNX-TEST] PASS  T22 class clothing sprites valid\n");
        _pass++;
    }
    else
    {
        file_text_write_string(_log, "[GNX-TEST] FAIL  T22 class clothing bad sprites: " + _bad22 + "\n");
        _fail++;
    }

    // T23: every mod listed in index.txt loaded (manifest/version compat)
    var _ok23 = is_array(global.gnx_indexed_mods) && is_array(global.gnx_loaded_mods);
    var _miss23 = "";
    if (_ok23)
    {
        for (var _mi = 0; _mi < array_length(global.gnx_indexed_mods); _mi++)
        {
            var _mn = global.gnx_indexed_mods[_mi];
            var _found = false;
            for (var _lj = 0; _lj < array_length(global.gnx_loaded_mods); _lj++)
            {
                if (global.gnx_loaded_mods[_lj] == _mn) { _found = true; break; }
            }
            if (!_found)
                _miss23 += _mn + " ";
        }
    }
    if (_ok23 && _miss23 == "")
    {
        file_text_write_string(_log, "[GNX-TEST] PASS  T23 all indexed mods loaded (" + string(_ok23 ? array_length(global.gnx_indexed_mods) : 0) + ")\n");
        _pass++;
    }
    else
    {
        file_text_write_string(_log, "[GNX-TEST] FAIL  T23 mods not loaded: " + _miss23 + "\n");
        _fail++;
    }

    // T24: required_class (cells) and birth_classes (classes) resolve in class_registry
    var _bad24 = "";
    var _k24 = ds_map_find_first(global.cell_registry);
    while (_k24 != undefined)
    {
        var _c24 = ds_map_find_value(global.cell_registry, _k24);
        if (is_struct(_c24) && variable_struct_exists(_c24, "physical") && is_struct(_c24.physical)
            && variable_struct_exists(_c24.physical, "required_class") && is_array(_c24.physical.required_class))
        {
            var _rq = _c24.physical.required_class;
            for (var _ri = 0; _ri < array_length(_rq); _ri++)
            {
                if (!ds_map_exists(global.class_registry, _rq[_ri]))
                    _bad24 += "cell" + string(_k24) + "->c" + string(_rq[_ri]) + " ";
            }
        }
        _k24 = ds_map_find_next(global.cell_registry, _k24);
    }
    // NOTE: birth_classes on CLASS = goblin class indices (0-3), NOT class_ids.
    // Only validate cell birth_classes (above). Skip class birth_classes here.
    if (_bad24 == "")
    {
        file_text_write_string(_log, "[GNX-TEST] PASS  T24 required_class resolve\n");
        _pass++;
    }
    else
    {
        file_text_write_string(_log, "[GNX-TEST] FAIL  T24 unresolved class refs: " + _bad24 + "\n");
        _fail++;
    }

    // T25: every bl_lookup value resolves to a real sprite (or -1)
    var _bad25 = 0;
    var _bk25 = ds_map_find_first(global.bl_lookup);
    while (_bk25 != undefined)
    {
        if (!scr_gnx_spr_ok(ds_map_find_value(global.bl_lookup, _bk25)))
            _bad25++;
        _bk25 = ds_map_find_next(global.bl_lookup, _bk25);
    }
    if (_bad25 == 0)
    {
        file_text_write_string(_log, "[GNX-TEST] PASS  T25 bl_lookup sprites valid (n=" + string(ds_map_size(global.bl_lookup)) + ")\n");
        _pass++;
    }
    else
    {
        file_text_write_string(_log, "[GNX-TEST] FAIL  T25 bl_lookup invalid entries: " + string(_bad25) + "\n");
        _fail++;
    }

    // T26: no duplicate h_type among gnx_registered_cells
    var _dup26 = "";
    if (is_array(global.gnx_registered_cells))
    {
        for (var _i = 0; _i < array_length(global.gnx_registered_cells); _i++)
        {
            var _ei = global.gnx_registered_cells[_i];
            var _hi = is_struct(_ei) ? _ei.h_type : _ei;
            for (var _j = _i + 1; _j < array_length(global.gnx_registered_cells); _j++)
            {
                var _ej = global.gnx_registered_cells[_j];
                var _hj = is_struct(_ej) ? _ej.h_type : _ej;
                if (_hi == _hj)
                    _dup26 += string(_hi) + " ";
            }
        }
    }
    if (_dup26 == "")
    {
        file_text_write_string(_log, "[GNX-TEST] PASS  T26 no duplicate registered h_type\n");
        _pass++;
    }
    else
    {
        file_text_write_string(_log, "[GNX-TEST] FAIL  T26 duplicate h_type: " + _dup26 + "\n");
        _fail++;
    }

    // T27: at least one GNX cell was hash-assigned (h_type >= 100)
    if (array_length(global.gnx_registered_cells) == 0)
    {
        file_text_write_string(_log, "[GNX-TEST] SKIP  T27 no mod cells loaded\n");
    }
    else
    {
        var _hash27 = false;
        for (var _ci = 0; _ci < array_length(global.gnx_registered_cells); _ci++)
        {
            var _e27 = global.gnx_registered_cells[_ci];
            var _h27 = is_struct(_e27) ? _e27.h_type : _e27;
            if (_h27 >= 100) { _hash27 = true; break; }
        }
        if (_hash27)
        {
            file_text_write_string(_log, "[GNX-TEST] PASS  T27 hash-assigned cell h_type>=100 found\n");
            _pass++;
        }
        else
        {
            file_text_write_string(_log, "[GNX-TEST] FAIL  T27 no hash-assigned cell found\n");
            _fail++;
        }
    }

    // T28: gnx_quest_events map exists and is valid
    if (ds_exists(global.gnx_quest_events, ds_type_map))
    {
        file_text_write_string(_log, "[GNX-TEST] PASS  T28 gnx_quest_events is valid ds_map (size=" + string(ds_map_size(global.gnx_quest_events)) + ")\n");
        _pass++;
    }
    else
    {
        file_text_write_string(_log, "[GNX-TEST] FAIL  T28 gnx_quest_events not a valid ds_map\n");
        _fail++;
    }

    // T29: gnx_quest_triggers array exists
    if (is_array(global.gnx_quest_triggers))
    {
        file_text_write_string(_log, "[GNX-TEST] PASS  T29 gnx_quest_triggers is array (len=" + string(array_length(global.gnx_quest_triggers)) + ")\n");
        _pass++;
    }
    else
    {
        file_text_write_string(_log, "[GNX-TEST] FAIL  T29 gnx_quest_triggers not an array\n");
        _fail++;
    }

    // T30: if mods loaded, quest events reference valid portraits
    if (ds_map_size(global.gnx_quest_events) > 0)
    {
        var _bad30 = "";
        var _key30 = ds_map_find_first(global.gnx_quest_events);
        while (_key30 != undefined)
        {
            var _ev30 = ds_map_find_value(global.gnx_quest_events, _key30);
            if (variable_struct_exists(_ev30, "dialog"))
            {
                for (var _d30 = 0; _d30 < array_length(_ev30.dialog); _d30++)
                {
                    var _line30 = _ev30.dialog[_d30];
                    if (_line30.portrait_spr != -1 && !sprite_exists(_line30.portrait_spr))
                        _bad30 += _key30 + ".dialog[" + string(_d30) + "] ";
                }
            }
            _key30 = ds_map_find_next(global.gnx_quest_events, _key30);
        }
        if (_bad30 == "")
        {
            file_text_write_string(_log, "[GNX-TEST] PASS  T30 all quest event portraits valid\n");
            _pass++;
        }
        else
        {
            file_text_write_string(_log, "[GNX-TEST] FAIL  T30 invalid portraits: " + _bad30 + "\n");
            _fail++;
        }
    }
    else
    {
        file_text_write_string(_log, "[GNX-TEST] SKIP  T30 no quest events loaded\n");
    }

    // T31: if mods loaded with quests, triggers have valid event_id refs
    if (array_length(global.gnx_quest_triggers) > 0)
    {
        var _bad31 = "";
        for (var _t31 = 0; _t31 < array_length(global.gnx_quest_triggers); _t31++)
        {
            var _trig = global.gnx_quest_triggers[_t31];
            var _eid = _trig.event;
            if (ds_map_find_value(global.gnx_quest_events, _eid) == undefined)
                _bad31 += _eid + " ";
        }
        if (_bad31 == "")
        {
            file_text_write_string(_log, "[GNX-TEST] PASS  T31 all triggers ref valid events (n=" + string(array_length(global.gnx_quest_triggers)) + ")\n");
            _pass++;
        }
        else
        {
            file_text_write_string(_log, "[GNX-TEST] FAIL  T31 triggers ref missing events: " + _bad31 + "\n");
            _fail++;
        }
    }
    else
    {
        file_text_write_string(_log, "[GNX-TEST] SKIP  T31 no triggers loaded\n");
    }

    // T32: gnx_popups map exists and is valid
    if (ds_exists(global.gnx_popups, ds_type_map))
    {
        file_text_write_string(_log, "[GNX-TEST] PASS  T32 gnx_popups is valid ds_map (size=" + string(ds_map_size(global.gnx_popups)) + ")\n");
        _pass++;
    }
    else
    {
        file_text_write_string(_log, "[GNX-TEST] FAIL  T32 gnx_popups not a valid ds_map\n");
        _fail++;
    }

    // T33: conditional encounter pool entries have mod_name set
    {
        var _bad33 = "";
        var _k33 = ds_map_find_first(global.gnx_encounter_pools);
        while (_k33 != undefined)
        {
            var _pool33 = ds_map_find_value(global.gnx_encounter_pools, _k33);
            for (var _p33 = 0; _p33 < ds_list_size(_pool33); _p33++)
            {
                var _e33 = ds_list_find_value(_pool33, _p33);
                if (variable_struct_exists(_e33, "condition") && !variable_struct_exists(_e33, "mod_name"))
                    _bad33 += "pool=" + string(_k33) + "[" + string(_p33) + "] ";
            }
            _k33 = ds_map_find_next(global.gnx_encounter_pools, _k33);
        }
        if (_bad33 == "")
        {
            file_text_write_string(_log, "[GNX-TEST] PASS  T33 all conditional pool entries have mod_name\n");
            _pass++;
        }
        else
        {
            file_text_write_string(_log, "[GNX-TEST] FAIL  T33 missing mod_name: " + _bad33 + "\n");
            _fail++;
        }
    }

    // T34: classes with post_raid have valid structure
    {
        var _bad34 = "";
        var _k34 = ds_map_find_first(global.class_registry);
        while (_k34 != undefined)
        {
            var _cr34 = ds_map_find_value(global.class_registry, _k34);
            if (variable_struct_exists(_cr34, "post_raid"))
            {
                var _pr34 = _cr34.post_raid;
                if (!variable_struct_exists(_pr34, "mod_name"))
                    _bad34 += "c" + string(_k34) + ".mod_name ";
                if (variable_struct_exists(_pr34, "cage_escape"))
                {
                    var _ce34 = _pr34.cage_escape;
                    if (!variable_struct_exists(_ce34, "over_diff_scale"))
                        _bad34 += "c" + string(_k34) + ".over_diff_scale ";
                }
            }
            _k34 = ds_map_find_next(global.class_registry, _k34);
        }
        if (_bad34 == "")
        {
            file_text_write_string(_log, "[GNX-TEST] PASS  T34 post_raid structures valid\n");
            _pass++;
        }
        else
        {
            file_text_write_string(_log, "[GNX-TEST] FAIL  T34 invalid post_raid: " + _bad34 + "\n");
            _fail++;
        }
    }

    // T35: birth_class values are valid goblin class indices (0-3)
    {
        var _bad35 = "";
        var _k35 = ds_map_find_first(global.class_registry);
        while (_k35 != undefined)
        {
            var _c35 = ds_map_find_value(global.class_registry, _k35);
            if (is_struct(_c35))
            {
                var _bc35 = -1;
                if (variable_struct_exists(_c35, "birth_class") && is_array(_c35.birth_class))
                    _bc35 = _c35.birth_class;
                else if (variable_struct_exists(_c35, "birth_classes") && is_array(_c35.birth_classes) && _k35 >= 14)
                    _bc35 = _c35.birth_classes;
                if (is_array(_bc35))
                {
                    if (array_length(_bc35) != 4)
                        _bad35 += "c" + string(_k35) + "(len=" + string(array_length(_bc35)) + ") ";
                    else
                    {
                        for (var _bi35 = 0; _bi35 < 4; _bi35++)
                        {
                            if (_bc35[_bi35] < 0 || _bc35[_bi35] > 3)
                                _bad35 += "c" + string(_k35) + "[" + string(_bi35) + "]=" + string(_bc35[_bi35]) + " ";
                        }
                    }
                }
            }
            _k35 = ds_map_find_next(global.class_registry, _k35);
        }
        if (_bad35 == "")
        {
            file_text_write_string(_log, "[GNX-TEST] PASS  T35 birth_class values valid (0-3)\n");
            _pass++;
        }
        else
        {
            file_text_write_string(_log, "[GNX-TEST] FAIL  T35 invalid birth_class: " + _bad35 + "\n");
            _fail++;
        }
    }
    // T36: gnx_tool_registry is a valid array
    if (is_array(global.gnx_tool_registry))
    {
        file_text_write_string(_log, "[GNX-TEST] PASS  T36 gnx_tool_registry is array (len=" + string(array_length(global.gnx_tool_registry)) + ")\n");
        _pass++;
    }
    else
    {
        file_text_write_string(_log, "[GNX-TEST] FAIL  T36 gnx_tool_registry is not an array\n");
        _fail++;
    }

    // T37: every tool button has non-empty actions array and all types are known
    {
        var _known_types = ["add_gold","add_food","add_milk","add_orbs","give_item","give_blueprint","give_prop",
                            "spawn_mon","set_troop_level","add_troop_exp","set_skill_level","set_troop_size",
                            "create_unit","create_unit_cage",
                            "unlock_boss","unlock_stage_next","unlock_breeds","unlock_cell","unlock_prop","unlock_raid","unlock_all_cells",
                            "add_floor","set_day","add_day_time",
                            "set_speed","swap_mouse","show_debug_overlay",
                            "set_val","set_var",
                            "reroll_shop","reroll_trade","reroll_encounters",
                            "set_state","set_continuous","fire_event","fire_trigger","popup","play_sfx"];
                            // [SHELVED 1.3.11] "travel_map","gml" removed
        var _bad37 = "";
        for (var _mi = 0; _mi < array_length(global.gnx_tool_registry); _mi++)
        {
            var _reg = global.gnx_tool_registry[_mi];
            for (var _ci = 0; _ci < array_length(_reg.categories); _ci++)
            {
                var _cat = _reg.categories[_ci];
                for (var _bi = 0; _bi < array_length(_cat.buttons); _bi++)
                {
                    var _btn = _cat.buttons[_bi];
                    var _acts = _btn.actions;
                    if (array_length(_acts) == 0 && _btn.toggle == "")
                        _bad37 += _reg.mod_name + "." + _cat.label + "." + _btn.label + "(no_actions) ";
                    for (var _ai = 0; _ai < array_length(_acts); _ai++)
                    {
                        var _at = _acts[_ai].type;
                        var _found = false;
                        for (var _ki = 0; _ki < array_length(_known_types); _ki++)
                        {
                            if (_known_types[_ki] == _at) { _found = true; break; }
                        }
                        if (!_found)
                            _bad37 += _reg.mod_name + "." + _btn.label + "(" + _at + ") ";
                    }
                }
            }
        }
        if (_bad37 == "")
        {
            file_text_write_string(_log, "[GNX-TEST] PASS  T37 all tool button action types valid\n");
            _pass++;
        }
        else
        {
            file_text_write_string(_log, "[GNX-TEST] FAIL  T37 invalid tool actions: " + _bad37 + "\n");
            _fail++;
        }
    }

    // T38: every keybind has valid vk_code or valid key_type=range
    {
        var _bad38 = "";
        for (var _ki = 0; _ki < array_length(global.gnx_keybinds); _ki++)
        {
            var _kb = global.gnx_keybinds[_ki];
            if (_kb.key_type == "range")
            {
                if (_kb.key_start > _kb.key_end)
                    _bad38 += _kb.mod_name + "(bad_range) ";
            }
            else
            {
                if (_kb.vk_code == -1)
                    _bad38 += _kb.mod_name + "(no_vk_code) ";
            }
        }
        if (_bad38 == "")
        {
            file_text_write_string(_log, "[GNX-TEST] PASS  T38 all keybinds valid (count=" + string(array_length(global.gnx_keybinds)) + ")\n");
            _pass++;
        }
        else
        {
            file_text_write_string(_log, "[GNX-TEST] FAIL  T38 invalid keybinds: " + _bad38 + "\n");
            _fail++;
        }
    }

    // T39: every toggle button references a key that exists in mod save_state
    {
        var _bad39 = "";
        for (var _mi = 0; _mi < array_length(global.gnx_tool_registry); _mi++)
        {
            var _reg = global.gnx_tool_registry[_mi];
            for (var _ci = 0; _ci < array_length(_reg.categories); _ci++)
            {
                var _cat = _reg.categories[_ci];
                for (var _bi = 0; _bi < array_length(_cat.buttons); _bi++)
                {
                    var _btn = _cat.buttons[_bi];
                    if (_btn.toggle != "")
                    {
                        // Check if the mod has save_state initialized for this key
                        if (variable_global_exists("gnx_mod_state") && variable_struct_exists(global.gnx_mod_state, _reg.mod_name))
                        {
                            var _ms = variable_struct_get(global.gnx_mod_state, _reg.mod_name);
                            if (!variable_struct_exists(_ms, _btn.toggle))
                                _bad39 += _reg.mod_name + "." + _btn.label + "(" + _btn.toggle + ") ";
                        }
                    }
                }
            }
        }
        if (_bad39 == "")
        {
            file_text_write_string(_log, "[GNX-TEST] PASS  T39 all toggle keys exist in save_state\n");
            _pass++;
        }
        else
        {
            file_text_write_string(_log, "[GNX-TEST] FAIL  T39 missing toggle keys: " + _bad39 + "\n");
            _fail++;
        }
    }

    // T40: every class naked layer table resolves to real sprites
    var _bad40 = "";
    var _k40 = ds_map_find_first(global.class_registry);
    while (_k40 != undefined)
    {
        var _cl40 = ds_map_find_value(global.class_registry, _k40);
        if (is_struct(_cl40))
        {
            var _ntabs40 = ["naked_standard", "naked_big", "naked_tent"];
            for (var _t40 = 0; _t40 < 3; _t40++)
            {
                if (variable_struct_exists(_cl40, _ntabs40[_t40]))
                    _bad40 += scr_gnx_collect_bad_spr(variable_struct_get(_cl40, _ntabs40[_t40]), "c" + string(_k40) + "." + _ntabs40[_t40]);
            }
            if (variable_struct_exists(_cl40, "carry_base_spr"))
            {
                var _cbs40 = _cl40.carry_base_spr;
                if (is_struct(_cbs40))
                    _bad40 += scr_gnx_collect_bad_spr(_cbs40, "c" + string(_k40) + ".carry_base_spr");
                else if (is_real(_cbs40) && _cbs40 != -1 && !sprite_exists(_cbs40))
                    _bad40 += "c" + string(_k40) + ".carry_base_spr ";
            }
        }
        _k40 = ds_map_find_next(global.class_registry, _k40);
    }
    if (_bad40 == "")
    {
        file_text_write_string(_log, "[GNX-TEST] PASS  T40 naked layer sprites valid\n");
        _pass++;
    }
    else
    {
        file_text_write_string(_log, "[GNX-TEST] FAIL  T40 naked layer bad sprites: " + _bad40 + "\n");
        _fail++;
    }

    // T41: gnx_voice_banks is valid, every entry is non-empty array of valid sounds
    if (!global.gnx_has_sounds)
    {
        file_text_write_string(_log, "[GNX-TEST] SKIP  T41 no sound mods loaded\n");
    }
    else
    {
        var _bad41 = "";
        var _bk41 = ds_map_find_first(global.gnx_voice_banks);
        while (_bk41 != undefined)
        {
            var _arr41 = ds_map_find_value(global.gnx_voice_banks, _bk41);
            if (!is_array(_arr41) || array_length(_arr41) == 0)
                _bad41 += _bk41 + "(empty) ";
            else
            {
                for (var _s41 = 0; _s41 < array_length(_arr41); _s41++)
                    if (!audio_exists(_arr41[_s41]))
                        _bad41 += _bk41 + "[" + string(_s41) + "] ";
            }
            _bk41 = ds_map_find_next(global.gnx_voice_banks, _bk41);
        }
        if (_bad41 == "")
        {
            file_text_write_string(_log, "[GNX-TEST] PASS  T41 voice banks valid (count=" + string(array_length(global.gnx_voice_bank_names)) + ")\n");
            _pass++;
        }
        else
        {
            file_text_write_string(_log, "[GNX-TEST] FAIL  T41 bad voice banks: " + _bad41 + "\n");
            _fail++;
        }
    }

    // T42: SFX pools contain valid sound_ids (or are empty)
    if (!global.gnx_has_sounds)
    {
        file_text_write_string(_log, "[GNX-TEST] SKIP  T42 no sound mods loaded\n");
    }
    else
    {
        var _bad42 = "";
        var _pools42 = [global.gnx_sfx_orgasm, global.gnx_sfx_bj_slurp, global.gnx_sfx_bj_gag, global.gnx_sfx_bj_moan, global.gnx_sfx_bj_breathe];
        var _pnames42 = ["orgasm", "bj_slurp", "bj_gag", "bj_moan", "bj_breathe"];
        for (var _p42 = 0; _p42 < 5; _p42++)
        {
            var _pa = _pools42[_p42];
            for (var _s42 = 0; _s42 < array_length(_pa); _s42++)
                if (!audio_exists(_pa[_s42]))
                    _bad42 += _pnames42[_p42] + "[" + string(_s42) + "] ";
        }
        if (_bad42 == "")
        {
            file_text_write_string(_log, "[GNX-TEST] PASS  T42 SFX pools valid\n");
            _pass++;
        }
        else
        {
            file_text_write_string(_log, "[GNX-TEST] FAIL  T42 bad SFX entries: " + _bad42 + "\n");
            _fail++;
        }
    }

    // T43: every class with voice_bank references an existing bank
    if (!global.gnx_has_sounds)
    {
        file_text_write_string(_log, "[GNX-TEST] SKIP  T43 no sound mods loaded\n");
    }
    else
    {
        var _bad43 = "";
        var _k43 = ds_map_find_first(global.class_registry);
        while (_k43 != undefined)
        {
            var _cl43 = ds_map_find_value(global.class_registry, _k43);
            if (is_struct(_cl43) && variable_struct_exists(_cl43, "voice_bank") && _cl43.voice_bank != -1)
            {
                if (!ds_map_exists(global.gnx_voice_banks, _cl43.voice_bank))
                    _bad43 += "c" + string(_k43) + "=" + string(_cl43.voice_bank) + " ";
            }
            _k43 = ds_map_find_next(global.class_registry, _k43);
        }
        if (_bad43 == "")
        {
            file_text_write_string(_log, "[GNX-TEST] PASS  T43 class voice bank refs valid\n");
            _pass++;
        }
        else
        {
            file_text_write_string(_log, "[GNX-TEST] FAIL  T43 bad voice bank refs: " + _bad43 + "\n");
            _fail++;
        }
    }

    // T44: every mon_spr_overrides value resolves to a real sprite
    var _bad44 = "";
    var _mso_keys = ds_map_find_first(global.class_registry);
    while (_mso_keys != undefined)
    {
        var _rc44 = ds_map_find_value(global.class_registry, _mso_keys);
        if (variable_struct_exists(_rc44, "mon_spr_overrides"))
        {
            var _mso = _rc44.mon_spr_overrides;
            var _knames = variable_struct_get_names(_mso);
            for (var _ki = 0; _ki < array_length(_knames); _ki++)
            {
                var _sv = variable_struct_get(_mso, _knames[_ki]);
                if (_sv != undefined && _sv != -1 && !sprite_exists(_sv))
                    _bad44 += "c" + string(_mso_keys) + "." + _knames[_ki] + " ";
            }
        }
        _mso_keys = ds_map_find_next(global.class_registry, _mso_keys);
    }

    if (_bad44 == "")
    {
        file_text_write_string(_log, "[GNX-TEST] PASS  T44 mon_spr_overrides sprites valid\n");
        _pass++;
    }
    else
    {
        file_text_write_string(_log, "[GNX-TEST] FAIL  T44 bad mon_spr_overrides: " + _bad44 + "\n");
        _fail++;
    }

    // T45: class_map cells have valid sprites in default + per-class entries
    var _bad45 = "";
    var _k45 = ds_map_find_first(global.cell_registry);
    while (_k45 != undefined)
    {
        var _c45 = ds_map_find_value(global.cell_registry, _k45);
        if (is_struct(_c45) && variable_struct_exists(_c45, "human_spr") && is_struct(_c45.human_spr)
            && variable_struct_exists(_c45.human_spr, "mode") && _c45.human_spr.mode == "class_map")
        {
            var _prefix45 = string(_k45);
            var _phases45 = ["phase_0", "phase_1", "phase_2", "phase_4"];
            // Check default entry
            if (variable_struct_exists(_c45.human_spr, "default"))
            {
                var _def45 = variable_struct_get(_c45.human_spr, "default");
                for (var _pi45 = 0; _pi45 < 4; _pi45++)
                {
                    if (variable_struct_exists(_def45, _phases45[_pi45]))
                        _bad45 += scr_gnx_collect_bad_spr(variable_struct_get(_def45, _phases45[_pi45]), _prefix45 + ".default." + _phases45[_pi45]);
                }
            }
            // Check per-class entries
            if (variable_struct_exists(_c45.human_spr, "classes"))
            {
                var _cls45 = _c45.human_spr.classes;
                var _ckeys45 = variable_struct_get_names(_cls45);
                var _cki45 = 0;
                repeat (array_length(_ckeys45))
                {
                    var _ck45 = _ckeys45[_cki45++];
                    var _ce45 = variable_struct_get(_cls45, _ck45);
                    for (var _pi45b = 0; _pi45b < 4; _pi45b++)
                    {
                        if (variable_struct_exists(_ce45, _phases45[_pi45b]))
                            _bad45 += scr_gnx_collect_bad_spr(variable_struct_get(_ce45, _phases45[_pi45b]), _prefix45 + ".c" + _ck45 + "." + _phases45[_pi45b]);
                    }
                }
            }
        }
        _k45 = ds_map_find_next(global.cell_registry, _k45);
    }
    if (_bad45 == "")
    {
        file_text_write_string(_log, "[GNX-TEST] PASS  T45 class_map cell sprites valid\n");
        _pass++;
    }
    else
    {
        file_text_write_string(_log, "[GNX-TEST] FAIL  T45 class_map bad sprites: " + _bad45 + "\n");
        _fail++;
    }
    // T58: removed (spr_slot_template lives in physical sub-struct, test checked wrong path)

    // [SHELVED 1.3.11] T46-T53: GMLC tests removed (GMLC not shipped)

    // T54-T57: multi-map tests (only when multi-map enabled)
    if (global.gnx_multimap_enabled)
    {
        // T54: multi-map globals have correct types
        {
            var _ok54 = is_string(global.gnx_active_map)
                     && is_struct(global.gnx_inactive_maps)
                     && is_struct(global.gnx_mod_map_decl)
                     && (global.gnx_travel_data == -1);
            if (_ok54) { file_text_write_string(_log, "[GNX-TEST] PASS  T54 multi-map globals\n"); _pass++; }
            else       { file_text_write_string(_log, "[GNX-TEST] FAIL  T54 multi-map globals (active_map=" + string(global.gnx_active_map) + " travel_data=" + string(global.gnx_travel_data) + ")\n"); _fail++; }
        }

        // T55: every loaded mod has a map declaration
        {
            var _bad55 = "";
            for (var _mi55 = 0; _mi55 < array_length(global.gnx_loaded_mods); _mi55++)
            {
                var _mn55 = global.gnx_loaded_mods[_mi55];
                if (!variable_struct_exists(global.gnx_mod_map_decl, _mn55))
                    _bad55 += _mn55 + " ";
            }
            if (_bad55 == "") { file_text_write_string(_log, "[GNX-TEST] PASS  T55 all loaded mods have map decl\n"); _pass++; }
            else              { file_text_write_string(_log, "[GNX-TEST] FAIL  T55 mods missing map decl: " + _bad55 + "\n"); _fail++; }
        }

        // T56: no orphaned inactive map snapshots (all keys are valid map names)
        {
            var _valid56 = {};
            variable_struct_set(_valid56, "vanilla", true);
            var _dk56 = variable_struct_get_names(global.gnx_mod_map_decl);
            for (var _di56 = 0; _di56 < array_length(_dk56); _di56++)
            {
                var _mv56 = variable_struct_get(global.gnx_mod_map_decl, _dk56[_di56]);
                if (_mv56 != "all")
                    variable_struct_set(_valid56, _mv56, true);
            }
            var _bad56 = "";
            var _ik56 = variable_struct_get_names(global.gnx_inactive_maps);
            for (var _ii56 = 0; _ii56 < array_length(_ik56); _ii56++)
            {
                if (!variable_struct_exists(_valid56, _ik56[_ii56]))
                    _bad56 += _ik56[_ii56] + " ";
            }
            if (!variable_struct_exists(_valid56, global.gnx_active_map) && global.gnx_active_map != "vanilla")
                _bad56 += "active:" + global.gnx_active_map + " ";
            if (_bad56 == "") { file_text_write_string(_log, "[GNX-TEST] PASS  T56 no orphaned maps\n"); _pass++; }
            else              { file_text_write_string(_log, "[GNX-TEST] FAIL  T56 orphaned maps: " + _bad56 + "\n"); _fail++; }
        }

        // T57: travel locations array is valid, each entry has required fields
        {
            var _ok57 = is_array(global.gnx_travel_locations);
            var _bad57 = "";
            if (_ok57)
            {
                for (var _i57 = 0; _i57 < array_length(global.gnx_travel_locations); _i57++)
                {
                    var _tl57 = global.gnx_travel_locations[_i57];
                    if (!is_struct(_tl57) || !variable_struct_exists(_tl57, "target") || !variable_struct_exists(_tl57, "show_on") || !variable_struct_exists(_tl57, "x") || !variable_struct_exists(_tl57, "y"))
                        _bad57 += string(_i57) + " ";
                }
            }
            if (_ok57 && _bad57 == "") { file_text_write_string(_log, "[GNX-TEST] PASS  T57 travel locations valid (n=" + string(array_length(global.gnx_travel_locations)) + ")\n"); _pass++; }
            else                      { file_text_write_string(_log, "[GNX-TEST] FAIL  T57 travel locations: " + _bad57 + "\n"); _fail++; }
        }
    }
    else
    {
        file_text_write_string(_log, "[GNX-TEST] SKIP  T54-T57 multi-map disabled\n");
    }

    var _total = _pass + _fail;
    file_text_write_string(_log, "[GNX-TEST] " + string(_pass) + "/" + string(_total) + " passed");

    if (_fail > 0)
        file_text_write_string(_log, "  *** " + string(_fail) + " FAILED ***");

    file_text_write_string(_log, "\n");
    file_text_write_string(_log, "[GNX-TEST] ============================================================\n");
    file_text_close(_log);
}

function scr_gnx_dump_coverage()
{
    var _log = file_text_open_append(GNX_LOG);
    file_text_write_string(_log, "[GNX-COV] --- coverage dump (tick 500) ---\n");
    var _n = ds_map_size(global.gnx_cov);
    var _k = ds_map_find_first(global.gnx_cov);
    for (var _i = 0; _i < _n; _i++)
    {
        file_text_write_string(_log, "[GNX-COV] " + string(_k) + " = " + string(ds_map_find_value(global.gnx_cov, _k)) + "\n");
        _k = ds_map_find_next(global.gnx_cov, _k);
    }
    file_text_write_string(_log, "[GNX-COV] --- end (" + string(_n) + " keys) ---\n");
    file_text_close(_log);
}

function gnx_cov_hit(arg0)
{
    if (ds_map_exists(global.gnx_cov, arg0))
        ds_map_replace(global.gnx_cov, arg0, ds_map_find_value(global.gnx_cov, arg0) + 1);
    else
        ds_map_add(global.gnx_cov, arg0, 1);
    
    global.gnx_cov_tick++;
    
    if (global.gnx_cov_tick >= 500)
    {
        global.gnx_cov_tick = 0;
        scr_gnx_dump_coverage();
    }
}

function gnx_first_hit(arg0, arg1, arg2, arg3)
{
    var _k = string(arg0) + "." + arg1 + "." + arg2 + "." + string(arg3);
    var _kb = string(arg0) + "." + arg1 + "." + arg2;
    
    if (!ds_map_exists(global.gnx_seen, _k))
    {
        ds_map_add(global.gnx_seen, _k, 1);
        if (global.gnx_debug_verbose)
        {
            var _f = file_text_open_append(GNX_LOG);
            file_text_write_string(_f, "[GNX-CELL] FIRST cell=" + string(arg0) + " t=" + arg1 + " ph=" + arg2 + " cls=" + string(arg3) + "\n");
            file_text_close(_f);
        }
    }
    
    if (!ds_map_exists(global.gnx_seen_base, _kb))
        ds_map_add(global.gnx_seen_base, _kb, 1);
}

function scr_gnx_build_expected()
{
    var _phases = ["s", "lo", "ej"];
    var _k = ds_map_find_first(global.cell_registry);
    
    while (_k != undefined)
    {
        var _cell = ds_map_find_value(global.cell_registry, _k);
        var _cn = string(_k);
        
        if (variable_struct_exists(_cell, "mon_spr") && _cell.mon_spr != undefined)
        {
            for (var _i = 0; _i < 3; _i++)
                ds_list_add(global.gnx_expected, _cn + ".g." + _phases[_i]);
            
            for (var _i = 0; _i < 3; _i++)
                ds_list_add(global.gnx_expected, _cn + ".h." + _phases[_i]);
            
            for (var _i = 0; _i < 3; _i++)
                ds_list_add(global.gnx_expected, _cn + ".o." + _phases[_i]);
        }
        
        _k = ds_map_find_next(global.cell_registry, _k);
    }
    
    var _f = file_text_open_append(GNX_LOG);
    file_text_write_string(_f, "[GNX-CELL] expected set built: " + string(ds_list_size(global.gnx_expected)) + " base combos\n");
    file_text_close(_f);
}

function scr_gnx_dump_cell_coverage()
{
    var _log = file_text_open_append(GNX_LOG);
    file_text_write_string(_log, "[GNX-CELL] ---- cell coverage dump ----\n");
    var _seen_n = ds_map_size(global.gnx_seen);
    file_text_write_string(_log, "[GNX-CELL] SEEN " + string(_seen_n) + " combos (cell.t.ph.cls)\n");
    var _sk = ds_map_find_first(global.gnx_seen);
    
    while (_sk != undefined)
    {
        file_text_write_string(_log, "[GNX-CELL] SEEN " + string(_sk) + "\n");
        _sk = ds_map_find_next(global.gnx_seen, _sk);
    }
    
    var _miss_n = 0;
    var _exp_n = ds_list_size(global.gnx_expected);
    
    for (var _i = 0; _i < _exp_n; _i++)
    {
        var _ek = ds_list_find_value(global.gnx_expected, _i);
        
        if (!ds_map_exists(global.gnx_seen_base, _ek))
        {
            file_text_write_string(_log, "[GNX-CELL] MISS " + _ek + "\n");
            _miss_n++;
        }
    }
    
    file_text_write_string(_log, "[GNX-CELL] MISSING " + string(_miss_n) + "/" + string(_exp_n) + " base combos\n");
    file_text_write_string(_log, "[GNX-CELL] ---- end ----\n");
    file_text_close(_log);
}

function scr_gnx_test_dispatch_routing()
{
    // Pre-validates registry data for all cell×class combos.
    // Does NOT call the dispatcher (needs object context). Simulates routing logic inline.
    // Giant (class 11) skipped for big/tent cells — it only uses GIANT cell (base_body=standard).
    var _log = file_text_open_append(GNX_LOG);
    file_text_write_string(_log, "[GNX-TEST] === DISPATCH ROUTING CHECK ===\n");
    var _pass = 0;
    var _fail = 0;
    var _skip = 0;
    var _cells  = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,17,18,19,20,21,22,23,24,25,27,28,29,30,31,32,33,34,36,37,38,39,40,41,42];
    // Include mod cells from gnx_registered_cells
    for (var _rci = 0; _rci < array_length(global.gnx_registered_cells); _rci++)
        array_push(_cells, global.gnx_registered_cells[_rci].h_type);
    // Build class list dynamically from class_registry (vanilla + any mod classes),
    // instead of a hardcoded list that assumes a specific test class is loaded.
    var _classes = [];
    var _ck = ds_map_find_first(global.class_registry);

    while (_ck != undefined)
    {
        array_push(_classes, _ck);
        _ck = ds_map_find_next(global.class_registry, _ck);
    }

    var _ci = 0;
    repeat (array_length(_cells))
    {
        var _h = _cells[_ci++];
        var _rcell = ds_map_find_value(global.cell_registry, _h);
        if (_rcell == undefined || !variable_struct_exists(_rcell, "human_spr") || _rcell.human_spr == undefined)
        {
            file_text_write_string(_log, "[GNX-TEST] SKIP  DROUTE h=" + string(_h) + " NO_HUMAN_SPR\n");
            _skip++;
            continue;
        }
        var _rule = _rcell.human_spr;
        if (variable_struct_exists(_rule, "mode") && _rule.mode == "fixed")
        {
            if (variable_struct_exists(_rule, "phase_1") && variable_struct_exists(_rule, "phase_2"))
                _pass++;
            else
            {
                file_text_write_string(_log, "[GNX-TEST] FAIL  DROUTE h=" + string(_h) + " FIXED_MISSING_PHASE\n");
                _fail++;
            }
            continue;
        }
        if (variable_struct_exists(_rule, "mode") && _rule.mode == "class_map")
        {
            var _has_default = variable_struct_exists(_rule, "default");
            var _has_classes = variable_struct_exists(_rule, "classes");
            var _clsi_cm = 0;
            repeat (array_length(_classes))
            {
                var _c_cm = _classes[_clsi_cm++];
                var _cm_ok = _has_default;
                if (!_cm_ok && _has_classes)
                    _cm_ok = (variable_struct_get(_rule.classes, string(_c_cm)) != undefined);
                if (_cm_ok)
                    _pass++;
                else
                {
                    file_text_write_string(_log, "[GNX-TEST] FAIL  DROUTE h=" + string(_h) + " c=" + string(_c_cm) + " CLASS_MAP_NO_MATCH\n");
                    _fail++;
                }
            }
            continue;
        }
        var _bb = variable_struct_exists(_rule, "base_body") ? _rule.base_body : "";
        var _clsi = 0;
        repeat (array_length(_classes))
        {
            var _c = _classes[_clsi++];
            if (_c == 11 && _bb != "standard") { file_text_write_string(_log, "[GNX-TEST] SKIP  DROUTE h=" + string(_h) + " c=11 Giant/" + _bb + "\n"); _skip++; continue; }
            var _rclass = ds_map_find_value(global.class_registry, _c);
            if (_rclass == undefined)
            {
                file_text_write_string(_log, "[GNX-TEST] FAIL  DROUTE h=" + string(_h) + " c=" + string(_c) + " NO_CLASS\n");
                _fail++;
                continue;
            }
            var _ok = false;
            if (_bb == "standard")
                _ok = variable_struct_exists(_rclass, "clothing_standard")
                   && variable_struct_exists(_rclass.clothing_standard, "phase_1")
                   && variable_struct_exists(_rclass.clothing_standard, "phase_2");
            else if (_bb == "big")
            {
                if (_rclass.is_special)
                    _ok = variable_struct_exists(_rclass, "clothing_big")
                       && variable_struct_exists(_rclass.clothing_big, "phase_1");
                else
                    _ok = variable_struct_exists(_rclass, "clothing_big")
                       && variable_struct_exists(_rclass.clothing_big, "idle")
                       && variable_struct_exists(_rclass.clothing_big, "loop");
            }
            else if (_bb == "tent")
            {
                if (_rclass.is_special)
                    _ok = variable_struct_exists(_rclass, "clothing_tent")
                       && variable_struct_exists(_rclass.clothing_tent, "phase_1");
                else
                    _ok = variable_struct_exists(_rclass, "clothing_tent")
                       && variable_struct_exists(_rclass.clothing_tent, "phase_1")
                       && variable_struct_exists(_rclass.clothing_tent, "phase_2");
            }
            if (_ok)
                _pass++;
            else
            {
                file_text_write_string(_log, "[GNX-TEST] FAIL  DROUTE h=" + string(_h) + " c=" + string(_c) + " bb=" + _bb + "\n");
                _fail++;
            }
        }
    }
    file_text_write_string(_log, "[GNX-TEST] DROUTE: " + string(_pass) + " PASS " + string(_fail) + " FAIL " + string(_skip) + " SKIP\n");
    file_text_write_string(_log, "[GNX-TEST] ============================================================\n");
    file_text_close(_log);
}

// ============================================================
// GNX TOOL SYSTEM
// ============================================================

/// @desc Load tools.json for a mod. Called from scr_gnx_load_mod.
/// @arg {string} arg0  mod_folder name
/// @arg {string} arg1  tools filename from manifest
function scr_gnx_load_tools(arg0, arg1)
{
    var _path = global.gnx_mods_root + arg0 + "/" + arg1;
    if (!file_exists(_path))
    {
        gnx_report_mod_error("Mod '" + arg0 + "': " + arg1 + " not found");
        exit;
    }

    var _f = file_text_open_read(_path);
    var _raw = "";
    while (!file_text_eof(_f))
        _raw += file_text_readln(_f);
    file_text_close(_f);

    var _data = undefined;
    try { _data = json_parse(_raw); }
    catch (_e)
    {
        gnx_report_mod_error("Mod '" + arg0 + "': " + arg1 + " invalid (" + string(_e.message) + ")");
        exit;
    }

    var _log = file_text_open_append(GNX_LOG);
    file_text_write_string(_log, "[GNX-TOOL] loading tools for " + arg0 + "\n");

    var _entry = { mod_name: arg0, categories: [] };

    // Parse categories
    if (variable_struct_exists(_data, "categories"))
    {
        var _cats = _data.categories;
        for (var _ci = 0; _ci < array_length(_cats); _ci++)
        {
            var _cat = _cats[_ci];
            var _parsed_cat = { label: _cat.label, buttons: [] };

            if (variable_struct_exists(_cat, "buttons"))
            {
                var _btns = _cat.buttons;
                for (var _bi = 0; _bi < array_length(_btns); _bi++)
                {
                    var _btn = _btns[_bi];
                    var _parsed_btn = {
                        label: _btn.label,
                        actions: variable_struct_exists(_btn, "actions") ? _btn.actions : [],
                        popup: variable_struct_exists(_btn, "popup") ? _btn.popup : "",
                        toggle: variable_struct_exists(_btn, "toggle") ? _btn.toggle : "",
                        undo_actions: variable_struct_exists(_btn, "undo_actions") ? _btn.undo_actions : [],
                        undo_popup: variable_struct_exists(_btn, "undo_popup") ? _btn.undo_popup : "",
                        guard: variable_struct_exists(_btn, "guard") ? _btn.guard : -1,
                        guard_fail_popup: variable_struct_exists(_btn, "guard_fail_popup") ? _btn.guard_fail_popup : ""
                    };
                    array_push(_parsed_cat.buttons, _parsed_btn);
                }
            }

            array_push(_entry.categories, _parsed_cat);
        }
    }

    // Parse keybinds
    if (variable_struct_exists(_data, "keybinds"))
    {
        var _kbs = _data.keybinds;
        for (var _ki = 0; _ki < array_length(_kbs); _ki++)
        {
            var _kb = _kbs[_ki];
            var _parsed_kb = {
                mod_name: arg0,
                modifier: variable_struct_exists(_kb, "modifier") ? _kb.modifier : "none",
                popup: variable_struct_exists(_kb, "popup") ? _kb.popup : "",
                popup_template: variable_struct_exists(_kb, "popup_template") ? _kb.popup_template : "",
                key_type: "single",
                vk_code: -1,
                key_start: 0,
                key_end: 0,
                actions: variable_struct_exists(_kb, "actions") ? _kb.actions : [],
                action_per_key: variable_struct_exists(_kb, "action_per_key") ? _kb.action_per_key : -1
            };

            var _key = _kb.key;
            if (_key == "0-9")
            {
                _parsed_kb.key_type = "range";
                _parsed_kb.key_start = 0;
                _parsed_kb.key_end = 9;
            }
            else if (string_length(_key) == 1 && ord(_key) >= ord("A") && ord(_key) <= ord("Z"))
                _parsed_kb.vk_code = ord(_key);
            else if (string_length(_key) == 1 && ord(_key) >= ord("0") && ord(_key) <= ord("9"))
                _parsed_kb.vk_code = ord(_key);
            else if (string_copy(_key, 1, 1) == "F" && string_length(_key) >= 2)
            {
                var _fnum = real(string_copy(_key, 2, string_length(_key) - 1));
                if (_fnum >= 1 && _fnum <= 12)
                    _parsed_kb.vk_code = vk_f1 + _fnum - 1;
            }
            else if (_key == "space") _parsed_kb.vk_code = vk_space;
            else if (_key == "tab") _parsed_kb.vk_code = vk_tab;
            else if (_key == "escape") _parsed_kb.vk_code = vk_escape;

            array_push(global.gnx_keybinds, _parsed_kb);
        }
    }

    file_text_write_string(_log, "[GNX-TOOL] " + arg0 + ": " + string(array_length(_entry.categories)) + " categories, " + string(array_length(global.gnx_keybinds)) + " total keybinds\n");
    file_text_close(_log);

    array_push(global.gnx_tool_registry, _entry);
}

/// @desc Execute a tool action. Central dispatcher for all 38 action types.
/// @arg {struct} arg0  action struct from tools.json
/// @arg {string} arg1  mod_name
function scr_gnx_exec_tool_action(arg0, arg1)
{
    var _type = arg0.type;

    switch (_type)
    {
        // === A. Resources ===
        case "add_gold":
            global.val.money = max(0, global.val.money + arg0.amount);
            break;

        case "add_food":
            global.val.food = max(0, global.val.food + arg0.amount);
            break;

        case "add_milk":
        {
            var _rarity = variable_struct_exists(arg0, "rarity") ? arg0.rarity : -1;
            var _amt = variable_struct_exists(arg0, "amount") ? arg0.amount : 1;
            if (_rarity == -1)
            {
                for (var _r = 0; _r <= 4; _r++)
                    scr_add_milk_item(_r, _amt);
            }
            else
                scr_add_milk_item(_rarity, _amt);
            break;
        }

        case "add_orbs":
            global.val.orb_num = max(0, global.val.orb_num + arg0.amount);
            break;

        case "give_item":
            scr_set_item_data(arg0.item_type, arg0.data, arg0.level);
            scr_add_item();
            break;

        case "give_blueprint":
        {
            var _ht = arg0.h_type;
            var _frag = variable_struct_exists(arg0, "fragment") ? arg0.fragment : false;
            var _lvl = _frag ? (variable_struct_exists(arg0, "lvl") ? arg0.lvl : 1) : 3;
            scr_set_item_data(5, _ht, _lvl);
            scr_add_item();
            break;
        }

        case "give_prop":
            scr_add_new_prop_type(arg0.prop_id, true);
            break;

        // === B. Monsters / Troops ===
        case "spawn_mon":
        {
            var _sp = arg0.species;
            var _amt = arg0.amount;
            var _sp_struct;
            switch (_sp)
            {
                case 0: _sp_struct = global.val.goblin; break;
                case 1: _sp_struct = global.val.hobgoblin; break;
                case 2: _sp_struct = global.val.tentacle; break;
                case 3: _sp_struct = global.val.ogre; break;
                default: exit;
            }
            for (var _gc = 0; _gc < 4; _gc++)
            {
                if (_sp_struct.num[_gc] == -1)
                {
                    scr_mon_num_edit(_sp, _gc, 1, true);
                    if (_amt > 1)
                        scr_mon_num_edit(_sp, _gc, _amt - 1, true);
                }
                else
                    scr_mon_num_edit(_sp, _gc, _amt, true);
            }
            break;
        }

        case "set_troop_level":
        {
            var _sp_struct;
            switch (arg0.species)
            {
                case 0: _sp_struct = global.val.goblin; break;
                case 1: _sp_struct = global.val.hobgoblin; break;
                case 2: _sp_struct = global.val.tentacle; break;
                case 3: _sp_struct = global.val.ogre; break;
                default: exit;
            }
            _sp_struct.lvl[arg0.class] = arg0.value;
            break;
        }

        case "add_troop_exp":
            scr_mon_exp_edit(arg0.species, arg0.class, arg0.amount);
            break;

        case "set_skill_level":
        {
            var _sp_struct;
            switch (arg0.species)
            {
                case 0: _sp_struct = global.val.goblin; break;
                case 1: _sp_struct = global.val.hobgoblin; break;
                case 2: _sp_struct = global.val.tentacle; break;
                case 3: _sp_struct = global.val.ogre; break;
                default: exit;
            }
            _sp_struct.skill_lvl[arg0.class] = arg0.value;
            break;
        }

        case "set_troop_size":
            global.val.troop_size = clamp(arg0.value, 0, 7);
            break;

        // === C. Human Units ===
        case "create_unit":
        {
            var _cls = arg0.class_id;
            var _lvl = variable_struct_exists(arg0, "level") ? arg0.level : 1;
            var _unit = scr_create_unit_base(_cls, _lvl);
            for (var _ui = 0; _ui < ds_list_size(global.unit_list); _ui++)
            {
                if (ds_list_find_value(global.unit_list, _ui) == -1)
                {
                    ds_list_set(global.unit_list, _ui, _unit);
                    break;
                }
            }
            break;
        }

        case "create_unit_cage":
        {
            var _cls = arg0.class_id;
            var _lvl = variable_struct_exists(arg0, "level") ? arg0.level : 1;
            var _unit = scr_create_unit_base(_cls, _lvl);
            array_push(global.val.cage, _unit);
            break;
        }

        // === D. Unlocks ===
        case "unlock_boss":
        {
            var _idx = arg0.index;
            if (_idx >= 0 && _idx <= 4 && global.unlock.boss[_idx] == -1)
                scr_add_event(31 + _idx, false);
            break;
        }

        case "unlock_stage_next":
        {
            var _stage = arg0.stage;
            if (_stage < 0 || _stage > 3) break;
            if (global.val.stage_info[_stage] == -1)
            {
                scr_set_stage_data(_stage, 0, false);
                if (_stage == 1) scr_add_event(23, false);
                else if (_stage == 2) scr_add_event(24, false);
                else if (_stage == 3) scr_add_event(25, false);
            }
            else
            {
                var _si = global.val.stage_info[_stage];
                _si.max_lvl++;
                global.val.stage_lvl_sel[_stage] = min(global.val.stage_lvl_sel[_stage] + 1, 2);
                scr_set_stage_data(_stage, _si.max_lvl, false);
            }
            scr_check_quest_raid();
            break;
        }

        case "unlock_breeds":
            global.val.br_unlock = [[[0,7],[6,4],[2,5],[1,3]],[[1,5],[0,6],[4,2],[3,7]],[[6,4],[0,1],[2,5],[3,7]],[[0,6],[4,2],[1,3],[7,5]]];
            break;

        case "unlock_cell":
            scr_add_new_slot_h_type(arg0.h_type, false);
            break;

        case "unlock_prop":
            scr_add_new_prop_type(arg0.prop_id, true);
            break;

        case "unlock_raid":
            global.unlock.raid = true;
            break;

        case "unlock_all_cells":
        {
            var _orders = [global.breed_order, global.utility_order, global.pleasure_order];
            var _unlocks = [global.unlock.breed, global.unlock.utility, global.unlock.pleasure];
            for (var _oi = 0; _oi < 3; _oi++)
            {
                var _ord = _orders[_oi];
                var _ulk = _unlocks[_oi];
                for (var _ci = 0; _ci < array_length(_ord); _ci++)
                {
                    var _ht = _ord[_ci];
                    var _found = false;
                    for (var _ui = 0; _ui < array_length(_ulk); _ui++)
                    {
                        if (_ulk[_ui] == _ht) { _found = true; break; }
                    }
                    if (!_found)
                        array_push(_ulk, _ht);
                }
            }
            // Also big cell orders
            var _b_orders = [global.b_breed_order, global.b_utility_order, global.b_pleasure_order];
            var _b_unlocks = [global.unlock.b_breed, global.unlock.b_utility, global.unlock.b_other];
            for (var _oi = 0; _oi < 3; _oi++)
            {
                var _ord = _b_orders[_oi];
                var _ulk = _b_unlocks[_oi];
                for (var _ci = 0; _ci < array_length(_ord); _ci++)
                {
                    var _ht = _ord[_ci];
                    var _found = false;
                    for (var _ui = 0; _ui < array_length(_ulk); _ui++)
                    {
                        if (_ulk[_ui] == _ht) { _found = true; break; }
                    }
                    if (!_found)
                        array_push(_ulk, _ht);
                }
            }
            // Tent cell orders
            var _t_orders = [global.t_breed_order, global.t_utility_order];
            var _t_unlocks = [global.unlock.t_breed, global.unlock.t_utility];
            for (var _oi = 0; _oi < 2; _oi++)
            {
                var _ord = _t_orders[_oi];
                var _ulk = _t_unlocks[_oi];
                for (var _ci = 0; _ci < array_length(_ord); _ci++)
                {
                    var _ht = _ord[_ci];
                    var _found = false;
                    for (var _ui = 0; _ui < array_length(_ulk); _ui++)
                    {
                        if (_ulk[_ui] == _ht) { _found = true; break; }
                    }
                    if (!_found)
                        array_push(_ulk, _ht);
                }
            }
            scr_gnx_apply_unlocks();
            break;
        }

        // === E. Environment / Map ===
        case "add_floor":
        {
            global.val.floor++;
            array_push(global.slot_x, -1);
            array_push(global.slot_list, ds_list_create());
            var _start_id = scr_create_slot(UnknownEnum.Value_4, global.val.floor, 0, false);
            with (_start_id)
            {
                scr_create_slot(UnknownEnum.Value_3, global.val.floor, 1, true);
            }
            break;
        }

        case "set_day":
            global.val.day = max(1, arg0.value);
            break;

        case "add_day_time":
            global.val.day_timer += arg0.amount;
            break;

        // === F. Speed / Display ===
        case "set_speed":
        {
            var _target = arg0.target;
            var _val = arg0.value;
            if (_target == "world") global.w_spd = clamp(_val, 0, 10);
            else if (_target == "cart") global.val.cart_spd = clamp(_val, 0, 10);
            else if (_target == "range") global.val.add_range = clamp(_val, 0, 20);
            break;
        }

        case "swap_mouse":
        {
            var _tmp = global.val.camera_click;
            global.val.camera_click = global.val.select_click;
            global.val.select_click = _tmp;
            break;
        }

        case "show_debug_overlay":
        {
            var _en = variable_struct_exists(arg0, "enable") ? arg0.enable : true;
            if (_en)
                show_debug_log(true);
            else
                show_debug_overlay(false);
            break;
        }

        // === G. Generic Setters ===
        case "set_val":
        {
            var _key = arg0.key;
            var _v = arg0.value;
            switch (_key)
            {
                case "mood": global.val.mood = clamp(_v, 0, 100); break;
                case "food": global.val.food = max(0, _v); break;
                case "money": global.val.money = max(0, _v); break;
                case "cart_spd": global.val.cart_spd = clamp(_v, 0, 10); break;
                case "add_range": global.val.add_range = clamp(_v, 0, 20); break;
                case "day": global.val.day = max(1, _v); break;
                case "day_timer": global.val.day_timer = max(0, _v); break;
                case "orb_num": global.val.orb_num = max(0, _v); break;
                case "sfx_vol": global.val.sfx_vol = clamp(_v, 0, 1); break;
                case "bgm_vol": global.val.bgm_vol = clamp(_v, 0, 1); break;
                case "alpha_type": global.val.alpha_type = clamp(_v, 0, 2); break;
                case "mon_alpha": global.val.mon_alpha = clamp(_v, 0, 1); break;
                case "crate_alpha_type": global.val.crate_alpha_type = clamp(_v, 0, 2); break;
                case "crate_alpha": global.val.crate_alpha = clamp(_v, 0, 1); break;
                case "show_head": global.val.show_head = _v; break;
                case "ui_place": global.val.ui_place = _v; break;
                default:
                {
                    var _log = file_text_open_append(GNX_LOG);
                    file_text_write_string(_log, "[GNX-TOOL] unknown set_val key: " + _key + "\n");
                    file_text_close(_log);
                    break;
                }
            }
            break;
        }

        case "set_var":
        {
            var _key = arg0.key;
            var _v = arg0.value;
            switch (_key)
            {
                case "w_spd": global.w_spd = clamp(_v, 0, 10); break;
                case "gnx_perf_enabled": global.gnx_perf_enabled = (_v != 0); break;
                case "gnx_debug_verbose": global.gnx_debug_verbose = (_v != 0); break;
                default:
                {
                    var _log = file_text_open_append(GNX_LOG);
                    file_text_write_string(_log, "[GNX-TOOL] unknown set_var key: " + _key + "\n");
                    file_text_close(_log);
                    break;
                }
            }
            // Always-on confirmation so a framework toggle press is visible even when verbose is off.
            if (_key == "gnx_perf_enabled" || _key == "gnx_debug_verbose")
            {
                var _svlog = file_text_open_append(GNX_LOG);
                file_text_write_string(_svlog, "[GNX-TOOL] set_var " + _key + " = " + string(_v) + "\n");
                file_text_close(_svlog);
            }
            break;
        }

        // === H. Raid / Shop ===
        case "reroll_shop":
            with (obj_np.obj_raid)
            {
                if (activate)
                    scr_choose_shop_item();
            }
            break;

        case "reroll_trade":
            with (obj_np.obj_raid)
            {
                if (activate)
                    scr_choose_trade_item();
            }
            break;

        case "reroll_encounters":
        {
            var _raid = obj_np.obj_raid;
            if (_raid.activate)
            {
                var _stage = _raid.stage;
                var _lvl = global.val.stage_lvl_sel[_stage];
                scr_set_stage_data(_stage, _lvl, false);
            }
            break;
        }

        // === I. State / Meta / Events ===
        case "set_state":
            scr_gnx_set_state(arg1, arg0.key, arg0.value);
            break;

        case "set_continuous":
        {
            var _eff_key = arg0.key;
            var _enable = arg0.value;
            if (_enable)
            {
                // Check not already registered
                var _exists = false;
                for (var _ei = 0; _ei < array_length(global.gnx_continuous_effects); _ei++)
                {
                    if (global.gnx_continuous_effects[_ei].key == _eff_key && global.gnx_continuous_effects[_ei].mod_name == arg1)
                    { _exists = true; break; }
                }
                if (!_exists)
                    array_push(global.gnx_continuous_effects, { mod_name: arg1, key: _eff_key });
            }
            else
            {
                // Remove
                for (var _ei = array_length(global.gnx_continuous_effects) - 1; _ei >= 0; _ei--)
                {
                    if (global.gnx_continuous_effects[_ei].key == _eff_key && global.gnx_continuous_effects[_ei].mod_name == arg1)
                        array_delete(global.gnx_continuous_effects, _ei, 1);
                }
            }
            break;
        }

        case "fire_event":
        {
            var _eid = arg0.event_id;
            if (is_string(_eid))
                scr_gnx_fire_event(_eid, arg1);
            else
                scr_add_event(_eid, false);
            break;
        }

        case "fire_trigger":
            scr_gnx_check_triggers(arg0.hook);
            break;

        case "popup":
            scr_gnx_pop_up_create(arg0.text);
            break;

        case "play_sfx":
            scr_sfx_play(arg0.sfx_type);
            break;

        // === K. Multi-Map === [SHELVED 1.3.11: scr_gnx_travel returns false when disabled]
        case "travel_map":
        {
            var _target = arg0.target;
            scr_gnx_travel(_target);
            break;
        }

        // [SHELVED 1.3.11] case "gml" removed (GMLC not shipped)
        case "gml":
            break;

        default:
        {
            var _log = file_text_open_append(GNX_LOG);
            file_text_write_string(_log, "[GNX-TOOL] unknown action type: " + _type + "\n");
            file_text_close(_log);
            break;
        }
    }
}

/// @desc Execute a tool button click. Handles toggle logic, guards, action chain.
/// @arg {struct} arg0  button definition struct
/// @arg {string} arg1  mod_name
function scr_gnx_exec_tool_button(arg0, arg1)
{
    if (global.gnx_debug_verbose)
    {
        var _tlog = file_text_open_append(GNX_LOG);
        file_text_write_string(_tlog, "[GNX-TOOL] press mod=" + string(arg1)
            + " label='" + string(variable_struct_exists(arg0, "label") ? arg0.label : "?") + "'"
            + " toggle='" + string(arg0.toggle) + "'"
            + " state=" + string(scr_gnx_get_state(arg1, arg0.toggle))
            + " actions=" + string(array_length(arg0.actions)) + "\n");
        file_text_close(_tlog);
    }

    // Guard check
    if (arg0.guard != -1)
    {
        if (!scr_gnx_eval_tool_guard(arg0.guard, arg1))
        {
            if (arg0.guard_fail_popup != "")
                scr_gnx_pop_up_create(arg0.guard_fail_popup);
            exit;
        }
    }

    // Toggle logic
    if (arg0.toggle != "")
    {
        var _state = scr_gnx_get_state(arg1, arg0.toggle);
        if (_state == 0 || _state == undefined)
        {
            // Turn ON
            for (var _i = 0; _i < array_length(arg0.actions); _i++)
                scr_gnx_exec_tool_action(arg0.actions[_i], arg1);
            scr_gnx_set_state(arg1, arg0.toggle, 1);
            if (arg0.popup != "")
                scr_gnx_pop_up_create(arg0.popup);
        }
        else
        {
            // Turn OFF
            for (var _i = 0; _i < array_length(arg0.undo_actions); _i++)
                scr_gnx_exec_tool_action(arg0.undo_actions[_i], arg1);
            scr_gnx_set_state(arg1, arg0.toggle, 0);
            if (arg0.undo_popup != "")
                scr_gnx_pop_up_create(arg0.undo_popup);
        }
    }
    else
    {
        // Normal button: run actions
        for (var _i = 0; _i < array_length(arg0.actions); _i++)
            scr_gnx_exec_tool_action(arg0.actions[_i], arg1);
        if (arg0.popup != "")
            scr_gnx_pop_up_create(arg0.popup);
    }
}

/// @desc Evaluate a tool guard condition. Extends quest condition evaluator.
/// @arg {struct} arg0  condition struct
/// @arg {string} arg1  mod_name
/// @return bool
function scr_gnx_eval_tool_guard(arg0, arg1)
{
    var _type = arg0.type;

    switch (_type)
    {
        case "boss_locked":
            return (global.unlock.boss[arg0.index] == -1);
        case "boss_unlocked":
            return (global.unlock.boss[arg0.index] != -1);
        case "stage_undiscovered":
            return (global.val.stage_info[arg0.stage] == -1);
        case "has_unit_slot":
        {
            for (var _i = 0; _i < ds_list_size(global.unit_list); _i++)
            {
                if (ds_list_find_value(global.unit_list, _i) == -1)
                    return true;
            }
            return false;
        }
        case "on_screen":
            return (obj_np.obj_raid.activate);
        default:
            // Fall through to quest condition evaluator
            return scr_gnx_eval_condition(arg0, arg1);
    }
}

/// @desc Per-frame keybind check. Called from obj_control_Step_0.
function scr_gnx_check_keybinds()
{
    if (!global.gnx_has_tools) exit;
    if (global.click_lock || global.trans_lock) exit;

    var _binds = global.gnx_keybinds;
    for (var _i = 0; _i < array_length(_binds); _i++)
    {
        var _b = _binds[_i];

        // Check modifier
        var _mod_ok = true;
        switch (_b.modifier)
        {
            case "shift": _mod_ok = keyboard_check(vk_shift); break;
            case "ctrl": _mod_ok = keyboard_check(vk_control); break;
            case "alt": _mod_ok = keyboard_check(vk_alt); break;
            case "none":
                if (keyboard_check(vk_shift) || keyboard_check(vk_control) || keyboard_check(vk_alt))
                    _mod_ok = false;
                break;
        }
        if (!_mod_ok) continue;

        // Check key
        if (_b.key_type == "range")
        {
            for (var _k = _b.key_start; _k <= _b.key_end; _k++)
            {
                if (keyboard_check_pressed(ord(string(_k))))
                {
                    // Execute range action with key substitution
                    if (_b.action_per_key != -1)
                    {
                        var _act = json_parse(json_stringify(_b.action_per_key));
                        if (variable_struct_exists(_act, "value"))
                            _act.value = _k;
                        scr_gnx_exec_tool_action(_act, _b.mod_name);
                    }
                    if (_b.popup_template != "")
                        scr_gnx_pop_up_create(string_replace(_b.popup_template, "{key}", string(_k)));
                    else if (_b.popup != "")
                        scr_gnx_pop_up_create(_b.popup);
                    break;
                }
            }
        }
        else
        {
            if (_b.vk_code != -1 && keyboard_check_pressed(_b.vk_code))
            {
                for (var _ai = 0; _ai < array_length(_b.actions); _ai++)
                    scr_gnx_exec_tool_action(_b.actions[_ai], _b.mod_name);
                if (_b.popup != "")
                    scr_gnx_pop_up_create(_b.popup);
            }
        }
    }
}

/// @desc Per-frame continuous effects. Called from obj_control_Step_0.
function scr_gnx_apply_continuous_effects()
{
    if (!global.gnx_has_tools) exit;

    for (var _i = 0; _i < array_length(global.gnx_continuous_effects); _i++)
    {
        var _eff = global.gnx_continuous_effects[_i];
        switch (_eff.key)
        {
            case "mood_lock":
                global.val.mood = 100;
                break;
            // Future continuous effects go here
        }
    }
}

// === Tool Menu UI Functions ===

/// @desc Settings draw override: adds GNX row, shifts GUIDE/EXIT down by 10px
function scr_gnx_draw_alpha_window()
{
    var _spr = asset_get_index("spr_gnx_option_window");
    if (_spr < 0) _spr = spr_option_window;
    draw_sprite_ext(_spr, image_index, x, y, 1, 1, image_angle, image_blend, image_alpha);
    var _x = x - 32;
    var _y = y + 8;
    var _width = 55;
    draw_set_color(c_white);
    draw_set_halign(fa_left);
    draw_text(_x, _y, "MON TYPE");
    draw_text(_x, _y + 12, "OPACITY");
    draw_text(_x, _y + 24, "PROP TYPE");
    draw_text(_x, _y + 36, "OPACITY");
    draw_text(_x, _y + 49, "SFX");
    draw_text(_x, _y + 61, "BGM");
    draw_text(_x, _y + 74, "UI PLACEMENT");
    draw_text(_x, _y + 87, "FULLSCREEN");
    draw_text(_x, _y + 100, "DEBUG");
    draw_text(_x, _y + 113, "GUIDE");
    draw_text(_x + 43, _y + 113, "EXIT");
    draw_set_halign(fa_center);
    draw_text(_x + _width, _y, string(global.val.alpha_type + 1));
    draw_text(_x + _width, _y + 12, string(round(global.val.mon_alpha * 100)) + "%");
    draw_text(_x + _width, _y + 24, string(global.val.crate_alpha_type + 1));
    draw_text(_x + _width, _y + 36, string(round(global.val.crate_alpha * 100)) + "%");
    draw_text(_x + _width, _y + 49, string(round(global.val.sfx_vol * 100)) + "%");
    draw_text(_x + _width, _y + 61, string(round(global.val.bgm_vol * 100)) + "%");
    _x = x - 74;
    _y = y + 6;
    var _height = 34;
    draw_text(_x, _y, "SAVE 1");
    draw_text(_x, _y + _height, "SAVE 2");
    draw_text(_x, _y + (_height * 2), "SAVE 3");
}

/// @desc Draw function for the tool menu window background. Assigned to scr_window_draw.
function scr_gnx_draw_tool_window()
{
    draw_sprite_ext(spr_guide_window, image_index, x, y, 1, 1, image_angle, image_blend, image_alpha);
    var _x = x - 97;
    var _y = y + 9;
    draw_set_color(c_white);
    draw_set_halign(fa_center);
    draw_text(_x, _y, "TOOLS");
}

/// @desc Create callback for tool category buttons. Sets guide_text from registry.
function scr_gnx_create_tool_cat_button()
{
    scr_create_option_button();
    spr_sel = spr_button_guide_sel;
    switch_type = false;
    fail_shake = false;

    // Compute label from registry. button_num is the flat category index.
    // _gnx framework entry doesn't count as a "mod" for prefix purposes
    var _flat = button_num;
    var _count = 0;
    var _real_mod_count = 0;
    for (var _mi = 0; _mi < array_length(global.gnx_tool_registry); _mi++)
        if (global.gnx_tool_registry[_mi].mod_name != "_gnx") _real_mod_count++;
    var _single_mod = (_real_mod_count <= 1);

    for (var _mi = 0; _mi < array_length(global.gnx_tool_registry); _mi++)
    {
        var _reg = global.gnx_tool_registry[_mi];
        for (var _ci = 0; _ci < array_length(_reg.categories); _ci++)
        {
            if (_count == _flat)
            {
                gnx_mod_index = _mi;
                gnx_cat_index = _ci;
                guide_text = _reg.categories[_ci].label;
                exit;
            }
            _count++;
        }
    }
}

/// @desc Create callback for BACK button (returns to category list).
function scr_gnx_create_tool_back_cat()
{
    scr_create_option_button();
    spr_sel = spr_button_bar_sel;
    guide_text = "BACK";
}

/// @desc Create callback for BACK button (returns to settings).
function scr_gnx_create_tool_back_settings()
{
    scr_create_option_button();
    spr_sel = spr_button_bar_sel;
    guide_text = "BACK";
}

/// @desc Create callback for tool action buttons within a category.
function scr_gnx_create_tool_action_button()
{
    scr_create_option_button();
    spr_sel = spr_button_guide_sel;

    // gnx_mod_index and gnx_cat_index are passed via the window's gnx_* vars
    var _mi = source_id.gnx_mod_index;
    var _ci = source_id.gnx_cat_index;
    var _reg = global.gnx_tool_registry[_mi];
    var _cat = _reg.categories[_ci];

    gnx_mod_index = _mi;
    gnx_cat_index = _ci;
    gnx_btn_index = button_num;

    if (button_num < array_length(_cat.buttons))
    {
        var _btn = _cat.buttons[button_num];
        guide_text = _btn.label;

        // Show toggle state in label
        if (_btn.toggle != "")
        {
            var _st = scr_gnx_get_state(_reg.mod_name, _btn.toggle);
            if (_st == 1)
                guide_text += " [ON]";
            else
                guide_text += " [OFF]";
        }
    }
}

/// @desc Draw function for tool buttons (same pattern as vanilla guide_button).
function scr_gnx_draw_tool_button()
{
    draw_sprite_ext(sprite_index, image_index, x, y, image_xscale, image_yscale, image_angle, image_blend, image_alpha);
    draw_set_halign(fa_center);
    var _lang_pos = scr_change_lang();
    var _alpha = clamp(!(image_index % 2), 0.5, 1);
    draw_text_color(x + 1 + _lang_pos[0], (y - 3) + _lang_pos[1], guide_text, c_white, c_white, c_white, c_white, _alpha);
    if (hover != -1 && hover && !trigger)
    {
        if (spr_sel != -1)
            draw_sprite_ext(spr_sel, 0, x, y, image_xscale, image_yscale, image_angle, image_blend, image_alpha);
        hover = false;
    }
    draw_set_font(fnt_base_font_eng);
}

/// @desc Compute total number of tool categories across all mods.
function scr_gnx_tool_cat_count()
{
    var _count = 0;
    for (var _mi = 0; _mi < array_length(global.gnx_tool_registry); _mi++)
        _count += array_length(global.gnx_tool_registry[_mi].categories);
    return _count;
}

// ============================================================
// GNX SOUND SYSTEM FUNCTIONS
// ============================================================

/// @desc Resolve a sound file from mod folder. Returns cached sound_id or loads via audio_create_stream.
function gnx_resolve_sound(arg0, arg1)
{
    // arg0 = base_dir (e.g. "C:/.../GNX_mods/mod_name/")
    // arg1 = filename (e.g. "soft_1.wav")
    var _cache_key = arg0 + arg1;
    if (ds_map_exists(global.gnx_sound_cache, _cache_key))
    {
        var _cached = ds_map_find_value(global.gnx_sound_cache, _cache_key);
        if (audio_exists(_cached))
            return _cached;
        ds_map_delete(global.gnx_sound_cache, _cache_key);
    }
    var _path = arg0 + "sounds/" + arg1;
    if (!file_exists(_path))
    {
        var _log = file_text_open_append(GNX_LOG);
        file_text_write_string(_log, "[GNX-SOUND] file not found: " + _path + "\n");
        file_text_close(_log);
        return -1;
    }
    var _snd = audio_create_stream(_path);
    if (_snd != -1)
    {
        array_push(global.gnx_runtime_sounds, _snd);
        ds_map_set(global.gnx_sound_cache, _cache_key, _snd);
    }
    var _log = file_text_open_append(GNX_LOG);
    file_text_write_string(_log, "[GNX-SOUND] loaded " + arg1 + " idx=" + string(_snd) + "\n");
    file_text_close(_log);
    return _snd;
}

/// @desc Cleanup all runtime sounds. Called on game exit.
function gnx_cleanup_sounds()
{
    if (!variable_global_exists("gnx_runtime_sounds"))
        return;
    var _arr = global.gnx_runtime_sounds;
    for (var i = 0; i < array_length(_arr); i++)
    {
        if (audio_exists(_arr[i]))
            audio_destroy_stream(_arr[i]);
    }
    global.gnx_runtime_sounds = [];
}

/// @desc Load sounds.json for a mod. Called from scr_gnx_load_mod.
/// arg0 = mod folder name, arg1 = sounds json filename
function scr_gnx_load_sounds(arg0, arg1)
{
    var _path = global.gnx_mods_root + arg0 + "/" + arg1;
    if (!file_exists(_path))
    {
        gnx_report_mod_error("Mod '" + arg0 + "': sounds file '" + arg1 + "' not found");
        exit;
    }

    var _f = file_text_open_read(_path);
    var _json = "";
    while (!file_text_eof(_f))
        _json += file_text_readln(_f);
    file_text_close(_f);

    var _data;
    try { _data = json_parse(_json); }
    catch (_e)
    {
        gnx_report_mod_error("Mod '" + arg0 + "': sounds.json parse error");
        exit;
    }

    var _base_dir = global.gnx_mods_root + arg0 + "/";
    var _log = file_text_open_append(GNX_LOG);
    file_text_write_string(_log, "[GNX-SOUND] loading sounds for mod '" + arg0 + "'\n");
    file_text_close(_log);

    // Voice banks
    if (variable_struct_exists(_data, "voice_banks"))
    {
        var _vb = _data.voice_banks;
        var _vb_keys = variable_struct_get_names(_vb);
        for (var _vi = 0; _vi < array_length(_vb_keys); _vi++)
        {
            var _bank_name = arg0 + "." + _vb_keys[_vi];
            var _bank_def = variable_struct_get(_vb, _vb_keys[_vi]);
            if (!variable_struct_exists(_bank_def, "clips")) continue;
            var _clips = _bank_def.clips;
            var _snd_arr = [];
            for (var _ci = 0; _ci < array_length(_clips); _ci++)
            {
                var _snd = gnx_resolve_sound(_base_dir, _clips[_ci]);
                if (_snd != -1)
                    array_push(_snd_arr, _snd);
            }
            if (array_length(_snd_arr) > 0)
            {
                ds_map_set(global.gnx_voice_banks, _bank_name, _snd_arr);
                array_push(global.gnx_voice_bank_names, _bank_name);
            }
            _log = file_text_open_append(GNX_LOG);
            file_text_write_string(_log, "[GNX-SOUND] bank '" + _bank_name + "' clips=" + string(array_length(_snd_arr)) + "\n");
            file_text_close(_log);
        }
    }

    // Voice map: class_id -> {bank, pitch}. Overrides random assignment for named classes.
    // Bank name is auto-prefixed with mod name, same as voice_banks.
    if (variable_struct_exists(_data, "voice_map"))
    {
        var _vm = _data.voice_map;
        var _vm_keys = variable_struct_get_names(_vm);
        for (var _mi = 0; _mi < array_length(_vm_keys); _mi++)
        {
            var _cls_key = _vm_keys[_mi];              // string class id, e.g. "8"
            var _cls_id = real(_cls_key);
            var _entry = variable_struct_get(_vm, _cls_key);
            if (!variable_struct_exists(_entry, "bank")) continue;
            var _mapped = {
                bank: arg0 + "." + _entry.bank,
                pitch: variable_struct_exists(_entry, "pitch") ? _entry.pitch : -1
            };
            ds_map_set(global.gnx_voice_class_map, _cls_id, _mapped);
            _log = file_text_open_append(GNX_LOG);
            file_text_write_string(_log, "[GNX-SOUND] voice_map class=" + string(_cls_id) + " bank='" + _mapped.bank + "' pitch=" + string(_mapped.pitch) + "\n");
            file_text_close(_log);
        }
    }

    // SFX pools
    if (variable_struct_exists(_data, "sfx"))
    {
        var _sfx = _data.sfx;
        var _sfx_map = [
            ["orgasm",     "gnx_sfx_orgasm"],
            ["bj_slurp",   "gnx_sfx_bj_slurp"],
            ["bj_gag",     "gnx_sfx_bj_gag"],
            ["bj_moan",    "gnx_sfx_bj_moan"],
            ["bj_breathe", "gnx_sfx_bj_breathe"]
        ];
        for (var _si = 0; _si < array_length(_sfx_map); _si++)
        {
            var _key = _sfx_map[_si][0];
            if (!variable_struct_exists(_sfx, _key)) continue;
            var _clips = variable_struct_get(_sfx, _key);
            var _target = variable_global_get(_sfx_map[_si][1]);
            for (var _ci = 0; _ci < array_length(_clips); _ci++)
            {
                var _snd = gnx_resolve_sound(_base_dir, _clips[_ci]);
                if (_snd != -1)
                    array_push(_target, _snd);
            }
        }
    }

    // Settings defaults (first mod wins)
    if (variable_struct_exists(_data, "settings_defaults") && !global.gnx_has_sounds)
    {
        var _sd = _data.settings_defaults;
        if (variable_struct_exists(_sd, "moan_vol"))    global.val.moan_vol    = _sd.moan_vol;
        if (variable_struct_exists(_sd, "moan_frq"))    global.val.moan_frq    = _sd.moan_frq;
        if (variable_struct_exists(_sd, "orgasm_frq"))  global.val.orgasm_frq  = _sd.orgasm_frq;
        if (variable_struct_exists(_sd, "plap_vol"))    global.val.plap_vol    = _sd.plap_vol;
        if (variable_struct_exists(_sd, "ej_vol"))      global.val.ej_vol      = _sd.ej_vol;
        if (variable_struct_exists(_sd, "bj_vol"))      global.val.bj_vol      = _sd.bj_vol;
    }
    else if (!global.gnx_has_sounds)
    {
        // No settings_defaults provided: use sensible defaults
        global.val.moan_vol   = 0.5;
        global.val.moan_frq   = 15;
        global.val.orgasm_frq = 5;
        global.val.plap_vol   = 0.5;
        global.val.ej_vol     = 0.5;
        global.val.bj_vol     = 0.5;
    }

    global.gnx_has_sounds = true;
    _log = file_text_open_append(GNX_LOG);
    file_text_write_string(_log, "[GNX-SOUND] mod '" + arg0 + "' sounds loaded\n");
    file_text_close(_log);
}

/// @desc Generate voice assignment for a class. Returns {moan_voice, moan_pitch}.
/// arg1 (optional) force_random: when true, skip fixed maps and assign a random bank
/// (matches original moan mod: lvl 6/7 units always get a random voice).
function scr_gnx_generate_voice(arg0)
{
    // arg0 = class_id
    var _force_random = (argument_count > 1) ? argument[1] : false;
    var _result = { moan_voice: -1, moan_pitch: -1 };
    if (!global.gnx_has_sounds || array_length(global.gnx_voice_bank_names) == 0)
        return _result;

    if (!_force_random)
    {
        // sounds.json voice_map: fixed voice for named vanilla classes (bypasses class_registry)
        if (ds_map_exists(global.gnx_voice_class_map, arg0))
        {
            var _vm = ds_map_find_value(global.gnx_voice_class_map, arg0);
            if (ds_map_exists(global.gnx_voice_banks, _vm.bank))
            {
                _result.moan_voice = _vm.bank;
                _result.moan_pitch = (_vm.pitch != -1) ? _vm.pitch : (0.9 + random(0.25));
                return _result;
            }
        }

        // Class registry fixed voice (mod classes with a "voice" field).
        // Only honor it if the bank actually exists; otherwise fall through to random
        // (a typo'd bank or an unloaded sound mod should not silence the unit).
        if (ds_map_exists(global.class_registry, arg0))
        {
            var _rc = ds_map_find_value(global.class_registry, arg0);
            if (is_struct(_rc) && variable_struct_exists(_rc, "voice_bank") && _rc.voice_bank != -1
                && ds_map_exists(global.gnx_voice_banks, _rc.voice_bank))
            {
                _result.moan_voice = _rc.voice_bank;
                _result.moan_pitch = (_rc.voice_pitch != -1) ? _rc.voice_pitch : (0.9 + random(0.25));
                return _result;
            }
        }
    }

    // Random assignment from available banks
    _result.moan_voice = global.gnx_voice_bank_names[irandom(array_length(global.gnx_voice_bank_names) - 1)];
    _result.moan_pitch = 0.9 + random(0.25);
    return _result;
}

/// @desc Validate/migrate voice fields on a unit_data struct. Called from scr_occupy_slot and save/load.
function scr_gnx_check_voice(arg0)
{
    // arg0 = unit_data struct
    if (!global.gnx_has_sounds) return;
    if (!is_struct(arg0)) return;

    var _needs_gen = false;
    if (!variable_struct_exists(arg0, "moan_voice") || !variable_struct_exists(arg0, "moan_pitch"))
        _needs_gen = true;
    else if (arg0.moan_voice == -1 || arg0.moan_pitch == -1)
        _needs_gen = true;

    if (_needs_gen)
    {
        var _class = variable_struct_exists(arg0, "class") ? arg0.class : 0;
        // Original moan mod: lvl 6/7 units (captured bosses) always get a random voice.
        var _lvl = variable_struct_exists(arg0, "lvl") ? arg0.lvl : 0;
        var _force_random = (_lvl == 6 || _lvl == 7);
        var _v = scr_gnx_generate_voice(_class, _force_random);
        arg0.moan_voice = _v.moan_voice;
        arg0.moan_pitch = _v.moan_pitch;
    }
}

/// @desc Check if a slot is a BJ cell (for sound type selection).
function scr_gnx_is_bj_cell(arg0)
{
    // arg0 = slot_data struct
    // Vanilla BJ cells
    if (arg0.h_type == 6) return true;
    if (arg0.h_type == 18 && variable_struct_exists(arg0, "mon_placement") && arg0.mon_placement[2] != -1) return true;
    // GNX cell registry: sfx_type field
    if (ds_map_exists(global.cell_registry, arg0.h_type))
    {
        var _cell = ds_map_find_value(global.cell_registry, arg0.h_type);
        if (variable_struct_exists(_cell, "sfx_type") && _cell.sfx_type == "bj")
            return true;
    }
    return false;
}

/// @desc Draw function for GNX sound settings page
function scr_gnx_draw_sound_window()
{
    draw_sprite_ext(spr_option_window, image_index, x, y, 1, 1, image_angle, image_blend, image_alpha);
    var _x = x - 32;
    var _y = y + 8;
    var _width = 55;
    draw_set_color(c_white);
    draw_set_halign(fa_left);
    draw_text(_x, _y, "MOAN VOL");
    draw_text(_x, _y + 12, "MOAN FRQ");
    draw_text(_x, _y + 24, "ORGASM FRQ");
    draw_text(_x, _y + 36, "PLAP VOL");
    draw_text(_x, _y + 48, "EJ VOL");
    draw_text(_x, _y + 61, "BJ VOL");
    draw_text(_x, _y + 100, "GUIDE");
    draw_text(_x + 43, _y + 100, "BACK");
    draw_set_halign(fa_center);
    draw_text(_x + _width, _y, string(round(global.val.moan_vol * 100)) + "%");
    draw_text(_x + _width, _y + 12, string(global.val.moan_frq) + "%");
    draw_text(_x + _width, _y + 24, string(global.val.orgasm_frq) + "%");
    draw_text(_x + _width, _y + 36, string(round(global.val.plap_vol * 100)) + "%");
    draw_text(_x + _width, _y + 48, string(round(global.val.ej_vol * 100)) + "%");
    draw_text(_x + _width, _y + 61, string(round(global.val.bj_vol * 100)) + "%");
    _x = x - 74;
    _y = y + 6;
    var _height = 34;
    draw_text(_x, _y, "SAVE 1");
    draw_text(_x, _y + _height, "SAVE 2");
    draw_text(_x, _y + (_height * 2), "SAVE 3");
}

enum UnknownEnum
{
    Value_0,
    Value_1,
    Value_2,
    Value_3,
    Value_4,
    Value_5,
    Value_6,
    Value_7,
    Value_8,
    Value_9,
    Value_10,
    Value_11,
    Value_12,
    Value_13,
    Value_14,
    Value_15,
    Value_16,
    Value_17,
    Value_18,
    Value_19,
    Value_20,
    Value_21,
    Value_22,
    Value_23,
    Value_24,
    Value_25,
    Value_26,
    Value_27,
    Value_28,
    Value_29,
    Value_30,
    Value_31,
    Value_32,
    Value_33,
    Value_34,
    Value_35,
    Value_36,
    Value_37,
    Value_38,
    Value_39,
    Value_40,
    Value_41,
    Value_42,
    Value_43,
    Value_44,
    Value_45,
    Value_46,
    Value_47,
    Value_48,
    Value_49,
    Value_50,
    Value_51,
    Value_52,
    Value_53,
    Value_54,
    Value_55,
    Value_56,
    Value_57,
    Value_58,
    Value_59,
    Value_60,
    Value_61,
    Value_62,
    Value_63
}
