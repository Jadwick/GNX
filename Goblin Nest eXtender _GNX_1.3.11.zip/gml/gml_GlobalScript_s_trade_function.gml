function scr_raid_drop_trade(arg0, arg1, arg2)
{
    var _empty = true;

    if (obj_np.obj_raid.raid_data.raid_state == 3 && ((arg1 >= 172 && arg1 < 209) && (arg2 >= 104 && arg2 < 152)))
    {
        _empty = false;

        switch (arg0.interact_type)
        {
            case 20:
                if (arg0.unit_data.class < 8 || (arg0.unit_data.class >= 8 && arg0.unit_data.lvl >= 6) || ds_map_exists(global.class_registry, arg0.unit_data.class))
                {
                    var _num;

                    with (arg0)
                    {
                        _num = (min(5, unit_data.lvl) + 1) * 10;

                        if (drag_type == 5)
                            global.val.cage[button_num] = -1;
                        else
                            ds_list_set(global.unit_list, button_num, -1);

                        instance_destroy();
                    }

                    global.val.money += _num;
                    scr_check_steam_achievement(4);
                    scr_icon_pop_up_create(arg1, arg2 - 10, _num, 2, true);
                    scr_sfx_play(6);
                    scr_check_softlock();
                }
                else
                {
                    scr_pop_up_create(20);
                }

                break;

            case 21:
                var _inst = obj_np.obj_raid;
                var _info = {};
                var _mon_val = scr_mon_type_construct(arg0.unit_data.mon_type);
                var _max_num = _mon_val.num[arg0.unit_data.class];
                _info.save_num = -1;
                _info.sell = true;
                _info.max_num = _max_num;
                _info.unit_data = arg0.unit_data;
                _info.mon_head_id = arg0.source_id;
                num_window = scr_create_window_num_sel(arg1, arg2, _inst, _inst.depth - 10, true, _info, -1, scr_mon_num_enter, -1);

                with (arg0)
                    instance_destroy();

                break;

            case 23:
                switch (arg0.item_type)
                {
                    case 4:
                        var _inst = obj_np.obj_raid;
                        var _item_lvl = arg0.image_index;
                        var _info = {};
                        var _size = ds_list_size(global.inv_list);
                        var _max_num;

                        for (var i = 0; i < _size; i++)
                        {
                            var _item_data = ds_list_find_value(global.inv_list, i);

                            if (_item_data.item_type == 4 && _item_data.index == _item_lvl)
                            {
                                _max_num = _item_data.num;
                                i = _size;
                            }
                        }

                        _info.max_num = _max_num;
                        _info.milk_lvl = _item_lvl;
                        _info.sell = true;
                        _info.save_num = -1;
                        num_window = scr_create_window_num_sel(arg1, arg2, _inst, _inst.depth - 10, true, _info, -1, scr_milk_num_enter, -1);
                        break;
                }

                break;
        }
    }

    return _empty;
}

function scr_raid_state_trade()
{
    if (raid_data.ff)
    {
        scr_create_button(190, 54, depth - 5, spr_button_ui, 46, id, scr_create_raid_back_button, -1, scr_draw_hover_button, 0, 0);
        var _num = array_length(raid_data.trade_unit);
        scr_create_button_layout(195, 217, depth - 5, _num, 3, 44, 0, 0, spr_button_trade, 48, other.id, false, scr_create_raid_trade_button, -1, scr_draw_raid_trade_button);
        scr_create_button_layout(290, 108, depth - 5, 3, 1, 0, 17, 0, spr_button_trade_sell, 58, id, false, scr_create_trade_sell_button, -1, scr_draw_hover_button);

        if (global.unlock.boss[4] == 1)
            scr_create_button(245, 141, depth - 5, spr_button_trade_food, 59, id, scr_create_trade_food_button, -1, scr_draw_hover_button, 0, 0);

        raid_data.ff = false;
    }
}

function scr_create_trade_sell_button()
{
    fail_shake = false;
    hover = false;
    gui = true;
    image_index = button_num * 2;
    act_resize = true;
    spr_sel = spr_button_trade_sell_sel;
}

function scr_create_trade_food_button()
{
    fail_shake = false;
    hover = false;
    gui = true;
    image_index = button_num * 2;
    act_resize = true;
    spr_sel = spr_button_trade_food_sel;
}

function scr_create_raid_trade_button()
{
    if (source_id.raid_data.trade_unit[button_num] == -1)
        instance_destroy();
    else
        scr_create_gui_base_button();

    spr_sel = spr_button_trade_sel;
    button_text = source_id.raid_data.trade_price[button_num];
}

function scr_set_trade_list()
{
    global.trade_list = [[0, 4, 2], [6, 2, 7], [1, 3, 5], [5, 5, 5], [5, 5, 5]];
}

function scr_choose_trade_item()
{
    var _stage = global.val.stage_info;
    var _num = 0;
    var _pool_list = [];
    var _dup = false;
    var _trade_num = 0;

    for (var i = 0; i < 5; i++)
    {
        if (_stage[i] != -1)
        {
            for (var ii = 0; ii < (min(2, _stage[i].max_lvl) + 1); ii++)
            {
                _dup = false;

                for (var iii = 0; iii < array_length(_pool_list); iii++)
                {
                    if (_pool_list[iii] == global.trade_list[i][ii])
                    {
                        _dup = true;
                        iii = array_length(_pool_list);
                    }
                }

                if (!_dup)
                {
                    _pool_list[_num] = global.trade_list[i][ii];
                    _num++;
                }
            }

            // GNX: add modded classes registered for this stage, weighted x3 for spawn rate
            var _gnx_pool = global.gnx_trade_list[i];
            var _gnx_pool_num = array_length(_gnx_pool);

            for (var ii = 0; ii < _gnx_pool_num; ii++)
            {
                repeat (3)
                {
                    _pool_list[_num] = _gnx_pool[ii];
                    _num++;
                }
            }

            _trade_num++;
        }
    }

    _trade_num = min(3, _trade_num);
    raid_data.trade_unit = [];
    raid_data.trade_price = [];

    for (var i = 0; i < _trade_num; i++)
    {
        var _unit = _pool_list[irandom_range(0, _num - 1)];
        _unit = scr_create_unit_base(_unit, i);
        raid_data.trade_unit[i] = _unit;
        raid_data.trade_price[i] = 100 * (i + 1);
    }

    if (_trade_num >= 2 && global.unlock.boss[5] == -1 && irandom_range(1, 100) <= 5)
    {
        var _a = irandom_range(0, _trade_num - 1);
        var _unit = scr_create_unit_base(13, 5);
        raid_data.trade_unit[_a] = _unit;
        raid_data.trade_price[_a] = 1000;
    }

    if (activate && raid_data.raid_state == 3)
    {
        with (obj_button)
        {
            if (interact_type == 48)
                instance_destroy();
        }

        scr_create_button_layout(195, 217, depth - 5, _trade_num, 3, 44, 0, 0, spr_button_trade, 48, id, false, scr_create_raid_trade_button, -1, scr_draw_raid_trade_button);
    }
}
