function scr_draw_raid()
{
    if (activate)
    {
        scr_draw_backdrop();
        draw_sprite(spr_raid_bg, 0, 4, 36);
        scr_draw_group_window(0);
        draw_set_halign(fa_left);
        draw_text(20, 157, "INVENTORY");
        draw_text(22, 48, "NEST");
        draw_text(371, 42, "FORMATION");
        draw_text(432, 42, "MAX");
        draw_text(329, 164, "STORAGE");
        draw_text(416, 164, "CAGE");
        // GNX: custom map sprite when on mod map, vanilla otherwise
        if (global.gnx_multimap_enabled && global.gnx_map_sprite != -1 && sprite_exists(global.gnx_map_sprite))
            draw_sprite(global.gnx_map_sprite, 0, 173, 39);
        else
            draw_sprite(spr_map, 0, 173, 39);
        var _black = false;
        
        // GNX: draw travel buttons in GUI space (state 0 only)
        if (raid_data.raid_state == UnknownEnum.Value_0)
            scr_gnx_draw_travel_buttons_gui();

        switch (raid_data.raid_state)
        {
            case UnknownEnum.Value_0:
                scr_draw_stage_info();
                break;
            
            case UnknownEnum.Value_1:
                scr_draw_stage_info();
                scr_draw_stage_icon();
                _black = true;
                break;
            
            case UnknownEnum.Value_2:
                scr_draw_stage_info();
                scr_draw_stage_icon();
                _black = true;
                break;
            
            case UnknownEnum.Value_3:
                scr_draw_raid_trade();
                break;
            
            case UnknownEnum.Value_4:
                scr_draw_raid_shop();
                break;
        }
        
        scr_draw_inventory();
        scr_draw_raid_inventory();
        var _num = array_length(global.val.cage);
        
        for (var i = 0; i < _num; i++)
            draw_sprite(spr_cage_frame, 0, 374 + (24 * i), 172);
        
        draw_set_halign(fa_right);
        
        if (global.max_troop[global.val.troop_size] == -1)
            draw_sprite(spr_infinity, 0, 449, 44);
        else
            draw_text(459, 42, string(global.max_troop[global.val.troop_size]));
        
        scr_draw_group_boxline();
        scr_draw_milk_boxline();
    }
}

function scr_draw_group_window(arg0)
{
    var _md = scr_calculate_mood_rate();
    _md.mood = min(_md.mood, 3);
    var _text_c = global.mood_c[_md.mood];
    var _row_text = ["FRONT", "BACK"];
    var _row_y = [64, 119];
    var _line_c = line_c;
    var _x = 348;
    
    for (var i = 0; i < 2; i++)
    {
        var _y = _row_y[i] - 15;
        draw_set_halign(fa_center);
        draw_set_color(c_white);
        draw_text(_x - 19, _y + 12, _row_text[i]);
        draw_sprite(spr_raid_stat_icon, i, _x - 22, _y + 21);
        draw_set_color(_text_c);
        var _a;
        
        if (raid_data.raid_state == UnknownEnum.Value_1)
            _a = max(sign(raid_data.ap[i]), floor(raid_data.ap[i]));
        else
            _a = max(sign(raid_data.ap[i]), floor(raid_data.ap[i] * _md.md_rate));
        
        draw_text(_x - 19, _y + 40, _a);
    }
    
    draw_set_color(c_white);
}

function scr_draw_stage_info()
{
    draw_sprite(spr_raid_stage_info, 0, 169, 130);
    draw_text(181, 134, "FRONT ");
    draw_text(183, 145, "BACK");
    draw_text(182, 156, "CAPTURE");
    draw_text(279, 156, "REWARD");
    draw_text(283, 203, "TIME");
    
    for (var i = 0; i < 2; i++)
        draw_sprite(spr_raid_stat_icon, i, 174, 135 + (11 * i));
    
    if (raid_data.stage != -1)
    {
        var _stage_lvl = min(2, global.val.stage_lvl_sel[raid_data.stage]);
        var _data = global.val.stage_info[raid_data.stage].info[_stage_lvl];
        var _player_hp, _player_ap;
        
        if (raid_data.raid_state != UnknownEnum.Value_1)
        {
            var _md = scr_calculate_mood_rate();
            _player_hp = floor(obj_np.obj_raid.raid_data.ap[0] * _md.md_rate);
            _player_ap = floor(obj_np.obj_raid.raid_data.ap[1] * _md.md_rate);
        }
        else
        {
            _player_hp = floor(obj_np.obj_raid.raid_data.ap[0]);
            _player_ap = floor(obj_np.obj_raid.raid_data.ap[1]);
        }
        
        var _enemy_hp = _data.en_ap[0];
        var _enemy_ap = _data.en_ap[1];
        draw_set_halign(fa_center);
        var _x = 234;
        var _y = 134;
        
        for (var i = 0; i < 2; i++)
            draw_text(_x, _y + (11 * i), string(_data.en_ap[i]));
        
        var _time_need = round((global.base_raid_time[raid_data.stage] * 2) / (global.val.cart_spd * raid_data.haste));
        var _time = time_convert(_time_need);
        draw_text(292, 214, string(_time[0]) + "H." + string(_time[1]) + "M");
        
        if (_player_hp >= _enemy_hp)
            draw_sprite(spr_tick, 0, 268, 137);
        
        if (_player_ap >= _enemy_ap)
            draw_sprite(spr_tick, 0, 268, 148);
        
        _x = 182;
        _y = 178;
        var _unit_list = _data.unit_list;
        var _num = array_length(_unit_list);
        
        for (var i = 0; i < _num; i++)
            scr_draw_stage_unit_head(_x + (20 * i), _y, _unit_list[i], true);
        
        _x = 183;
        _y = 209;
        var _item_list = _data.item;
        _num = array_length(_item_list);
        var _width = 20;
        
        for (var i = 0; i < _num; i++)
            scr_draw_item(_x + (i * _width), _y, _item_list[i], true);
        
        var _item_data = {};
        _x = 291;
        
        if (array_length(global.reward[raid_data.stage][_stage_lvl]) > 0)
        {
            _item_data = global.reward[raid_data.stage][_stage_lvl][0];
            scr_draw_item(_x, 171, _item_data, true);
            _item_data = global.reward[raid_data.stage][_stage_lvl][1];
            scr_draw_item(_x, 188, _item_data, true);
        }
        
        _stage_lvl = min(global.val.stage_lvl_sel[raid_data.stage], 2);
        _num = 0;
        var _dnum = 0;
        var _a = 0;
        var _cap_mul = 0;
        var _rev_mul = 0;
        var _dd = false;
        
        if (_player_hp >= _enemy_hp && _player_ap >= _enemy_ap)
        {
            _cap_mul = scr_check_skill_data(UnknownEnum.Value_5);
            _rev_mul = scr_check_skill_data(UnknownEnum.Value_1);
            var _over_diff = (_player_hp + _player_ap) / (_enemy_hp + _enemy_ap);
            var _list_num = array_length(_data.unit_list);
            var _max_lvl = 0;
            
            for (var i = 0; i < _list_num; i++)
            {
                if (_data.unit_list[i].lvl > _max_lvl)
                {
                    if (_data.unit_list[i].class == UnknownEnum.Value_8)
                        _max_lvl = 8;
                    else
                        _max_lvl = _data.unit_list[i].lvl;
                }
                
                if (global.unlock.boss[UnknownEnum.Value_3] == 0 && _data.unit_list[i].class == UnknownEnum.Value_12)
                    _dd = true;
            }
            
            if (raid_data.stage == UnknownEnum.Value_4 && _stage_lvl == 1)
                _dd = true;
            
            _num = ((_over_diff - 1) / (1 + (_max_lvl * 0.3))) * 100;
            _num = clamp(floor(_num + (_cap_mul * 100)), 0, 140);
            _dnum = (1 - clamp(((_over_diff - 1) * 0.8) + 0.1, 0.1, 0.9)) * 100;
            _dnum = max(0, round(_dnum - (_dnum * min(1, _rev_mul)))) + floor(_dd * (_dnum * 0.5));
        }
        
        draw_set_halign(fa_right);
        
        if (_cap_mul > 0)
            draw_set_color(c_lime);
        else
            draw_set_color(c_white);
        
        draw_text(236, 156, string(_num));
        
        if (_dd)
        {
            if (_rev_mul > 0)
                draw_set_color(c_orange);
            else
                draw_set_color(c_red);
        }
        else if (_rev_mul > 0)
        {
            draw_set_color(c_lime);
        }
        else
        {
            draw_set_color(c_white);
        }
        
        draw_text(268, 156, string(_dnum));
        draw_set_color(c_white);
        draw_text(241, 156, "%");
        draw_text(273, 156, "%");
        
        if (raid_data.raid_state == UnknownEnum.Value_0)
        {
            _x = 285;
            _y = 129;
            _num = array_length(global.val.stage_item[raid_data.stage][_stage_lvl]);
            draw_set_halign(fa_left);
            draw_sprite(spr_chest, 0, _x, _y);
            draw_sprite(spr_x, 0, _x + 9, _y + 1);
            draw_text(_x + 13, _y - 3, string(_num));
        }
    }
}

function scr_draw_stage_icon()
{
    draw_sprite(spr_button_stage, 0, 240, 92);
    
    if (global.val.stage_info[UnknownEnum.Value_1] != -1)
        draw_sprite(spr_button_stage, 1, 188, 108);
    
    if (global.val.stage_info[UnknownEnum.Value_2] != -1)
        draw_sprite(spr_button_stage, 2, 266, 50);
    
    if (global.val.stage_info[UnknownEnum.Value_3] != -1)
        draw_sprite(spr_button_stage, 3, 272, 103);
    
    if (global.val.stage_info[UnknownEnum.Value_4] != -1)
        draw_sprite(spr_button_stage, 4, 294, 80);
    
    draw_sprite(spr_raid_shop_button, 0, 233, 50);
    draw_sprite(spr_raid_trade_button, 0, 223, 76);
    
    if (instance_exists(obj_carriage))
        draw_sprite(spr_carriage, image_index, obj_carriage.x, obj_carriage.y);
}

enum UnknownEnum
{
    Value_0,
    Value_1,
    Value_2,
    Value_3,
    Value_4,
    Value_5,
    Value_8 = 8,
    Value_12 = 12
}
