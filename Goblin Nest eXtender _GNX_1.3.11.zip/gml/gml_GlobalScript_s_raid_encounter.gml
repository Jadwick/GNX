function scr_stage_encounter_data(arg0, arg1, arg2)
{
    var _unit_list = [];
    var _en_ap = [0, 0];
    var _item_pool = [];
    var _item = [];
    var _pool_num = 0;
    var _data = {};
    var _spawn_boss = false;
    arg1 = min(arg1, 2);
    var _coin_num, _food_num, i;
    var _gnx_picked = []; // tracks picked class_ids for max_per_encounter
    
    switch (arg0)
    {
        case 0:
            switch (arg1)
            {
                case 0:
                    _unit_list[0] = scr_create_unit_base(0, 0);
                    _en_ap[0] += 1;
                    _en_ap[1] += 1;
                    _coin_num = choose(10, 15, 20);
                    _food_num = choose(14, 16, 18, 20);
                    break;
                
                case 1:
                    if (global.unlock.boss[0] == 0 && irandom_range(1, 100) <= 35)
                        _spawn_boss = true;
                    
                    if (_spawn_boss)
                    {
                        _num = irandom_range(1, 2);
                        var _boss_ap = scr_set_unit_ap(9, 5);
                        _en_ap[0] += _boss_ap[0];
                        _en_ap[1] += _boss_ap[1];
                    }
                    else
                    {
                        _num = irandom_range(2, 3);
                    }
                    
                    _en_ap[0] += irandom_range(10, 14) + _num;
                    _en_ap[1] += irandom_range(9, 12) + _num;
                    
                    for (i = 0; i < _num; i++)
                    {
                        var _pick = gnx_pool_pick(0, 1, _gnx_picked);
                        var _class = _pick.class_id;
                        var _lvl = _pick.lvl;
                        if (variable_struct_exists(_pick, "ap_override"))
                        {
                            _en_ap[0] += _pick.ap_override[0];
                            _en_ap[1] += _pick.ap_override[1];
                        }
                        else
                        {
                            var _ap = scr_set_unit_ap(_class, _lvl);
                            _en_ap[0] += _ap[0];
                            _en_ap[1] += _ap[1];
                        }
                        _unit_list[i] = scr_create_unit_base(_class, _lvl);
                        array_push(_gnx_picked, _class);
                    }
                    
                    if (_spawn_boss)
                        _unit_list[i] = scr_create_unit_base(9, 5);
                    
                    _coin_num = choose(15, 20, 25);
                    _food_num = choose(22, 24, 26, 28);
                    break;
                
                case 2:
                    _num = irandom_range(3, 4);
                    _en_ap[0] += irandom_range(41, 45) + _num;
                    _en_ap[1] += irandom_range(35, 39) + _num;
                    
                    for (i = 0; i < _num; i++)
                    {
                        var _pick = gnx_pool_pick(0, 2, _gnx_picked);
                        var _class = _pick.class_id;
                        var _lvl = _pick.lvl;
                        if (variable_struct_exists(_pick, "ap_override"))
                        {
                            _en_ap[0] += _pick.ap_override[0];
                            _en_ap[1] += _pick.ap_override[1];
                        }
                        else
                        {
                            var _ap = scr_set_unit_ap(_class, _lvl);
                            _en_ap[0] += _ap[0];
                            _en_ap[1] += _ap[1];
                        }
                        _unit_list[i] = scr_create_unit_base(_class, _lvl);
                        array_push(_gnx_picked, _class);
                    }
                    
                    _coin_num = choose(30, 37, 44, 41);
                    _food_num = choose(26, 28, 30, 32, 34);
                    break;
            }
            
            break;
        
        case 1:
            switch (arg1)
            {
                case 0:
                    _num = irandom_range(1, 2);
                    _en_ap[0] += irandom_range(5, 7) + _num;
                    _en_ap[1] += irandom_range(4, 6) + _num;
                    
                    for (i = 0; i < _num; i++)
                    {
                        var _pick = gnx_pool_pick(1, 0, _gnx_picked);
                        var _class = _pick.class_id;
                        var _lvl = _pick.lvl;
                        if (variable_struct_exists(_pick, "ap_override"))
                        {
                            _en_ap[0] += _pick.ap_override[0];
                            _en_ap[1] += _pick.ap_override[1];
                        }
                        else
                        {
                            var _ap = scr_set_unit_ap(_class, _lvl);
                            _en_ap[0] += _ap[0];
                            _en_ap[1] += _ap[1];
                        }
                        _unit_list[i] = scr_create_unit_base(_class, _lvl);
                        array_push(_gnx_picked, _class);
                    }
                    
                    _coin_num = choose(15, 20, 25, 30);
                    _food_num = choose(10, 12, 14);
                    break;
                
                case 1:
                    _num = irandom_range(2, 4);
                    _en_ap[0] += irandom_range(19, 24) + _num;
                    _en_ap[1] += irandom_range(14, 18) + _num;
                    
                    for (i = 0; i < _num; i++)
                    {
                        var _pick = gnx_pool_pick(1, 1, _gnx_picked);
                        var _class = _pick.class_id;
                        var _lvl = _pick.lvl;
                        if (variable_struct_exists(_pick, "ap_override"))
                        {
                            _en_ap[0] += _pick.ap_override[0];
                            _en_ap[1] += _pick.ap_override[1];
                        }
                        else
                        {
                            var _ap = scr_set_unit_ap(_class, _lvl);
                            _en_ap[0] += _ap[0];
                            _en_ap[1] += _ap[1];
                        }
                        _unit_list[i] = scr_create_unit_base(_class, _lvl);
                        array_push(_gnx_picked, _class);
                    }
                    
                    _coin_num = choose(30, 36, 42, 48);
                    _food_num = choose(16, 18, 20);
                    break;
                
                case 2:
                    _num = irandom_range(3, 5);
                    _en_ap[0] += irandom_range(52, 68) + _num;
                    _en_ap[1] += irandom_range(42, 56) + _num;
                    
                    for (i = 0; i < _num; i++)
                    {
                        var _pick = gnx_pool_pick(1, 2, _gnx_picked);
                        var _class = _pick.class_id;
                        var _lvl = _pick.lvl;
                        if (variable_struct_exists(_pick, "ap_override"))
                        {
                            _en_ap[0] += _pick.ap_override[0];
                            _en_ap[1] += _pick.ap_override[1];
                        }
                        else
                        {
                            var _ap = scr_set_unit_ap(_class, _lvl);
                            _en_ap[0] += _ap[0];
                            _en_ap[1] += _ap[1];
                        }
                        _unit_list[i] = scr_create_unit_base(_class, _lvl);
                        array_push(_gnx_picked, _class);
                    }
                    
                    _coin_num = choose(65, 75, 85, 95);
                    _food_num = choose(18, 20, 22, 24);
                    break;
            }
            
            break;
        
        case 2:
            switch (arg1)
            {
                case 0:
                    _num = irandom_range(1, 3);
                    _en_ap[1] += irandom_range(14, 18) + _num;
                    _en_ap[0] += irandom_range(18, 25) + _num;
                    
                    for (i = 0; i < _num; i++)
                    {
                        var _pick = gnx_pool_pick(2, 0, _gnx_picked);
                        var _class = _pick.class_id;
                        var _lvl = _pick.lvl;
                        if (variable_struct_exists(_pick, "ap_override"))
                        {
                            _en_ap[0] += _pick.ap_override[0];
                            _en_ap[1] += _pick.ap_override[1];
                        }
                        else
                        {
                            var _ap = scr_set_unit_ap(_class, _lvl);
                            _en_ap[0] += _ap[0];
                            _en_ap[1] += _ap[1];
                        }
                        _unit_list[i] = scr_create_unit_base(_class, _lvl);
                        array_push(_gnx_picked, _class);
                    }
                    
                    _coin_num = choose(20, 26, 32, 38);
                    _food_num = choose(16, 18, 20, 22);
                    break;
                
                case 1:
                    _num = irandom_range(3, 4);
                    _en_ap[0] += irandom_range(52, 66) + _num;
                    _en_ap[1] += irandom_range(60, 64) + _num;
                    
                    for (i = 0; i < _num; i++)
                    {
                        var _pick = gnx_pool_pick(2, 1, _gnx_picked);
                        var _class = _pick.class_id;
                        var _lvl = _pick.lvl;
                        if (variable_struct_exists(_pick, "ap_override"))
                        {
                            _en_ap[0] += _pick.ap_override[0];
                            _en_ap[1] += _pick.ap_override[1];
                        }
                        else
                        {
                            var _ap = scr_set_unit_ap(_class, _lvl);
                            _en_ap[0] += _ap[0];
                            _en_ap[1] += _ap[1];
                        }
                        _unit_list[i] = scr_create_unit_base(_class, _lvl);
                        array_push(_gnx_picked, _class);
                    }
                    
                    _coin_num = choose(30, 40, 50, 60);
                    _food_num = choose(22, 24, 26, 28);
                    break;
                
                case 2:
                    if (global.unlock.boss[2] == 0)
                        _spawn_boss = true;
                    
                    if (_spawn_boss)
                    {
                        _num = 3;
                        var _boss_ap = scr_set_unit_ap(11, 5);
                        _en_ap[0] += _boss_ap[0];
                        _en_ap[1] += _boss_ap[1];
                    }
                    else
                    {
                        _num = irandom_range(4, 5);
                    }
                    
                    _en_ap[0] += irandom_range(76, 82) + _num;
                    _en_ap[1] += irandom_range(88, 100) + _num;
                    
                    for (i = 0; i < _num; i++)
                    {
                        var _pick = gnx_pool_pick(2, 2, _gnx_picked);
                        var _class = _pick.class_id;
                        var _lvl = _pick.lvl;
                        if (variable_struct_exists(_pick, "ap_override"))
                        {
                            _en_ap[0] += _pick.ap_override[0];
                            _en_ap[1] += _pick.ap_override[1];
                        }
                        else
                        {
                            var _ap = scr_set_unit_ap(_class, _lvl);
                            _en_ap[0] += _ap[0];
                            _en_ap[1] += _ap[1];
                        }
                        _unit_list[i] = scr_create_unit_base(_class, _lvl);
                        array_push(_gnx_picked, _class);
                    }
                    
                    if (_spawn_boss)
                        _unit_list[i] = scr_create_unit_base(11, 5);
                    
                    _coin_num = choose(42, 55, 68, 81);
                    _food_num = choose(30, 32, 34, 36, 38);
                    break;
            }
            
            break;
        
        case 3:
            switch (arg1)
            {
                case 0:
                    _num = irandom_range(4, 5);
                    _en_ap[0] += irandom_range(86, 104) + _num;
                    _en_ap[1] += irandom_range(84, 106) + _num;
                    
                    for (i = 0; i < _num; i++)
                    {
                        var _pick = gnx_pool_pick(3, 0, _gnx_picked);
                        var _class = _pick.class_id;
                        var _lvl = _pick.lvl;
                        if (variable_struct_exists(_pick, "ap_override"))
                        {
                            _en_ap[0] += _pick.ap_override[0];
                            _en_ap[1] += _pick.ap_override[1];
                        }
                        else
                        {
                            var _ap = scr_set_unit_ap(_class, _lvl);
                            _en_ap[0] += _ap[0];
                            _en_ap[1] += _ap[1];
                        }
                        _unit_list[i] = scr_create_unit_base(_class, _lvl);
                        array_push(_gnx_picked, _class);
                    }
                    
                    _coin_num = choose(50, 60, 70);
                    _food_num = choose(30, 35, 40, 45);
                    break;
                
                case 1:
                    _num = irandom_range(4, 5);
                    _en_ap[0] += irandom_range(158, 186) + _num;
                    _en_ap[1] += irandom_range(156, 188) + _num;
                    
                    for (i = 0; i < _num; i++)
                    {
                        var _pick = gnx_pool_pick(3, 1, _gnx_picked);
                        var _class = _pick.class_id;
                        var _lvl = _pick.lvl;
                        var _ap = scr_set_unit_ap(_class, _lvl);
                        _unit_list[i] = scr_create_unit_base(_class, _lvl);
                        array_push(_gnx_picked, _class);
                    }
                    
                    _coin_num = choose(95, 105, 115);
                    _food_num = choose(62, 67, 72, 77);
                    break;
                
                case 2:
                    if (global.unlock.boss[3] == 0)
                        _spawn_boss = true;
                    
                    if (_spawn_boss)
                    {
                        _num = 4;
                        var _boss_ap = scr_set_unit_ap(12, 5);
                        _en_ap[0] += _boss_ap[0];
                        _en_ap[1] += _boss_ap[1];
                    }
                    else
                    {
                        _num = 5;
                    }
                    
                    _en_ap[0] += irandom_range(210, 238) + _num;
                    _en_ap[1] += irandom_range(208, 240) + _num;
                    
                    for (i = 0; i < _num; i++)
                    {
                        var _pick = gnx_pool_pick(3, 2, _gnx_picked);
                        var _class = _pick.class_id;
                        var _lvl = _pick.lvl;
                        var _ap = scr_set_unit_ap(_class, _lvl);
                        _unit_list[i] = scr_create_unit_base(_class, _lvl);
                        array_push(_gnx_picked, _class);
                    }
                    
                    if (_spawn_boss)
                        _unit_list[i] = scr_create_unit_base(12, 5);
                    
                    _coin_num = choose(110, 120, 130, 140, 150);
                    _food_num = choose(60, 75, 90, 105);
                    break;
            }
            
            break;
        
        case 4:
            switch (arg1)
            {
                case 0:
                    if (global.unlock.boss[4] != 1)
                    {
                        _en_ap[0] = 666;
                        _en_ap[1] = 666;
                        _unit_list[0] = scr_create_unit_base(8, 5);
                    }
                    else
                    {
                        var _t_lvl = min(24, global.val.ct_lvl);
                        _en_ap[0] = 600 + (100 * _t_lvl);
                        _en_ap[1] = 600 + (100 * _t_lvl);
                        _num = 5;
                        var _spe_chnc = 5;
                        
                        if (arg2)
                            _spe_chnc += scr_check_skill_data(14);
                        
                        var _spe_class = [];
                        
                        for (i = 0; i < array_length(global.unlock.boss); i++)
                        {
                            if (global.unlock.boss[i] == 1)
                            {
                                switch (i)
                                {
                                    case 0:
                                        array_push(_spe_class, 9);
                                        break;
                                    
                                    case 4:
                                        array_push(_spe_class, 8);
                                        break;
                                    
                                    case 5:
                                        array_push(_spe_class, 13);
                                        break;
                                    
                                    case 3:
                                        array_push(_spe_class, 12);
                                        break;
                                    
                                    case 1:
                                        array_push(_spe_class, 10);
                                        break;
                                    
                                    case 2:
                                        array_push(_spe_class, 11);
                                        break;
                                }
                            }
                        }
                        
                        for (i = 0; i < _num; i++)
                        {
                            var _class, _lvl;

                            if (irandom_range(1, 100) <= _spe_chnc)
                            {
                                _class = _spe_class[irandom_range(0, array_length(_spe_class) - 1)];
                                _lvl = 6;
                            }
                            else
                            {
                                var _pick = gnx_pool_pick(4, 0, _gnx_picked);
                                _class = _pick.class_id;
                                _lvl = _pick.lvl;
                            }

                            _unit_list[i] = scr_create_unit_base(_class, _lvl);
                            array_push(_gnx_picked, _class);
                        }
                    }

                    break;

                case 1:
                    var _t_lvl = global.val.ct_lvl;
                    var _scale = max(0, _t_lvl - 25);
                    _en_ap[0] = 5000 + (500 * _scale);
                    _en_ap[1] = 5000 + (500 * _scale);
                    _num = 5;
                    var _spe_chnc = 5;
                    
                    if (arg2)
                        _spe_chnc += scr_check_skill_data(14);
                    
                    var _spe_class = [];
                    
                    for (i = 0; i < array_length(global.unlock.boss); i++)
                    {
                        if (global.unlock.boss[i] == 1)
                        {
                            switch (i)
                            {
                                case 0:
                                    array_push(_spe_class, 9);
                                    break;
                                
                                case 4:
                                    array_push(_spe_class, 8);
                                    break;
                                
                                case 5:
                                    array_push(_spe_class, 13);
                                    break;
                                
                                case 3:
                                    array_push(_spe_class, 12);
                                    break;
                                
                                case 1:
                                    array_push(_spe_class, 10);
                                    break;
                                
                                case 2:
                                    array_push(_spe_class, 11);
                                    break;
                            }
                        }
                    }
                    
                    for (i = 0; i < _num; i++)
                    {
                        var _class, _lvl;

                        if (irandom_range(1, 100) <= _spe_chnc)
                        {
                            _class = _spe_class[irandom_range(0, array_length(_spe_class) - 1)];
                            _lvl = 6;
                        }
                        else
                        {
                            var _pick = gnx_pool_pick(4, 1, _gnx_picked);
                            _class = _pick.class_id;
                            _lvl = _pick.lvl;
                        }

                        _unit_list[i] = scr_create_unit_base(_class, _lvl);
                        array_push(_gnx_picked, _class);
                    }

                    break;
            }

            _coin_num = 0;
            _food_num = 0;
            break;
    }
    
    if (_coin_num > 0)
    {
        var _item_data = scr_set_item_data(0, _coin_num, -1);
        array_push(_item_pool, _item_data);
    }
    
    if (_food_num > 0)
    {
        var _item_data = scr_set_item_data(1, _food_num, -1);
        array_push(_item_pool, _item_data);
    }
    
    _pool_num += 2;
    var _item_array = global.val.stage_item[arg0][arg1];
    var _ar_num = array_length(_item_array);
    
    for (i = 0; i < _ar_num; i++)
    {
        var _item_data = scr_set_item_data(_item_array[i][0], _item_array[i][1], _item_array[i][2]);
        array_push(_item_pool, _item_data);
    }
    
    _pool_num += i;
    var _num = min(array_length(_item_pool), 3 + arg1);
    
    for (i = 0; i < _num; i++)
    {
        if (irandom_range(1, 100) <= 75)
        {
            var _a = irandom_range(0, _pool_num - 1);
            array_push(_item, _item_pool[_a]);
            array_delete(_item_pool, _a, 1);
            _pool_num--;
        }
    }
    
    _data.unit_list = _unit_list;
    _data.en_ap = _en_ap;
    _data.item = _item;
    return _data;
}

function scr_check_raid_target()
{
    var _stage = [];
    
    for (var i = 0; i < array_length(global.val.stage_info); i++)
    {
        if (global.val.stage_info[i] != -1)
            _stage[i] = min(2, global.val.stage_info[i].max_lvl);
        else
            _stage[i] = -1;
    }
    
    var _a = [];
    var _stage_sel = -1;
    
    while (_stage_sel == -1)
    {
        _a[0] = irandom_range(0, array_length(_stage) - 1);
        _stage_sel = _stage[_a[0]];
    }
    
    _a[1] = irandom_range(0, _stage[_a[0]]);
    return _a;
}

function scr_stage_raid_reward()
{
    global.reward = [[[scr_set_item_data(0, 10, -1), scr_set_item_data(1, 12, -1)], [scr_set_item_data(0, 13, -1), scr_set_item_data(1, 17, -1)], [scr_set_item_data(0, 15, -1), scr_set_item_data(1, 30, -1)]], [[scr_set_item_data(0, 16, -1), scr_set_item_data(1, 8, -1)], [scr_set_item_data(0, 30, -1), scr_set_item_data(1, 14, -1)], [scr_set_item_data(0, 60, -1), scr_set_item_data(1, 22, -1)]], [[scr_set_item_data(0, 28, -1), scr_set_item_data(1, 20, -1)], [scr_set_item_data(0, 55, -1), scr_set_item_data(1, 30, -1)], [scr_set_item_data(0, 90, -1), scr_set_item_data(1, 45, -1)]], [[scr_set_item_data(0, 80, -1), scr_set_item_data(1, 40, -1)], [scr_set_item_data(0, 120, -1), scr_set_item_data(1, 50, -1)], [scr_set_item_data(0, 160, -1), scr_set_item_data(1, 60, -1)]], [[scr_set_item_data(0, 150, -1), scr_set_item_data(1, 70, -1)], [scr_set_item_data(0, 200, -1), scr_set_item_data(1, 80, -1)], [scr_set_item_data(0, 200, -1), scr_set_item_data(1, 80, -1)]]];
}

function scr_set_encounter_reward()
{
    global.val.stage_item = [[[[5, 2, 0], [5, 2, 1], [5, 2, 2], [5, 3, 0], [5, 3, 1], [7, 0, 3], [7, 7, 3]], [[5, 7, 2], [5, 8, 2], [5, 10, 0], [7, 9, 3], [7, 2, 3], [7, 5, 3]], [[5, 9, 1], [5, 36, 4], [5, 11, 0], [5, 11, 1], [5, 11, 2], [5, 41, 6], [7, 8, 3], [7, 32, 3], [7, 14, 3]]], [[[5, 3, 2], [5, 7, 0], [5, 8, 1], [5, 6, 1], [5, 6, 2], [7, 12, 3], [7, 10, 3]], [[5, 36, 6], [5, 13, 0], [5, 13, 2], [5, 15, 1], [5, 9, 0], [5, 41, 4], [7, 1, 3], [7, 13, 3]], [[5, 19, 4], [5, 29, 2], [5, 27, 2], [5, 28, 0], [5, 28, 1], [5, 30, 2], [5, 39, 5], [7, 18, 3], [7, 31, 3], [6, 2, 3]]], [[[5, 32, 0], [5, 32, 1], [5, 32, 2], [5, 12, 1], [5, 12, 2], [5, 42, 4], [5, 42, 5], [6, 4, 3]], [[5, 29, 1], [5, 28, 2], [5, 27, 0], [5, 27, 1], [5, 30, 0], [5, 42, 6], [7, 24, 3], [7, 29, 3], [7, 34, 3]], [[5, 33, 0], [5, 20, 4], [5, 20, 5], [5, 21, 4], [5, 41, 5], [5, 12, 0], [7, 20, 3], [7, 25, 3], [7, 35, 3]]], [[[5, 14, 0], [5, 14, 2], [5, 18, 6], [5, 18, 5], [5, 20, 6], [5, 40, 4], [7, 21, 3], [7, 26, 3], [7, 28, 3]], [[5, 24, 6], [5, 24, 5], [5, 21, 6], [5, 40, 5], [5, 22, 4], [5, 39, 4], [7, 27, 3], [7, 23, 3], [6, 3, 3]], [[5, 22, 5], [5, 22, 6], [5, 24, 4], [5, 40, 6], [5, 38, 4], [5, 38, 5], [5, 23, 4], [5, 23, 5], [7, 16, 3], [7, 38, 3]]], [[], [], []]];
}

